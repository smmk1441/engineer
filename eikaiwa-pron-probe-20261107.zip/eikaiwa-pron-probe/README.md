# ブラウザ上での発音判定 スモール検証

引き継ぎメモ「発音判定-クライアント検証」に対する実装。
**サーバを使わずに、ブラウザだけで音声から音素を取り出して採点できるか**を確かめるための使い捨て検証。

- **全体の作り → [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)**
- **ライセンスと費用（商用化の前に読む） → [docs/LICENSES.md](docs/LICENSES.md)**
- 結論と数字 → [docs/MEASUREMENTS.md](docs/MEASUREMENTS.md)
- 詰まった点・見送った判断 → [docs/NOTES.md](docs/NOTES.md)

**動いているもの（URLを知っていれば誰でも開けます）**

| | |
|---|---|
| 発音チャレンジ | https://witty-stone-0ebf1d400.5.azurestaticapps.net/ |
| はなして つたえよう | https://witty-stone-0ebf1d400.5.azurestaticapps.net/speaking.html |
| きいて こたえよう | https://witty-stone-0ebf1d400.5.azurestaticapps.net/listen.html |

初回だけモデルを318MB落とすので、**Wi-Fi で、1〜2分待てる状態**で開いてください
（2回目以降は数秒）。マイクの許可が要ります。

## 動かす

```bash
npm install
node tools/serve.mjs --isolate     # http://localhost:8080
```

ブラウザで http://localhost:8080 を開く。初回はモデルを約300MB落とすので待ち時間がある
（2回目以降は Cache Storage から読むので数秒）。

`file://` では ES モジュールもマイクも使えないため、ローカルでもサーバ経由で開く必要がある
（`localhost` は secure context 扱いになる）。

`--isolate` は COOP/COEP を付けて cross-origin isolation を有効にするフラグ。
これが無いと onnxruntime-web の WASM がシングルスレッドに落ちて、推論が3倍前後遅くなる。
本番配信でも同じヘッダが要る。

### 3つの画面

| | |
|---|---|
| `index.html` | **発音チャレンジ**。決まった文を読んで、発音を採点する |
| `listen.html` | **きいて こたえよう**（試作）。設問を聞いて、選択肢を声に出して答える |
| `speaking.html` | **はなして つたえよう**（試作）。教材の問題形式（音読 / 対話 / 発表）をそのまま動かす |

リスニング側は音声認識をしていない。選択肢が有限なので、候補それぞれについて
「この音声をこの文として読ませるのにどれだけ無理があるか」を測り、いちばん無理の
無いものを「言った文」とみなす。根拠は [docs/MEASUREMENTS.md](docs/MEASUREMENTS.md) §7-2。

問題を足すには `tools/gen-listening.mjs` の `QUESTIONS` に追記して:

```bash
node tools/gen-listening.mjs > data/listening.json
bash tools/gen-listening-audio.sh
```

### スピーキング（教材の問題形式）

`speaking.html` は教材からもらった問題サンプルをそのまま動かすもので、種別が3つある。

| 種別 | 生徒が言う文 | 画面の流れ |
|---|---|---|
| **音読** | お手本と同じ | お手本を聞く → 言う |
| **対話** | 自分で決める | 質問を聞く → **答えをタップ** → 言う |
| **発表** | 自分で決める | メモを見る → **伝える内容をタップ** → 言う |

2文で答える形式（`That is Elly. She is kind.` のうち `She is kind.` だけを採点）にも
対応している。前置きは**言っても言わなくてもよく**、名前が何であっても TGT の点は
変わらない。仕組みと実測は [docs/MEASUREMENTS.md](docs/MEASUREMENTS.md) §7-11。

**採点の経路は1本。** 対話・発表でも、答えをタップした時点で正解文が既知になるので、
以降は音読とまったく同じ処理を通る。

機械に「何を答えたか」を当てさせることもできるが（`listen.html` のやり方）、
枠が同じで1語しか違わない候補だと日本語訛り＋雑音で正答率が 40〜60% まで落ちる。
**先に選ばせればその不確かさが消える。** 根拠は
[docs/MEASUREMENTS.md](docs/MEASUREMENTS.md) §7-9。

問題を足すには `tools/gen-speaking.mjs` の `QUESTIONS` に追記して:

```bash
node tools/gen-speaking.mjs > data/speaking.json
bash tools/gen-speaking-audio.sh
```

### デモでの操作

1. マイクボタンを押す → 課題文を読む → もう一度押して停止
2. 星と、単語／音素ごとの色分けが出る
3. 「おてほん」は同梱した音声（`audio/model/*.m4a`）を鳴らす

音声ファイルを画面にドロップしても判定できる（検証用。マイクの無い環境やデモ素材の再現に使う）。

### 構成を切り替える（計測用）

URL パラメータで差し替えられる。右上の「計測」でパネルが開く。

| パラメータ | 例 | 効果 |
|---|---|---|
| `device` | `wasm` / `webgpu` | 実行バックエンド。既定は WebGPU を試したうえで自己検証し、だめなら WASM。現状 WebGPU は必ず落ちる（docs/MEASUREMENTS.md §3-2） |
| `dtype` | `q8` / `q4` / `bnb4` / `fp16` / `fp32` | モデルの量子化 |
| `threads` | `1` | WASM のスレッド数を固定 |
| `aec` | `1` | マイクの音声処理（AEC/NS/AGC）を通話向けの既定に戻す。既定はオフ |
| `worker` | `0` | 推論を Worker ではなくメインスレッドで走らせる（画面が固まる。比較用） |
| `rate` | `native` | AudioContext を 16kHz ではなくハードウェア既定のレートで開く（比較用） |
| `model` | `teacher` / `s12` / `s12-child` | 使うモデル。[data/models.json](data/models.json) の `id`。既定は先頭（現行24層）。計測パネルのプルダウンからも選べる |
| `metrics` | `1` | 計測パネルを開いた状態で起動 |
| `probe` | `1` | 自動計測用のフックを生やす |

例: `http://localhost:8080/?device=wasm&dtype=q8&threads=1&metrics=1`

### モデルを切り替える

計測パネル（右上の「計測」）のいちばん上にプルダウンがある。選ぶと
`?model=<id>` を付けて読み直す。子ども向けの画面にモデル名は出したくないので、
表には出していない。

**切り替えるとモデルを丸ごと落とし直す**（166〜318MB）。キャッシュはモデルごとに
別なので、一度落とせば次からは速い。3本を実ブラウザで並べて比べるには:

```bash
node tools/serve.mjs --isolate &
node tools/compare-models.mjs          # 本番を見るなら BASE=https://... を付ける
```

結果は docs/MEASUREMENTS.md §7-8。**既定を蒸留モデルに変えていないのは、
サイズが半分になる代わりに、ネイティブと訛りを見分ける幅が4割縮むため。**

## 確認する

```bash
npm test                              # アライメントと採点のユニットテスト
node tools/test-mic.mjs               # マイク経路の通し確認（Chrome の偽マイクに wav を流す）
node tools/shots.mjs                  # 結果画面のスクリーンショット -> docs/shot-*.png
```

`tools/test-mic.mjs` は `WAV=...` で流す音声を差し替えられる。
probe 経由の計測は Recorder を通らないので、AudioWorklet・リサンプル・無音トリムは
このスクリプトでしか踏めない。

## 計測をやり直す

```bash
# ブラウザ側（DL量・ロード時間・推論時間・CPU絞り・スレッド有無）
node tools/serve.mjs --isolate &
node tools/measure-browser.mjs        # -> docs/browser-metrics.json, docs/shot-result.png

# 精度の目盛り確認（Node 上。話者ラダーに対する採点の並び）
bash bench/make-audio.sh              # 検証用音声を macOS の TTS で作る
node bench/run.mjs q8                 # -> bench/results-q8.json
node bench/run.mjs fp32               # 量子化の影響を見るとき

# 採点まわり
node bench/calibrate.mjs              # 係数を振って星の分布を見る
node bench/compare-scoring.mjs        # 旧採点との比較 -> docs/compare-scoring.json
node bench/exp-choice.mjs             # リスニング問題（選択肢から選ぶ）の可否 -> docs/exp-choice.json
node tools/exp-mic-path.mjs           # マイク経路の劣化 -> docs/exp-mic-path.json
```

計測は機械が空いているときに回すこと。Chrome を何本も上げたままだと
推論時間が倍近くぶれる（実際に一度それで誤った数字を出した）。

## 課題文を足す

[tools/gen-reference.mjs](tools/gen-reference.mjs) の `SENTENCES` に追記して、

```bash
npm run data                    # espeak-ng が要る: brew install espeak-ng
bash tools/gen-model-audio.sh   # 「おてほん」の音声（macOS の say を使う）
```

`data/reference.json`（正解音素列と許容する異形）、`data/en-phones.json`（英語音素の在庫）、
`audio/model/s*.m4a`（お手本音声）が再生成される。本数に制限は無い。
長い文でも短い文でも通る（`What time do you usually get up in the morning?` の
10単語 30音素で確認済み。画面は折り返して崩れない）。

**お手本の音声は端末の TTS に任せないこと。** ブラウザが選ぶ既定の声しだいで、
同じ文の素点が 0.08〜0.98 まで振れる。詳細は [docs/NOTES.md](docs/NOTES.md)。

### 足したら必ず自己診断を通す

右上の「計測」→「お手本で自己診断」。**お手本の音声をマイクを通さず直接採点する**ので、
ここで星3つが出ない文は、正しく読んでも点が出ない文ということになる。

素点の目安:

| 素点 | 判断 |
|---|---|
| 0.95 以上 | 問題なし |
| 0.85 〜 0.95 | 使えるが、子どもには少し辛い |
| 0.85 未満 | **その文は出題しないほうがいい** |

低く出る原因はだいたい2つ。

1. **辞書形と自然な発話のずれ。** espeak-ng は辞書形を出すが、実際の発話では音が変わる。
   `to school` は `t uː` ではなく `t ə`、`get up` は `ɡ ɛ t` ではなく `ɡ ɛ ɾ`（フラップ化）。
   よくある現象は [tools/variants.mjs](tools/variants.mjs) で吸収しているが、
   取りこぼしはある。足りなければここに追記する
2. **モデルがその音を素で外す。** 対処法が無いので、その文は諦めて別の文にする

例として `I go to school by bus.` は素点 0.74 までしか上がらない。
`bus` の `b` を `v`、`ʌ` を `ɑː` と聞き違えるためで、これは 2 のケース。

## 中身

| ファイル | 役割 |
|---|---|
| `js/engine.js` | wav2vec2 のロードと、フレームごとの対数事後確率の算出 |
| `js/worker.js` | 推論を走らせる Worker。メインスレッドを塞がないため |
| `js/engine-client.js` | Worker 側のエンジンを engine.js と同じ形で使えるようにする層 |
| `js/gop.js` | CTC 強制アライメント（Viterbi）と GOP。採点の中身はここ |
| `js/score.js` | GOP → 星と単語ごとの色。甘め補正はここだけ |
| `js/audio.js` | マイク録音、16kHz へのリサンプル、無音トリム |
| `js/app.js` | 発音チャレンジの画面 |
| `js/listen.js` | リスニング問題の画面 |
| `js/boot.js` | エンジンの起動。2つの画面で共有（WebGPU の自己検証を含む） |
| `tools/gen-reference.mjs` | 課題文 → 正解音素列（espeak-ng） |
| `tools/gen-en-inventory.mjs` | 多言語 vocab から英語音素だけを抜く |
| `tools/gen-model-audio.sh` | 「おてほん」の音声を作る。端末の TTS に任せない |
| `tools/variants.mjs` | 許容する発音の異形（機能語の弱形、t のフラップ化など） |
| `tools/measure-browser.mjs` | 実 Chrome を puppeteer で回す計測 |
| `bench/run.mjs` | Node 上の精度・速度計測 |
| `bench/calibrate.mjs` | 採点の係数を話者ラダーで決める |
| `bench/compare-scoring.mjs` | 旧採点（自由デコード + Needleman-Wunsch）との比較 |
| `bench/legacy/` | 旧採点の実装。比較のためだけに残してある |
| `tools/exp-mic-path.mjs` | 同じ音声を「直接」と「マイク経由」で通して比べる |
| `tools/exp-noise-constraints.mjs` | 雑音下でノイズ抑制が得か損かを測る |
| `bench/exp-degrade.mjs` | クリップ・反響・雑音など、劣化ごとの影響を測る |

採点は CTC 強制アライメント + GOP（Goodness of Pronunciation）。
なぜ自由デコード + 文字列アライメントをやめたかは
[docs/MEASUREMENTS.md §5-2](docs/MEASUREMENTS.md) と [docs/NOTES.md](docs/NOTES.md) に書いた。

使っているモデルは
[onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX](https://huggingface.co/onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX)
（`facebook/wav2vec2-lv-60-espeak-cv-ft` の ONNX 変換）。Hugging Face の CDN から直接読む。

## Azure へのデプロイ

```bash
bash tools/deploy-azure.sh                  # 静的サイトだけ更新（数十秒）
bash tools/deploy-azure.sh --with-model     # 現行モデル318MBも上げ直す（初回・モデル変更時）
bash tools/deploy-azure.sh --with-students  # 蒸留した生徒モデル（166MB×2）も上げる
```

```
ブラウザ ──HTTPS──> Azure Static Web Apps (Free, East Asia)
   │                  *.html / js / css / data / audio  約800KB
   │                  COOP: same-origin / COEP: credentialless
   │
   └──────────────> Azure Blob Storage (japaneast, 匿名読み取り + CORS)
                      wav2vec2 q8            318MB  ← 既定
                      蒸留 12層 q8 ×2         166MB  ← ?model= で選んだときだけ
```

**なぜ Static Web Apps か。** COOP/COEP ヘッダが必須で（無いと `SharedArrayBuffer` が
使えず WASM が1スレッドに落ちて2倍遅くなる）、SWA は `staticwebapp.config.json` で
ヘッダを指定できる。Blob の静的サイト機能では任意ヘッダを付けられず、
Front Door を挟むことになって構成も費用も増える。App Service は常時課金で過剰。

**なぜモデルを Blob に置くか。** SWA は Free で 250MB 上限なので 318MB のモデルは載らない。
HuggingFace CDN のままでも動くが、初回訪問ごとに外部から 300MB 引くことになり、
速度も可用性も他社任せになる。

配信するのは [tools/build-dist.sh](tools/build-dist.sh) が集めたものだけ。
**`docs/` は含めない** — 検証メモには規模や費用の見積もりが入っていて、公開URLに置くものではない。

| | |
|---|---|
| 費用 | SWA Free は ¥0。Blob はストレージ約¥1/月 + 下り約¥5/初回訪問 |
| 認証 | Free tier には無い。URL を知っていれば誰でもアクセスできる |
| モデル取得元 | `data/model-source.json` で切り替え。既定は HuggingFace CDN |

## この検証でやっていないこと

サーバ実装、認証、学習履歴、モデルの学習・蒸留、精度のチューニング。
引き継ぎメモ §5 のとおり。
