// 教材の問題形式（音読 / 対話 / 発表）をそのまま動かす画面。
//
// 種別は3つあるが、**採点の経路は1本**にしてある。
//
//   音読  お手本と同じ文を言う         -> 正解文は最初から既知
//   対話  先生の質問に答える           -> 答えをタップしてから言う。選んだ時点で既知
//   発表  メモを見て自分のことを伝える  -> 同上
//
// 対話と発表で「何を答えたか」を機械に当てさせることもできる（js/listen.js の
// やり方）。ただし枠が同じで1語しか違わない候補だと、日本語訛り＋雑音で
// 正答率が 40〜60% まで落ちる（docs/MEASUREMENTS.md §7-9）。
// **先に選ばせれば正解文が既知になり、音読と同じ精度になる。**
// 「何を答えるか考える」段階は画面の側に残るので、教材として失うものは無い。

import { bootEngine, loadModelAudio, modelRows, bindModelPicker } from './boot.js';
import { gopScore } from './gop.js';
import { scoreUtterance } from './score.js';
import { Recorder, DEFAULT_CONSTRAINTS } from './audio.js';

const params = new URLSearchParams(location.search);

const $ = (id) => document.getElementById(id);
const el = {
  boot: $('boot'), bootMsg: $('boot-msg'), bootFill: $('boot-fill'),
  bootSub: $('boot-sub'), bootRetry: $('boot-retry'),
  app: $('app'), qIndex: $('q-index'), qType: $('q-type'),
  scene: $('q-scene'), instruction: $('q-instruction'),
  memo: $('q-memo'), memoText: $('q-memo-text'),
  say: $('say'), sayIcon: $('say-icon'), sayEn: $('say-en'), sayJa: $('say-ja'),
  choose: $('choose'), chooseAsk: $('choose-ask'), choices: $('choices'),
  play: $('btn-play'), playLabel: $('play-label'),
  rec: $('btn-rec'), micLabel: $('mic-label'),
  meter: $('meter'), bars: document.querySelectorAll('.bars i'),
  result: $('result'), stars: $('stars'), verdict: $('verdict'),
  words: $('words'), hint: $('hint'),
  fluencyFill: $('fluency-fill'), fluencyText: $('fluency-text'),
  again: $('btn-again'), next: $('btn-next'),
  metrics: $('metrics'), metricsBody: $('metrics-body'), metricsToggle: $('metrics-toggle'),
  selfTest: $('btn-self-test'), benchOut: $('bench-out'),
  promptCard: document.querySelector('.prompt-card'),
};

const state = {
  questions: [], at: 0, engine: null, recorder: null,
  busy: false, recording: false, metrics: {},
  /** いま読ませる文。対話・発表では選択で決まるまで null */
  say: null, lastScore: null, lastStats: null,
};

const TYPE_LABEL = { read: '音読', dialog: '対話', present: '発表' };

// ---------- 起動 ----------

boot().catch((err) => {
  console.error(err);
  el.bootMsg.textContent = 'じゅんび できませんでした';
  el.bootSub.textContent = String(err.message || err);
  el.bootRetry.hidden = false;
});
el.bootRetry.addEventListener('click', () => location.reload());

async function boot() {
  state.questions = await fetch('data/speaking.json').then((r) => r.json());

  el.bootFill.classList.add('indeterminate');
  const { engine, metrics } = await bootEngine({
    params,
    onStatus: (msg, sub) => {
      el.bootMsg.textContent = msg;
      if (sub) el.bootSub.textContent = sub;
    },
    onProgress: ({ pct, loaded, total }) => {
      el.bootFill.classList.remove('indeterminate');
      el.bootFill.style.width = pct.toFixed(1) + '%';
      el.bootMsg.textContent = `よみこみ中… ${Math.round(pct)}%`;
      el.bootSub.textContent = `${fmtMB(loaded)} / ${fmtMB(total)}`;
    },
  });
  state.engine = engine;
  state.metrics = metrics;
  renderMetrics();

  el.bootFill.classList.remove('indeterminate');
  el.bootFill.style.width = '100%';
  el.bootMsg.textContent = 'じゅんび できました！';
  await sleep(420);
  el.boot.classList.add('done');
  el.app.hidden = false;
  setTimeout(() => { el.boot.hidden = true; }, 500);

  if (params.get('metrics') === '1') el.metrics.hidden = false;
  show(0);

  if (params.get('probe') === '1') {
    self.__probe = {
      metrics: () => state.metrics,
      show,
      pick,
      lastScore: () => state.lastScore,
      async run(samples, questionIndex = 0, choiceIndex = 0) {
        show(questionIndex);
        if (state.questions[questionIndex].choices) pick(choiceIndex);
        await evaluate(Float32Array.from(samples));
        return { metrics: state.metrics, score: state.lastScore };
      },
    };
  }
  self.dispatchEvent(new Event('probe-ready'));
}

// ---------- 出題 ----------

function show(i) {
  state.at = i;
  state.say = null;
  state.lastScore = null;
  const q = state.questions[i];

  // グループ内の問題数は固定ではない（2文で答える を足したので）
  const inGroup = state.questions.filter((x) => x.group === q.group).length;
  el.qIndex.textContent = `${q.group} ${q.no} / ${inGroup}`;
  el.qType.textContent = TYPE_LABEL[q.type];
  el.qType.dataset.type = q.type;

  el.scene.hidden = !q.scene;
  el.scene.textContent = q.scene || '';
  el.instruction.textContent = q.instruction;

  el.memo.hidden = q.type !== 'present';
  el.memoText.textContent = q.memo || '';

  // 発表には流す音声が無い。ボタンを出しておくと押して無反応になる。
  el.play.hidden = !q.audio;
  el.playLabel.textContent = q.type === 'dialog' ? 'しつもん' : 'おてほん';

  el.choose.hidden = !q.choices;
  el.chooseAsk.textContent = q.askJa || '';
  el.chooseAsk.hidden = !q.askJa;

  el.result.hidden = true;
  el.again.hidden = true;
  el.next.textContent = i === state.questions.length - 1 ? 'さいしょに もどる' : 'つぎの もんだい →';

  if (q.choices) {
    renderChoices(q);
    setSay(null);
  } else {
    // 音読は言う文が最初から決まっている
    setSay({ ...q.target, icon: q.icon, ja: null });
  }

  if (q.audio) play();
}

function renderChoices(q) {
  el.choices.innerHTML = '';
  q.choices.forEach((c, idx) => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'choice choice-btn';
    card.dataset.index = String(idx);
    card.innerHTML = '<span class="choice-icon" aria-hidden="true"></span>'
      + '<span class="choice-en"></span><span class="choice-ja"></span>';
    card.querySelector('.choice-icon').textContent = c.icon || '';
    card.querySelector('.choice-en').textContent = c.text;
    card.querySelector('.choice-ja').textContent = c.ja;
    card.addEventListener('click', () => pick(idx));
    el.choices.append(card);
  });
}

/** 言う文を決める。ここで正解文が既知になり、以降は音読とまったく同じ経路。 */
function pick(idx) {
  if (state.busy) return;
  const q = state.questions[state.at];
  const c = q.choices[idx];
  [...el.choices.children].forEach((card, i) => card.classList.toggle('chosen', i === idx));
  setSay({ ...c });
  el.result.hidden = true;
  el.again.hidden = true;
}

function setSay(say) {
  state.say = say;
  el.say.hidden = !say;
  if (!say) {
    el.micLabel.textContent = 'まず こたえを えらんでね';
    el.rec.disabled = true;
    return;
  }
  el.sayIcon.textContent = say.icon || '';
  el.sayIcon.hidden = !say.icon;
  // 前置きのある問題では、言うのは2文。前置きは任意なので薄く見せる。
  el.sayEn.innerHTML = '';
  if (say.lead) {
    const lead = document.createElement('span');
    lead.className = 'say-lead';
    lead.textContent = say.lead + ' ';
    el.sayEn.append(lead);
  }
  el.sayEn.append(document.createTextNode(say.text));
  el.sayJa.textContent = say.ja || '';
  el.sayJa.hidden = !say.ja;
  el.rec.disabled = false;
  el.micLabel.textContent = 'ボタンを おして いってみよう';
}

const player = new Audio();
player.preload = 'auto';
function play() {
  const src = state.questions[state.at].audio;
  if (!src) return;
  if (!player.src.endsWith(src)) player.src = src;
  player.currentTime = 0;
  player.play().catch(() => { /* 出力が無い環境。無視 */ });
}
el.play.addEventListener('click', play);

el.next.addEventListener('click', () => show((state.at + 1) % state.questions.length));
el.again.addEventListener('click', () => {
  el.result.hidden = true;
  el.again.hidden = true;
  el.micLabel.textContent = 'ボタンを おして いってみよう';
});

// ---------- 録音 ----------

el.rec.addEventListener('click', async () => {
  if (state.busy || !state.say) return;
  if (state.recording) return stopAndScore();

  try {
    if (!state.recorder) {
      state.recorder = new Recorder(DEFAULT_CONSTRAINTS);
      state.recorder.onOverrun = () => stopAndScore();
    }
    if (!state.recorder.isOpen) el.micLabel.textContent = 'マイクを じゅんびちゅう…';
    await state.recorder.open();
    state.recorder.start();
  } catch (err) {
    el.micLabel.textContent = 'マイクが つかえません';
    console.error(err);
    return;
  }
  state.recording = true;
  el.rec.classList.add('rec');
  el.micLabel.textContent = 'きいています… おわったら もういちど おしてね';
  el.meter.hidden = false;
  el.result.hidden = true;
  drawMeter();
});

let meterRAF = 0;
function drawMeter() {
  const r = state.recorder;
  if (!r || !r.recording) return cancelAnimationFrame(meterRAF);
  const level = r.peek();
  const n = el.bars.length;
  el.bars.forEach((bar, i) => {
    const w = 1 - Math.abs(i - (n - 1) / 2) / (n / 2);
    const h = 6 + level * 38 * (0.35 + 0.65 * w) * (0.75 + Math.random() * 0.5);
    bar.style.height = Math.min(44, h).toFixed(0) + 'px';
  });
  meterRAF = requestAnimationFrame(drawMeter);
}

async function stopAndScore() {
  const rec = state.recorder;
  state.recording = false;
  el.rec.classList.remove('rec');
  el.meter.hidden = true;
  cancelAnimationFrame(meterRAF);

  // 停止を押した瞬間に「かんがえ中」にする。録音の取り出しにも時間がかかり、
  // そのあいだ無防備だともう一度押せてしまう。
  enterBusy();
  try {
    const { audio, stats } = await rec.stop();
    await evaluate(audio, stats);
  } catch (err) {
    console.error(err);
    el.micLabel.textContent = 'うまく ろくおん できませんでした';
    await rec.release().catch(() => {});
  } finally {
    exitBusy();
  }
}

let busyDepth = 0;
function enterBusy() { if (busyDepth++ === 0) { state.busy = true; setThinking(true); } }
function exitBusy() { if (--busyDepth === 0) { state.busy = false; setThinking(false); } if (busyDepth < 0) busyDepth = 0; }

function setThinking(on) {
  el.rec.disabled = on || !state.say;
  el.rec.classList.toggle('thinking', on);
  el.promptCard.classList.toggle('thinking', on);
  el.rec.setAttribute('aria-busy', String(on));
  el.next.disabled = on;
  el.again.disabled = on;
  el.play.disabled = on;
  [...el.choices.children].forEach((c) => { c.disabled = on; });
  if (on) el.micLabel.textContent = 'いま きいているよ…';
}

// ---------- 採点 ----------

async function evaluate(audio, stats = null) {
  state.lastStats = stats;
  if (stats) renderMetrics();
  if (audio.length < 16000 * 0.25) {
    el.micLabel.textContent = 'こえが きこえなかったよ。もういちど！';
    return;
  }
  const asked = state.at;
  const say = state.say;
  if (!say) return;
  enterBusy();

  try {
    await nextPaint();
    const out = await state.engine.recognize(audio);
    state.metrics.lastMs = Math.round(out.ms);
    state.metrics.lastSec = +out.audioSec.toFixed(2);
    renderMetrics();
    // ここから先は発音チャレンジとまったく同じ。正解文は既知。
    const scored = judge(out, say);
    state.lastScore = { ...scored, hyp: out.phones.map((p) => p.tok), said: say.text };
    renderMetrics();
    if (state.at === asked) renderResult(scored);
  } catch (err) {
    console.error(err);
    el.micLabel.textContent = 'うまく きけませんでした';
  } finally {
    exitBusy();
  }
}

/**
 * 答えを採点する。
 *
 * 2文で答える問題（`That is Elly. She is kind.`）では、前置きは言っても
 * 言わなくてもよい。どちらで貼り付けるのが正しいかは言ってみるまで
 * 分からないので、**両方やって良いほうを採る**。
 *
 *   前置きごと貼って TGT だけ採点   言った子はこちらが正しい
 *   TGT だけ貼って採点              言わなかった子はこちらが正しい
 *
 * 片方に決め打つと、もう片方の子が不当に下がる。実測では
 * 前置きを言わなかった子が ★3 -> ★2 に落ちた（docs/MEASUREMENTS.md §7-11）。
 * 間違いが救済されることはない（言い間違えは両方とも ★2 のまま）。
 *
 * 強制アライメントは1回 0.4ms 程度なので、2回でも費用は無視できる。
 */
function judge(out, say) {
  const alone = scoreUtterance(say, gopScore(out, say.phones, say.alts), out.phones);
  if (!say.full) return alone;
  const f = say.full;
  const withLead = scoreUtterance(f, gopScore(out, f.phones, f.alts, { from: f.from }), out.phones);
  return withLead.accuracy >= alone.accuracy ? withLead : alone;
}

// ---------- 結果 ----------

const VERDICT = {
  3: ['かんぺき！', 'すごい！', 'ばっちり！'],
  2: ['いいね！', 'おしい！', 'あと ちょっと！'],
  1: ['ナイス チャレンジ！', 'よく いえたね！'],
  // 星なし。責める言い方にはしない。
  0: ['もういちど チャレンジ！'],
};

function renderResult(s) {
  el.micLabel.textContent = 'もういちど いっても いいよ';
  el.result.hidden = false;
  el.again.hidden = false;

  el.stars.innerHTML = '';
  for (let i = 0; i < 3; i++) {
    const span = document.createElement('span');
    span.textContent = i < s.stars ? '⭐️' : '☆';
    span.style.opacity = i < s.stars ? '1' : '.28';
    el.stars.append(span);
  }
  el.verdict.textContent = VERDICT[s.stars][Math.floor(Math.random() * VERDICT[s.stars].length)];
  el.verdict.classList.remove('zero');

  el.words.innerHTML = '';
  for (const w of s.words) {
    const box = document.createElement('div');
    // 前置きは採点に入っていないので、色を付けずに薄く出す
    box.className = w.context ? 'word context' : `word ${w.level}`;
    const label = document.createElement('span');
    label.className = 'word-text';
    label.textContent = w.display.replace(/[.,!?]+$/, '');
    box.append(label);
    const row = document.createElement('div');
    row.className = 'phones';
    for (const d of w.detail) row.append(phoneChip(d));
    box.append(row);
    el.words.append(box);
  }

  const pct = { smooth: 100, ok: 62, choppy: 28, unknown: 15 }[s.fluency.level];
  el.fluencyFill.style.width = pct + '%';
  el.fluencyText.textContent = { smooth: 'すらすら', ok: 'まあまあ', choppy: 'ゆっくり', unknown: '—' }[s.fluency.level];

  // 星なし。聞き取れなかったか、別のことを言っている。
  // 理由で言うことを変える。「大きな声で」と「問題文を読んで」では
  // 次にやることがまるで違う。
  if (s.stars === 0) {
    el.verdict.classList.add('zero');
    el.hint.hidden = false;
    el.hint.textContent = s.zeroReason === 'silent'
      ? 'マイクに ちかづいて、もういちど いってみよう'
      : 'えらんだ えいぶんを いってみよう';
    return;
  }

  // 録音そのものに問題があるときは、発音の話より先にそちらを伝える。
  const st = state.lastStats;
  if (st && st.cutOff) {
    el.hint.hidden = false;
    el.hint.textContent = 'さいごまで いえたかな？ ボタンは いいおわってから おしてね';
    return;
  }
  if (st && st.snrDb < 12) {
    el.hint.hidden = false;
    el.hint.textContent = 'まわりが すこし うるさいみたい';
    return;
  }
  el.hint.hidden = !s.extraSound;
  if (s.extraSound) el.hint.textContent = 'えいごの おとだけで いってみよう';

}

function phoneChip(d) {
  const slot = document.createElement('span');
  slot.className = 'ph-slot';
  const chip = document.createElement('span');
  chip.className = `ph ${d.level}`;
  chip.textContent = d.ref;
  slot.append(chip);
  const heard = document.createElement('span');
  heard.className = 'ph-heard';
  heard.textContent = d.level !== 'match' && d.heard ? d.heard : '';
  slot.append(heard);
  const label = {
    match: 'ばっちり', near: 'おしい', sub: 'ちがう音に きこえたよ', del: 'いえてなかった',
  }[d.level];
  slot.title = `${d.ref} — ${label}${d.heard ? `（${d.heard} に近い）` : ''}`;
  return slot;
}

// ---------- 計測パネル ----------

el.metricsToggle.addEventListener('click', () => { el.metrics.hidden = !el.metrics.hidden; });
bindModelPicker(el.metricsBody);

function renderMetrics() {
  const m = state.metrics;
  const rows = [
    ...modelRows(m),
    ['backend', `${m.device} / ${m.dtype}`],
    ['自己検証', m.verify
      ? `${m.verify.ok ? 'OK' : 'NG'} (確信度 ${m.verify.meanTopProb?.toFixed(2) ?? '—'})${m.verify.fellBackFrom ? ' ←WebGPUから退避' : ''}`
      : '—'],
    ['推論スレッド', m.inWorker ? 'Worker' : 'メイン'],
    ['ロード', `${(m.loadMs / 1000).toFixed(1)}s`],
    ['直近の推論', m.lastMs != null ? `${m.lastMs}ms / ${m.lastSec}s` : '—'],
  ];
  const st = state.lastStats;
  if (st) {
    rows.push(['— 録音 —', ''], ['S/N', `${st.snrDb.toFixed(1)} dB`],
      ['ピーク', `${(st.peak * 100).toFixed(0)}%`],
      ['長さ', `${st.rawSec?.toFixed(2)}s → ${st.trimmedSec?.toFixed(2)}s`]);
  }
  const sc = state.lastScore;
  if (sc) {
    rows.push(['— 採点 —', ''], ['言った文', sc.said],
      ['素点', sc.accuracy.toFixed(3)], ['発話GOP', sc.utteranceGop.toFixed(3)],
      ['きこえた音', sc.hyp.join(' ') || '（なし）']);
  }
  el.metricsBody.innerHTML = rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('');
}

// マイクを通さず、同梱の音声をそのままエンジンへ入れる。
// 音読の問題でだけ成立する（対話は質問音声なので、答えとは別物）。
el.selfTest.addEventListener('click', async () => {
  el.selfTest.disabled = true;
  const lines = [];
  try {
    for (let i = 0; i < state.questions.length; i++) {
      const q = state.questions[i];
      if (q.type !== 'read') { lines.push(`${q.id} ${TYPE_LABEL[q.type]} — お手本が無いので省略`); continue; }
      const audio = await loadModelAudio(q.audio);
      const out = await state.engine.recognize(audio);
      const s = scoreUtterance(q.target, gopScore(out, q.target.phones, q.target.alts), out.phones);
      lines.push(`${q.id} ${'★'.repeat(s.stars)}${'☆'.repeat(3 - s.stars)} ${s.accuracy.toFixed(2)}  ${q.target.text}`);
      el.benchOut.textContent = lines.join('\n');
    }
  } catch (err) {
    lines.push('失敗: ' + (err.message || err));
    el.benchOut.textContent = lines.join('\n');
  } finally {
    el.selfTest.disabled = false;
  }
});

// ---------- 小物 ----------

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nextPaint = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
const fmtMB = (b) => `${(b / 1e6).toFixed(1)} MB`;
