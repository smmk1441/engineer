// エンジンの起動。発音チャレンジとリスニング問題の両方から使う。
//
// ここを共有しているのは重複を減らすためだけではない。
// **WebGPU の自己検証を通っていないエンジンを使うと、静かに間違った結果が出る**
// （docs/MEASUREMENTS.md §3-2）。採点でも選択肢の判定でも、拠り所は同じ
// フレームごとの事後確率なので、起動経路を分けると片方だけ保護が抜ける。

import * as T from 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.6';
import { WorkerEngine, InlineEngine } from './engine-client.js';

const DEFAULT_MODEL = 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX';

/**
 * 使うモデルを決める。
 *
 * data/models.json に並べたものを ?model=<id> で選べる。蒸留した生徒モデルを
 * 実機で比べるためのもので、既定（先頭）は現行の24層から動かさない。
 * **モデルごとに別物を丸ごと落とす**（166〜318MB）。キャッシュも別なので、
 * 切り替えた直後の1回はダウンロードが走る。
 *
 * **取得元によって ID の形が違う。** 自前配信（Blob）では置き場所がそのまま
 * パスになるが、HuggingFace では組織名が要る
 * （onnx-community/… を落とすと 401）。dir と hf を分けてあるのはこのため。
 * 蒸留した生徒は HuggingFace に上げていないので、自前配信のときだけ使える。
 */
function pickModel(catalog, modelSource, params) {
  const host = modelSource?.remoteHost || '';
  const selfHosted = !!host && !/(^|\/\/)([^/]*\.)?(huggingface\.co|hf\.co)\//.test(host);

  const list = catalog?.models?.length ? catalog.models : null;
  if (!list) {
    const dir = modelSource?.model || DEFAULT_MODEL;
    return { entry: { id: 'default', dir, label: dir }, list: [], model: dir };
  }
  const want = params.get('model');
  const entry = list.find((m) => m.id === want) || list[0];
  const model = selfHosted ? entry.dir : entry.hf;
  if (!model) {
    throw new Error(`「${entry.label}」は自前配信のときだけ使えます（いまの取得元: ${host || 'HuggingFace'}）`);
  }
  // 取得元に無いものは選ばせない。選べば必ず 401 になる。
  return { entry, list: list.filter((m) => selfHosted || m.hf), model };
}

/**
 * @param {object} opts
 * @param {URLSearchParams} opts.params  URL パラメータ（device / dtype / threads / worker）
 * @param {(msg: string, sub?: string) => void} [opts.onStatus] 状態の文言
 * @param {(p: {pct: number, loaded: number, total: number}) => void} [opts.onProgress] ダウンロード進捗
 * @returns {Promise<{engine, metrics, modelSource, loadModelAudio}>}
 */
export async function bootEngine({ params, onStatus = () => {}, onProgress = () => {} }) {
  const [vocab, enPhones, modelSource, catalog] = await Promise.all([
    fetch('data/vocab.json').then((r) => r.json()),
    fetch('data/en-phones.json').then((r) => r.json()),
    fetch('data/model-source.json').then((r) => r.json()).catch(() => null),
    fetch('data/models.json').then((r) => r.json()).catch(() => null),
  ]);
  const { entry, list, model } = pickModel(catalog, modelSource, params);

  // 既定は WASM。WebGPU はこのモデルで壊れた出力を返すことが分かっているので、
  // 既定で試すとモデルを2回落とすだけ無駄になる。
  // onnxruntime-web 側が直ったか確かめたいときは ?device=webgpu を明示する。
  let device = params.get('device') === 'webgpu' ? 'webgpu' : 'wasm';
  let dtype = params.get('dtype') || (device === 'webgpu' ? 'q4f16' : 'q8');

  const cached = await isCached(model);
  onStatus(cached ? 'よみこみ中…' : 'はじめての じゅんび中…',
    cached ? '2かいめ からは すぐ はじまります' : 'はじめの1かいだけ、すこし じかんが かかります');

  const progress = makeProgress(onStatus, onProgress);
  const t0 = performance.now();
  const make = (d, t) => makeEngine({ model, device: d, dtype: t, vocab, enPhones, modelSource, params, cb: progress.cb });

  let { engine, inWorker } = await make(device, dtype);

  // 出力が壊れていないか、既知の音声で1回だけ確かめる。
  let verify = await verifyEngine(engine, model);
  if (!verify.ok && device !== 'wasm') {
    console.warn('バックエンドの出力が不正です。WASM に切り替えます', verify);
    onStatus('べつの ほうほうで よみこみ中…');
    // 壊れたほうを先に解放する。持ったままだとモデル2本ぶんのメモリを抱える。
    await engine.dispose();
    device = 'wasm';
    dtype = 'q8';
    ({ engine, inWorker } = await make(device, dtype));
    verify = { ...(await verifyEngine(engine, model)), fellBackFrom: 'webgpu' };
  }

  return {
    engine,
    modelSource,
    loadModelAudio,
    metrics: {
      device, dtype, verify, inWorker, cached,
      model: entry, models: list,
      host: new URL(modelSource?.remoteHost || 'https://huggingface.co/').host,
      threads: engine.threads,
      crossOriginIsolated: self.crossOriginIsolated,
      bytes: progress.total(),
      loadMs: Math.round(performance.now() - t0),
    },
  };
}

async function makeEngine({ model, device, dtype, vocab, enPhones, modelSource, params, cb }) {
  const options = { model, dtype, device, vocab, allowedIds: enPhones.ids };
  const threads = Number(params.get('threads') || 0);

  // 推論は Worker で走らせる。メインスレッドに置くと WASM が画面を完全に塞ぐ。
  if (params.get('worker') !== '0') {
    try {
      const engine = new WorkerEngine(options);
      await engine.load(cb, threads, modelSource);
      return { engine, inWorker: true };
    } catch (err) {
      console.warn('Worker が使えません。メインスレッドで動かします', err);
    }
  }
  const engine = new InlineEngine({ transformers: T, ...options });
  await engine.load(cb, threads, modelSource);
  return { engine, inWorker: false };
}

/**
 * 計測パネルに差し込むモデル切り替え。
 *
 * 子ども向けの画面にモデル名を出すわけにいかないので、検証用の計測パネルの中に置く。
 * 選ぶと ?model=<id> を付けて読み直す。**別モデルは別ダウンロード**になる。
 */
export function modelRows(m) {
  if (!m.models?.length) return [];
  const opts = m.models.map((x) => `<option value="${x.id}"${x.id === m.model.id ? ' selected' : ''}>`
    + `${x.label} / ${x.sizeMB}MB</option>`).join('');
  return [
    ['モデル', `<select id="model-pick" class="model-pick">${opts}</select>`],
    ['', `<span class="model-note">${m.model.note || ''}</span>`],
  ];
}

/** dl は毎回描き直すので、中身ではなく入れ物側で受ける。 */
export function bindModelPicker(root) {
  root.addEventListener('change', (e) => {
    if (e.target.id !== 'model-pick') return;
    const url = new URL(location.href);
    url.searchParams.set('model', e.target.value);
    url.searchParams.set('metrics', '1');
    location.href = url.toString();
  });
}

/** 同梱のお手本音声を 16kHz モノラルにして返す */
export async function loadModelAudio(url) {
  const buf = await (await fetch(url)).arrayBuffer();
  const decoded = await new OfflineAudioContext(1, 1, 16000).decodeAudioData(buf);
  if (decoded.sampleRate === 16000) return decoded.getChannelData(0);
  const oc = new OfflineAudioContext(1, Math.round((decoded.length * 16000) / decoded.sampleRate), 16000);
  const src = oc.createBufferSource();
  src.buffer = decoded;
  src.connect(oc.destination);
  src.start();
  return (await oc.startRendering()).getChannelData(0);
}

/**
 * ロードしたエンジンがまともな確率を返しているかを、既知の音声で確かめる。
 *
 * onnxruntime-web の WebGPU バックエンドは、このモデルで壊れた出力を返す。
 * 同じ重み (q8) でも WASM が最大確率 0.98 を返すのに対し WebGPU は 0.30。
 * 採点も選択肢の判定も事後確率の値を直接使うので、これは黙って全部を狂わせる。
 */
export async function verifyEngine(engine) {
  try {
    const out = await engine.recognize(await loadModelAudio('audio/model/s1.m4a'));
    let sum = 0;
    for (let t = 0; t < out.T; t++) {
      let m = -Infinity;
      for (let k = 0; k < out.K; k++) if (out.logp[t * out.K + k] > m) m = out.logp[t * out.K + k];
      sum += Math.exp(m);
    }
    const meanTopProb = sum / out.T;
    // 正常なら 0.95 前後。壊れていると 0.3 付近まで落ちる。
    return { ok: meanTopProb > 0.6 && out.phones.length >= 3, meanTopProb, phones: out.phones.length };
  } catch (err) {
    return { ok: false, error: String(err.message || err) };
  }
}

/** 2回目以降かどうか。ダウンロード時間の計測を分けるために見る。 */
async function isCached(model) {
  if (!('caches' in self)) return false;
  try {
    const keys = await (await caches.open('transformers-cache')).keys();
    return keys.some((r) => r.url.includes(model) && r.url.includes('.onnx'));
  } catch { return false; }
}

/** transformers.js の進捗イベントをまとめて1本にする */
function makeProgress(onStatus, onProgress) {
  const files = new Map();
  return {
    total: () => [...files.values()].reduce((a, f) => a + (f.loaded || 0), 0),
    cb(e) {
      if (e.status === 'progress' && e.total) {
        files.set(e.file, { loaded: e.loaded, total: e.total });
        let loaded = 0, total = 0;
        for (const f of files.values()) { loaded += f.loaded; total += f.total; }
        onProgress({ pct: Math.min(100, (loaded / total) * 100), loaded, total });
      } else if (e.status === 'done' && e.file?.endsWith('.onnx')) {
        onStatus('もうすこし…');
      }
    },
  };
}
