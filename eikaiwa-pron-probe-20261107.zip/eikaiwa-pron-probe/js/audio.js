// マイク録音と音声ファイルの読み込み。
// モデルの入力は 16kHz モノラルの Float32 なので、どちらの経路でもそこに揃える。

export const TARGET_RATE = 16000;
const MAX_SECONDS = 8;

/**
 * getUserMedia の音声処理。既定は全部オフ。
 *
 * 通話向けの既定値（AEC/NS/AGC 有効）は発音評価には向かない:
 *  - echoCancellation は端末のスピーカーから出た音を打ち消す。
 *    「おてほん」を鳴らしてマイクに聞かせると、まさにそれが消される。
 *  - noiseSuppression は s / ʃ / f / θ のような摩擦音の高域を削る。
 *    音素認識で一番効く帯域をそのまま持っていかれる。
 *  - autoGainControl は無音区間を持ち上げるので、無音トリムが利かなくなる。
 */
export const DEFAULT_CONSTRAINTS = {
  channelCount: 1,
  echoCancellation: false,
  noiseSuppression: false,
  autoGainControl: false,
};

// AudioWorklet を別ファイルにすると読み込みパスの都合が増えるので Blob で渡す。
// 生の Float32 をそのまま溜めたいだけなので中身は短い。
const WORKLET_SRC = `
class Tap extends AudioWorkletProcessor {
  process(inputs) {
    const ch = inputs[0][0];
    if (ch) this.port.postMessage(new Float32Array(ch));
    return true;
  }
}
registerProcessor('tap', Tap);
`;

/**
 * マイクを保持して、録音の開始/停止だけを繰り返せるようにする。
 *
 * 録音のたびに getUserMedia からやり直すと、実測で毎回 800ms 前後かかる
 * （デバイスを開く時間。AudioContext と AudioWorklet は合計 4ms 程度で、
 * 待ち時間のほぼ全部がここ）。ボタンを押してから録音が始まるまでの間が
 * そのまま体感の重さになるので、一度開いたら保持する。
 *
 * ただし開いている間はブラウザの録音インジケータが点いたままになるので、
 * しばらく使われなければ手放す。
 */
export class Recorder {
  /**
   * @param {object} constraints getUserMedia の audio 制約
   * @param {object} [opts]
   * @param {boolean} [opts.forceRate] AudioContext に 16kHz を直接要求する。既定は true。
   *   非ネイティブのレート要求はデバイスを開き直すので遅い、と考えて既定を外したが、
   *   実測では AudioContext の生成は 16kHz でも 48kHz でも 1ms 未満で差が無かった。
   *   16kHz で開けばリサンプル自体が要らなくなるぶん確実なので、既定に戻してある。
   *   `?rate=native` で比べられる。
   * @param {number} [opts.idleMs] この時間使われなければマイクを手放す
   */
  constructor(constraints = DEFAULT_CONSTRAINTS, { forceRate = true, idleMs = 90000 } = {}) {
    this.constraints = constraints;
    this.forceRate = forceRate;
    this.idleMs = idleMs;
    this.ctx = null;
    this.chunks = [];
    this.recording = false;
    this.level = 0;
    this.startup = {};
    this.idleTimer = 0;
  }

  get isOpen() { return !!this.ctx; }

  /** マイクを開く。すでに開いていれば何もしない（ここが速さの肝）。 */
  async open() {
    clearTimeout(this.idleTimer);
    if (this.ctx) { this.startup = { reused: true, total: 0 }; return; }

    // どこで待たされているかを段階ごとに測る。
    const mark = (k, t) => { this.startup[k] = Math.round(performance.now() - t); };
    const t0 = performance.now();
    this.startup = { reused: false };

    let t = performance.now();
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: this.constraints });
    mark('getUserMedia', t);

    // 要求した制約が本当に効いているとは限らない。ブラウザや OS が
    // 別の録音経路を選ぶことがあり、そこで音が変わる。実際の設定を控える。
    const track = this.stream.getAudioTracks()[0];
    this.settings = { ...track?.getSettings?.(), label: track?.label };

    t = performance.now();
    if (this.forceRate) {
      try { this.ctx = new AudioContext({ sampleRate: TARGET_RATE }); }
      catch { this.ctx = new AudioContext(); }
    } else {
      this.ctx = new AudioContext();
    }
    await this.ctx.resume();
    mark('audioContext', t);
    this.startup.rate = this.ctx.sampleRate;

    t = performance.now();
    const url = URL.createObjectURL(new Blob([WORKLET_SRC], { type: 'text/javascript' }));
    await this.ctx.audioWorklet.addModule(url);
    URL.revokeObjectURL(url);
    mark('worklet', t);

    const src = this.ctx.createMediaStreamSource(this.stream);
    this.analyser = this.ctx.createAnalyser();
    this.analyser.channelCount = 1;
    this.analyser.channelCountMode = 'explicit';
    this.analyser.fftSize = 1024;
    this.analyser.smoothingTimeConstant = 0.6;
    this.buf = new Float32Array(this.analyser.fftSize);

    // 要求しても 2ch で返ってくる環境がある（getSettings で確認できる）。
    // ワークレット側で 1ch に固定し、Web Audio にダウンミックスさせる。
    // 第1チャンネルだけ読むと、信号が片側にしか無い機器で取りこぼす。
    this.node = new AudioWorkletNode(this.ctx, 'tap', {
      channelCount: 1,
      channelCountMode: 'explicit',
      channelInterpretation: 'speakers',
    });
    this.node.port.onmessage = (e) => {
      if (!this.recording) return;
      this.chunks.push(e.data);
      if (this.sampleCount() > MAX_SECONDS * this.ctx.sampleRate) this.onOverrun?.();
    };

    src.connect(this.analyser);
    src.connect(this.node);
    // worklet は出力を持たないが、繋がないと処理が走らないブラウザがある。
    this.node.connect(this.ctx.destination);

    this.startup.total = Math.round(performance.now() - t0);
  }

  /** 録音開始。open() 済みなら一瞬で始まる。 */
  start() {
    clearTimeout(this.idleTimer);
    this.chunks = [];
    this.recording = true;
    this.startedAt = performance.now();
  }

  sampleCount() {
    return this.chunks.reduce((a, c) => a + c.length, 0);
  }

  /** 0..1 のレベル。波形表示用。 */
  peek() {
    if (!this.analyser) return 0;
    this.analyser.getFloatTimeDomainData(this.buf);
    let sum = 0;
    for (let i = 0; i < this.buf.length; i++) sum += this.buf[i] * this.buf[i];
    const rms = Math.sqrt(sum / this.buf.length);
    // 生の RMS はほとんど下に張り付くので、対数で見た目に効く範囲へ伸ばす。
    this.level = Math.max(0, Math.min(1, (Math.log10(rms + 1e-6) + 3.2) / 2.6));
    return this.level;
  }

  /** 録音を止めて音を取り出す。マイクは開いたまま。 */
  async stop() {
    this.recording = false;
    const rate = this.ctx?.sampleRate ?? TARGET_RATE;
    const merged = concat(this.chunks, this.sampleCount());
    this.chunks = [];
    // しばらく使われなければ手放す。インジケータを点けっぱなしにしない。
    clearTimeout(this.idleTimer);
    this.idleTimer = setTimeout(() => this.release(), this.idleMs);

    const out = await prepare(merged, rate);
    out.stats.startup = this.startup;
    out.stats.settings = this.settings;
    return out;
  }

  /** マイクと AudioContext を手放す */
  async release() {
    clearTimeout(this.idleTimer);
    this.recording = false;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.node?.disconnect();
    await this.ctx?.close().catch(() => {});
    this.ctx = null;
    this.analyser = null;
    this.stream = null;
  }
}

/** ドロップされた音声ファイルを 16kHz モノラルにする */
export async function decodeFile(file) {
  const ctx = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 1, 44100);
  const buf = await ctx.decodeAudioData(await file.arrayBuffer());
  const mono = buf.numberOfChannels === 1
    ? buf.getChannelData(0)
    : mixdown(buf);
  return prepare(mono, buf.sampleRate);
}

function mixdown(buf) {
  const out = new Float32Array(buf.length);
  for (let c = 0; c < buf.numberOfChannels; c++) {
    const d = buf.getChannelData(c);
    for (let i = 0; i < d.length; i++) out[i] += d[i] / buf.numberOfChannels;
  }
  return out;
}

function concat(chunks, total) {
  const out = new Float32Array(total);
  let at = 0;
  for (const c of chunks) { out.set(c, at); at += c.length; }
  return out;
}

/**
 * リサンプルと無音トリム。
 * 録音そのものの品質（レベル・暗騒音・S/N）も一緒に返す。
 * 点が出ない原因が「発音」なのか「録音環境」なのかは、これが無いと切り分けられない。
 */
async function prepare(samples, rate) {
  let audio = samples;
  // 1サンプルも録れていないことがある（マイクが開く前に止めた等）。
  // OfflineAudioContext は長さ0で例外を投げるので、リサンプルへ入れない。
  if (!audio.length) {
    return { audio: new Float32Array(0), stats: analyse(audio) };
  }
  if (rate !== TARGET_RATE) audio = await resample(audio, rate, TARGET_RATE);
  const stats = analyse(audio);
  let trimmed = trimSilence(audio, stats.threshold);
  // トリムで全部消えたのに元の音には信号がある場合は、削りすぎ。
  // 判定できないより、そのまま渡して採点したほうがいい。
  if (!trimmed.length && stats.speechRms > 0.002) {
    trimmed = audio;
    stats.trimFellBack = true;
  }
  // 末尾ぎりぎりまで声が続いていたら、止めるのが早すぎて語尾が切れている可能性。
  // 同じ文でも点がばらつく原因になる。
  stats.cutOff = trimmed.length > 0
    && audio.length - (trimmed.length ? indexOfEnd(audio, stats.threshold) : 0) < 0.12 * TARGET_RATE;
  stats.rawSec = audio.length / TARGET_RATE;
  stats.trimmedSec = trimmed.length / TARGET_RATE;
  return { audio: trimmed, stats };
}

const WIN = 320; // 20ms

/** 20ms フレームごとの RMS を並べて、暗騒音と声のレベルを分けて見る */
export function analyse(audio) {
  const frames = [];
  let peak = 0, clipped = 0;
  for (let i = 0; i + WIN <= audio.length; i += WIN) {
    let sum = 0;
    for (let j = 0; j < WIN; j++) {
      const v = audio[i + j];
      const a = Math.abs(v);
      if (a > peak) peak = a;
      if (a > 0.985) clipped++;
      sum += v * v;
    }
    frames.push(Math.sqrt(sum / WIN));
  }
  if (!frames.length) {
    return { peak: 0, noiseRms: 0, speechRms: 0, snrDb: 0, clipped: 0, threshold: 0.012, frames: 0 };
  }

  const sorted = [...frames].sort((a, b) => a - b);
  const at = (q) => sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * q))];
  const noiseRms = at(0.1);   // 下位10% = 喋っていない区間
  const speechRms = at(0.9);  // 上位10% = 声が出ている区間
  const snrDb = 20 * Math.log10(Math.max(speechRms, 1e-7) / Math.max(noiseRms, 1e-7));

  // しきい値は暗騒音に対して決める。固定値だと、静かな部屋では何も削れず、
  // うるさい部屋では逆に全部が「声」になってしまう。
  //
  // ただし声のレベルを超えさせない。暗騒音が声の 1/2.5 より大きい録音だと
  // noiseRms * 2.5 が声を追い越し、全区間が無音と判定されて何も残らなくなる。
  // 「ボタンを押しても何も起きない」という形で出る。
  const threshold = Math.min(
    Math.max(noiseRms * 2.5, 0.004),
    Math.max(speechRms * 0.5, 1e-6)
  );

  return {
    peak, noiseRms, speechRms, snrDb, threshold,
    clippedRatio: clipped / Math.max(audio.length, 1),
    frames: frames.length,
  };
}

async function resample(samples, from, to) {
  const len = Math.round((samples.length * to) / from);
  const OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const ctx = new OAC(1, len, to);
  const buf = ctx.createBuffer(1, samples.length, from);
  buf.copyToChannel(samples, 0);
  const src = ctx.createBufferSource();
  src.buffer = buf;
  src.connect(ctx.destination);
  src.start();
  const out = await ctx.startRendering();
  return out.getChannelData(0);
}

/**
 * 前後の無音を落とす。録音ボタンを押してから話し出すまでの間が
 * そのまま「流暢さ」の減点になるのを避けるため。
 *
 * しきい値は analyse() が暗騒音から決めた値を使う。固定値にすると、
 * 暗騒音がそれを上回る部屋では1フレームも削れず、雑音ごとモデルに渡ることになる。
 */
export function trimSilence(audio, threshold, padSec = 0.1) {
  let first = -1, last = -1;
  for (let i = 0; i + WIN <= audio.length; i += WIN) {
    let sum = 0;
    for (let j = 0; j < WIN; j++) sum += audio[i + j] * audio[i + j];
    if (Math.sqrt(sum / WIN) > threshold) {
      if (first < 0) first = i;
      last = i + WIN;
    }
  }
  if (first < 0) return new Float32Array(0);
  const pad = Math.round(padSec * TARGET_RATE);
  return audio.slice(Math.max(0, first - pad), Math.min(audio.length, last + pad));
}

/** 声が途切れた最後の位置（サンプル） */
function indexOfEnd(audio, threshold) {
  for (let i = audio.length - WIN; i >= 0; i -= WIN) {
    let sum = 0;
    for (let j = 0; j < WIN; j++) sum += audio[i + j] * audio[i + j];
    if (Math.sqrt(sum / WIN) > threshold) return i + WIN;
  }
  return 0;
}

/** Float32 の 16kHz モノラルを wav にする。録音を持ち出して調べるため。 */
export function toWav(audio) {
  const buf = new ArrayBuffer(44 + audio.length * 2);
  const v = new DataView(buf);
  const str = (off, s) => [...s].forEach((c, i) => v.setUint8(off + i, c.charCodeAt(0)));
  str(0, 'RIFF'); v.setUint32(4, 36 + audio.length * 2, true); str(8, 'WAVEfmt ');
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, TARGET_RATE, true); v.setUint32(28, TARGET_RATE * 2, true);
  v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  str(36, 'data'); v.setUint32(40, audio.length * 2, true);
  for (let i = 0; i < audio.length; i++) {
    v.setInt16(44 + i * 2, Math.max(-32768, Math.min(32767, Math.round(audio[i] * 32768))), true);
  }
  return new Blob([buf], { type: 'audio/wav' });
}
