// 音素認識エンジン。wav2vec2 の CTC ロジットを扱うところまで。
//
// transformers.js の automatic-speech-recognition パイプラインは使わず、
// モデルと特徴量抽出器を直接叩いている。理由は2つ:
//
//   1. onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX には tokenizer.json が無く、
//      パイプラインはロードに失敗する（vocab.json 形式のみ同梱されている）。
//   2. パイプラインは文字列しか返さない。発音評価に要るのはフレームごとの
//      対数事後確率そのもので、そこから強制アライメントと GOP を出す（js/gop.js）。
//
// ブラウザからも Node の計測スクリプトからも使えるよう、transformers.js の
// モジュール自体は呼び出し側から渡してもらう。

/** wav2vec2 の畳み込み段は 16kHz を 320 サンプル(=20ms)ごとに1フレームへ落とす */
export const FRAME_SEC = 0.02;

export class PronunciationEngine {
  /**
   * @param {object} opts
   * @param {object} opts.transformers  @huggingface/transformers のモジュール
   * @param {string} opts.model         HuggingFace のモデルID
   * @param {string} opts.dtype         'q8' | 'q4' | 'fp16' | 'fp32' など
   * @param {string} opts.device        'webgpu' | 'wasm' | 'cpu'(Node)
   * @param {object} opts.vocab         音素 -> id
   * @param {number[]} [opts.allowedIds] 英語音素だけに絞る場合の id リスト
   */
  constructor({ transformers, model, dtype = 'q8', device = 'wasm', vocab, allowedIds = null }) {
    this.T = transformers;
    this.modelId = model;
    this.dtype = dtype;
    this.device = device;

    const id2tok = [];
    for (const [tok, id] of Object.entries(vocab)) id2tok[id] = tok;
    const pad = vocab['<pad>'];

    // vocab は 392 トークンの多言語 IPA。英語音声でも中国語の声調付き母音
    // (ɑ5 など) を拾うことがあるので、英語の在庫外は最初から候補にしない。
    // 以降は「圧縮語彙」= [blank, 英語音素...] の添字で通す。
    const keep = allowedIds ? [...new Set(allowedIds)].filter((id) => id !== pad) : null;
    this.compactIds = keep
      ? [pad, ...keep]
      : Object.values(vocab).filter((id) => id === pad || id2tok[id]?.[0] !== '<').sort((a, b) => (a === pad ? -1 : b === pad ? 1 : a - b));
    this.blank = 0;
    this.tokens = this.compactIds.map((id) => id2tok[id]);
    this.index = new Map(this.tokens.map((t, i) => [t, i]));
    this.stats = {};
  }

  /** モデルをロードする。onProgress は transformers.js の進捗イベントをそのまま流す。 */
  async load(onProgress) {
    const t0 = performance.now();
    const opts = { dtype: this.dtype, device: this.device, progress_callback: onProgress };
    this.fe = await this.T.AutoFeatureExtractor.from_pretrained(this.modelId);
    this.model = await this.T.AutoModelForCTC.from_pretrained(this.modelId, opts);
    this.stats.loadMs = performance.now() - t0;
    return this.stats.loadMs;
  }

  /** ONNX のセッションを解放する。バックエンドを切り替えるときに要る。 */
  async dispose() {
    await this.model?.dispose?.();
    this.model = null;
  }

  /**
   * @param {Float32Array} audio 16kHz モノラル
   * @returns {Promise<{logp:Float32Array, T:number, K:number, blank:number,
   *   tokens:string[], index:Map<string,number>, frameSec:number,
   *   phones:Array<{tok:string,start:number,end:number,p:number}>, ms:number, audioSec:number}>}
   */
  async recognize(audio) {
    const t0 = performance.now();
    const inputs = await this.fe(audio);
    const { logits } = await this.model(inputs);
    const ms = performance.now() - t0;

    const logp = this.#logSoftmax(logits.data, logits.dims);
    const T = logits.dims[1];
    const K = this.compactIds.length;

    return {
      logp, T, K,
      blank: this.blank,
      tokens: this.tokens,
      index: this.index,
      frameSec: FRAME_SEC,
      phones: this.#greedy(logp, T, K),
      ms,
      audioSec: audio.length / 16000,
    };
  }

  /**
   * 圧縮語彙の上で対数ソフトマックスを取る。
   * 以降の処理（強制アライメント・GOP・貪欲デコード）はすべてこの行列だけ見る。
   */
  #logSoftmax(data, dims) {
    const [, T, V] = dims;
    const K = this.compactIds.length;
    const ids = this.compactIds;
    const out = new Float32Array(T * K);
    for (let t = 0; t < T; t++) {
      const off = t * V, dst = t * K;
      let max = -Infinity;
      for (let k = 0; k < K; k++) { const x = data[off + ids[k]]; if (x > max) max = x; }
      let sum = 0;
      for (let k = 0; k < K; k++) sum += Math.exp(data[off + ids[k]] - max);
      const lse = max + Math.log(sum);
      for (let k = 0; k < K; k++) out[dst + k] = data[off + ids[k]] - lse;
    }
    return out;
  }

  /**
   * CTC グリーディデコード。採点そのものには使わないが、
   * 「実際には何と聞こえたか」を出すのに要る。
   */
  #greedy(logp, T, K) {
    const out = [];
    let prev = -1;
    for (let t = 0; t < T; t++) {
      const off = t * K;
      let best = this.blank, bestVal = -Infinity;
      for (let k = 0; k < K; k++) if (logp[off + k] > bestVal) { bestVal = logp[off + k]; best = k; }
      if (best !== this.blank) {
        const p = Math.exp(bestVal);
        if (best !== prev) out.push({ tok: this.tokens[best], startFrame: t, endFrame: t + 1, pSum: p, n: 1 });
        else {
          const last = out[out.length - 1];
          if (last && last.tok === this.tokens[best]) { last.endFrame = t + 1; last.pSum += p; last.n++; }
        }
      }
      prev = best;
    }
    return out.map((o) => ({
      tok: o.tok,
      start: o.startFrame * FRAME_SEC,
      end: o.endFrame * FRAME_SEC,
      p: o.pSum / o.n,
    }));
  }
}
