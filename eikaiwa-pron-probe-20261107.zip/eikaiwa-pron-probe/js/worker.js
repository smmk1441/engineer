// 推論を走らせる Worker。
//
// WASM の推論はメインスレッドを完全に塞ぐ。実測で、1発話の推論中は
// requestAnimationFrame が 0fps（4.6秒間まったく発火しない）。
// CSS アニメーションもコンポジタに載らず止まるので、「かんがえ中」の表示すら動かない。
// 押しても反応が無いように見えて、何度も押されてしまう。
//
// そこで推論だけこちらへ逃がす。メインスレッドは描画と操作に専念できる。
//
// やりとりは { id, type, payload } の1往復。logp は大きいので transfer で渡す。

import * as T from 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.6';
import { PronunciationEngine } from './engine.js';

let engine = null;

self.onmessage = async ({ data: { id, type, payload } }) => {
  try {
    switch (type) {
      case 'load': {
        if (payload.threads) T.env.backends.onnx.wasm.numThreads = payload.threads;
        // モデルの取得元。既定は HuggingFace CDN だが、自前配信に向けられる。
        if (payload.source?.remoteHost) T.env.remoteHost = payload.source.remoteHost;
        if (payload.source?.remotePathTemplate) T.env.remotePathTemplate = payload.source.remotePathTemplate;
        engine = new PronunciationEngine({ transformers: T, ...payload.options });
        await engine.load((e) => self.postMessage({ type: 'progress', payload: e }));
        self.postMessage({
          id,
          payload: { threads: T.env.backends.onnx.wasm.numThreads, loadMs: engine.stats.loadMs },
        });
        break;
      }
      case 'recognize': {
        const out = await engine.recognize(payload.audio);
        // index は Map。構造化クローンで渡せる。logp は転送して複製を避ける。
        self.postMessage({ id, payload: out }, [out.logp.buffer]);
        break;
      }
      case 'dispose': {
        await engine?.dispose();
        engine = null;
        self.postMessage({ id, payload: null });
        break;
      }
      default:
        throw new Error(`unknown message: ${type}`);
    }
  } catch (err) {
    self.postMessage({ id, error: String(err?.message || err) });
  }
};
