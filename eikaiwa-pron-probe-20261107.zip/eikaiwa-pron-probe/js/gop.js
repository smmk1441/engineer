// CTC 強制アライメントと GOP（Goodness of Pronunciation）。
//
// なぜ自由デコード＋文字列アライメントをやめたか
// ------------------------------------------------
// 最初の実装は「音素列を自由に読み取って、正解音素列と Needleman-Wunsch で
// 突き合わせる」だった。動くが、評価としては情報を捨てすぎている:
//
//  - argmax で1本の音素列に潰した時点で、「ɹ と l で迷った」のような
//    肝心の情報が消える。あとは一致/不一致の2値しか残らない
//  - 複合音素が分割されると誤減点になる。`are` を ɑːɹ と書いてある正解に対し
//    モデルが ɑː + ɹ と出すと、置換1＋挿入1の扱いになる。発音は合っているのに
//  - 環境ノイズが音素として読み取られ、そのまま挿入の減点になる
//
// GOP はこれを避ける。正解音素列は既知なのだから自由に読み取る必要はなく、
// 「その音素が、その区間で、どれくらい確からしく出ていたか」を直接測ればいい。
//
//   1. 正解音素列を CTC で強制アライメント（Viterbi）し、各音素のフレーム区間を得る
//   2. その区間での対数事後確率の平均を取る            -> posterior
//   3. 同じ区間の最尤音素との差を取る                  -> GOP
//
// GOP は 0 に近いほど「その音がいちばんそれらしく出ていた」。大きく負なら
// 「別の音のほうがそれらしかった」。音素ごとに連続値が出るので、
// 星の甘さ調整も、色分けの段階も、ここから素直に作れる。

/** 強制アライメントの結果1音素ぶん */
/**
 * @typedef {object} PhoneScore
 * @property {string} tok       正解音素
 * @property {number} start     秒
 * @property {number} end       秒
 * @property {number} posterior 区間平均の事後確率 0..1
 * @property {number} gop       区間平均の log 事後 - log 最尤（<= 0）
 * @property {string|null} heard 区間でいちばん強かった音素（正解と違うときだけ）
 * @property {boolean} squeezed  フレームが1枚も割り当たらなかった
 */

const NEG_INF = -Infinity;

/**
 * CTC 強制アライメント（Viterbi）。
 *
 * @param {Float32Array} logp  T×K の対数事後（K は blank を含む圧縮語彙）
 * @param {number} T           フレーム数
 * @param {number} K           圧縮語彙サイズ
 * @param {number[]} ref       正解音素の圧縮語彙インデックス列
 * @param {number} blank       blank の圧縮語彙インデックス
 * @returns {{path: Int32Array, logProb: number, ext: Int32Array}}
 *   path は各フレームが割り当たった拡張系列上の位置
 */
export function forcedAlign(logp, T, K, ref, blank) {
  const N = ref.length;
  // 拡張系列 [blank, r0, blank, r1, ..., r(N-1), blank]
  const S = 2 * N + 1;
  const ext = new Int32Array(S);
  for (let i = 0; i < N; i++) ext[2 * i + 1] = ref[i];
  for (let i = 0; i <= N; i++) ext[2 * i] = blank;

  const dp = new Float64Array(T * S).fill(NEG_INF);
  const bt = new Int8Array(T * S); // 0: 同じ位置に留まる, 1: 1つ進む, 2: blank を飛ばして2つ進む

  dp[0] = logp[ext[0]];                       // blank から始まる
  if (S > 1) dp[1] = logp[ext[1]];            // 最初の音素から始まる

  for (let t = 1; t < T; t++) {
    const off = t * S, prev = (t - 1) * S, lp = t * K;
    for (let s = 0; s < S; s++) {
      let best = dp[prev + s], move = 0;
      if (s > 0 && dp[prev + s - 1] > best) { best = dp[prev + s - 1]; move = 1; }
      // blank を挟まずに次の音素へ飛べるのは、同じ音素の連続でないときだけ
      if (s > 1 && ext[s] !== blank && ext[s] !== ext[s - 2] && dp[prev + s - 2] > best) {
        best = dp[prev + s - 2]; move = 2;
      }
      dp[off + s] = best === NEG_INF ? NEG_INF : best + logp[lp + ext[s]];
      bt[off + s] = move;
    }
  }

  // 終端は最後の音素か、その後ろの blank
  let s = S - 1;
  if (S > 1 && dp[(T - 1) * S + S - 2] > dp[(T - 1) * S + S - 1]) s = S - 2;
  const logProb = dp[(T - 1) * S + s];

  const path = new Int32Array(T);
  for (let t = T - 1; t >= 0; t--) {
    path[t] = s;
    s -= bt[t * S + s];
  }
  return { path, logProb, ext };
}

/**
 * 制約なしの最尤パスの対数尤度。強制アライメントとの差が、
 * 「正解文として読ませるために、どれだけ無理をしたか」になる。
 * 余分な音を挟んだ発話ほどこの差が開く。
 */
export function freeLogProb(logp, T, K, lo = 0, hi = T) {
  let sum = 0;
  for (let t = lo; t < hi; t++) {
    let best = NEG_INF;
    const off = t * K;
    for (let v = 0; v < K; v++) if (logp[off + v] > best) best = logp[off + v];
    sum += best;
  }
  return sum;
}

/**
 * 強制アライメントの結果から音素ごとの GOP を出す。
 *
 * 余分な音（「アイ・ライク・アップルズ」の間に入る母音）は、ここでは
 * 音素ごとの値としては出てこない。Viterbi が余った区間を隣の正解音素へ
 * 吸収してしまうので、その音素の GOP が下がる形で現れる。
 * 発話全体としての挿入量は utteranceGop のほうで測る。
 *
 * @param {object} out engine.recognize() の戻り
 * @param {string[]} refTokens 正解音素列
 * @param {string[][]} [alts] 位置ごとに許容する発音の異形（tools/variants.mjs が作る）。
 *   辞書形と自然な発話のずれ（to の弱形、get up のフラップ化など）で
 *   減点しないため、これらは正解と同じ扱いにする。
 * @param {{from?: number}} [opts] from を渡すと、その手前の音素は**前置き**として扱い、
 *   貼り付けには使うが採点には入れない。2文で答える問題（`That is Elly. She is kind.` の
 *   うち `She is kind.` だけを見る）のため。前置きを採点区間に含めると、そこを
 *   丁寧に言うほど発話GOP が下がる（docs/MEASUREMENTS.md §7-11）。
 * @returns {{phones: PhoneScore[], utteranceGop: number, from: number}}
 */
export function gopScore(out, refTokens, alts = null, opts = {}) {
  const { logp, T, K, blank, index, tokens, frameSec } = out;

  // 正解音素が語彙に無いことは通常ないが、あっても落ちないようにする
  const ref = refTokens.map((t) => (index.has(t) ? index.get(t) : blank));
  // 各位置で「正解とみなす」id の集合。強制アライメントは辞書形のまま行い、
  // 点を付けるところだけ異形を許す。
  const accept = refTokens.map((t, i) => {
    const ids = new Set([ref[i]]);
    for (const a of alts?.[i] ?? []) if (index.has(a)) ids.add(index.get(a));
    return [...ids];
  });
  const { path, logProb, ext } = forcedAlign(logp, T, K, ref, blank);

  const N = refTokens.length;
  const spans = Array.from({ length: N }, () => []);
  for (let t = 0; t < T; t++) {
    const s = path[t];
    if (s % 2 === 1) spans[(s - 1) / 2].push(t); // 音素の位置（blank は偶数）
  }

  const phones = refTokens.map((tok, i) => {
    const frames = spans[i];
    if (!frames.length) {
      // フレームが割り当たらなかった = その音が入る余地が無かった。
      // 言い落としか、極端に速く読まれたか。
      return { tok, start: 0, end: 0, posterior: 0, gop: -10, heard: null, squeezed: true };
    }
    const ok = accept[i];
    let sumLp = 0, sumGop = 0;
    const rivals = new Map();
    for (const t of frames) {
      const lp = t * K;
      let bestV = 0, bestLp = NEG_INF;
      for (let v = 0; v < K; v++) if (logp[lp + v] > bestLp) { bestLp = logp[lp + v]; bestV = v; }
      // 正解とその異形のうち、いちばんそれらしかったものを採る
      let mine = NEG_INF;
      for (const id of ok) if (logp[lp + id] > mine) mine = logp[lp + id];
      sumLp += mine;
      sumGop += mine - bestLp;
      if (!ok.includes(bestV) && bestV !== blank) rivals.set(bestV, (rivals.get(bestV) || 0) + 1);
    }
    const n = frames.length;
    // 対抗馬は「その区間でいちばん多く1位を取った音素」
    let heard = null, bestCount = 0;
    for (const [v, c] of rivals) if (c > bestCount) { bestCount = c; heard = tokens[v]; }

    return {
      tok,
      start: frames[0] * frameSec,
      end: (frames[n - 1] + 1) * frameSec,
      posterior: Math.exp(sumLp / n),
      gop: sumGop / n,
      heard: bestCount > n / 2 ? heard : null,
      squeezed: false,
    };
  });

  // 発話全体の GOP。1フレームあたりの「無理をした量」。0 に近いほど、
  // 読ませたい文とそのまま一致している。挿入があると開く。
  //
  // **測る区間は採点対象の音素が占めるぶんだけ。** 前置きの文まで含めると、
  // 前置きをはっきり言うほど値が下がり、上手い子ほど損をする（§7-11）。
  const from = Math.max(0, Math.min(opts.from ?? 0, N - 1));
  let lo = 0, hi = T;
  if (from > 0) {
    const first = spans.slice(from).find((f) => f.length);
    const lastSpan = [...spans.slice(from)].reverse().find((f) => f.length);
    if (first && lastSpan) { lo = first[0]; hi = lastSpan[lastSpan.length - 1] + 1; }
  }
  let forced = logProb;
  if (lo !== 0 || hi !== T) {
    forced = 0;
    for (let t = lo; t < hi; t++) forced += logp[t * K + ext[path[t]]];
  }
  const span = Math.max(1, hi - lo);
  const utteranceGop = (forced - freeLogProb(logp, T, K, lo, hi)) / span;

  return { phones, utteranceGop, from };
}
