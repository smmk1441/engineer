// リスニング問題。設問を聞いて、選択肢のうち正しいものを声に出して答える。
//
// 音声認識はしていない。選択肢が有限なので、候補それぞれについて
// 「この音声をこの文として読ませるのにどれだけ無理があるか」（発話GOP）を測り、
// いちばん無理の無いものを「言った文」とみなす。
// 重い推論は1回だけで、候補1つの照合は 0.5ms 程度（docs/MEASUREMENTS.md §7-2）。
//
// エンジンの起動は発音チャレンジと共有（js/boot.js）。WebGPU の自己検証を
// 通っていないと、壊れた確率で選択肢を選ぶことになる。

import { bootEngine, modelRows, bindModelPicker } from './boot.js';
import { gopScore } from './gop.js';
import { Recorder, decodeFile, DEFAULT_CONSTRAINTS } from './audio.js';

const params = new URLSearchParams(location.search);

/**
 * 「どれでもない」と判断する境目。
 *
 * 選択肢から必ず最良を選ぶ作りなので、そのままだと**でたらめな発話でも
 * どれかが選ばれてしまう**。ただし何を基準に弾くかは慎重に選ぶ必要がある。
 *
 * **発話GOP（絶対値）は使えない。** 録音環境で大きく動くため。
 * 実機相当の劣化を通した実測（docs/MEASUREMENTS.md §7-7）:
 *
 *              クリーン  SNR25dB  SNR20dB  SNR15dB
 *   正解(訛り)   -0.268   -0.348   -0.219   -0.372
 *   × ラララ     -0.289   -0.242   -0.193   -0.215
 *
 * 雑音が乗ると正しい発話のほうが低くなり、**順序が逆転する**。
 * 絶対値でしきい値を引くと、訛りのある正解を弾いてでたらめを通すことになる。
 *
 * **「1位と2位の差」は環境が変わっても安定する。** 同じ音声を同じ条件で
 * 比べているので、録音品質の影響が相殺されるため。
 *
 * ただし分布は完全には分かれない。雑音の量を振って測った結果:
 *
 *   しきい値   正解を弾く   でたらめを通す
 *   0.065      1/24 (4%)    13/36 (36%)
 *   0.080      1/24 (4%)     8/36 (22%)   ← 採用
 *   0.100      3/24 (13%)    4/36 (11%)
 *   0.150      6/24 (25%)    1/36 (3%)
 *
 * 0.080 より上げると、**正解を弾く割合が急に増える**。
 * 子ども向けでは「ちゃんと答えたのに×」の害のほうが大きいので、
 * でたらめが2割通ることを受け入れてこの位置にする。
 * 完全には分けられない、というのが正直なところ。
 */
const REJECT_MARGIN = 0.080;

const $ = (id) => document.getElementById(id);
const el = {
  boot: $('boot'), bootMsg: $('boot-msg'), bootFill: $('boot-fill'),
  bootSub: $('boot-sub'), bootRetry: $('boot-retry'),
  app: $('app'), qIndex: $('q-index'), qJa: $('q-ja'), play: $('btn-play'),
  choices: $('choices'), rec: $('btn-rec'), micLabel: $('mic-label'),
  meter: $('meter'), bars: document.querySelectorAll('.bars i'),
  verdict: $('verdict'), hint: $('hint'),
  again: $('btn-again'), next: $('btn-next'),
  metrics: $('metrics'), metricsBody: $('metrics-body'), metricsToggle: $('metrics-toggle'),
  benchOut: $('bench-out'), promptCard: document.querySelector('.prompt-card'),
};

const state = {
  questions: [], at: 0, engine: null, recorder: null,
  busy: false, recording: false, metrics: {}, last: null, answered: false,
};

// ---------- 起動 ----------

boot().catch((err) => {
  console.error(err);
  el.bootMsg.textContent = 'じゅんび できませんでした';
  el.bootSub.textContent = String(err.message || err);
  el.bootRetry.hidden = false;
});
el.bootRetry.addEventListener('click', () => location.reload());

async function boot() {
  state.questions = await fetch('data/listening.json').then((r) => r.json());

  el.bootFill.classList.add('indeterminate');
  const { engine, metrics } = await bootEngine({
    params,
    onStatus: (msg, sub) => {
      el.bootMsg.textContent = msg;
      if (sub) el.bootSub.textContent = sub;
    },
    onProgress: ({ pct, loaded, total }) => {
      el.bootFill.classList.remove('indeterminate');
      el.bootFill.style.width = pct.toFixed(1) + '%';
      el.bootMsg.textContent = `よみこみ中… ${Math.round(pct)}%`;
      el.bootSub.textContent = `${fmtMB(loaded)} / ${fmtMB(total)}`;
    },
  });
  state.engine = engine;
  state.metrics = metrics;
  renderMetrics();

  el.bootFill.classList.remove('indeterminate');
  el.bootFill.style.width = '100%';
  el.bootMsg.textContent = 'じゅんび できました！';
  await sleep(420);
  el.boot.classList.add('done');
  el.app.hidden = false;
  setTimeout(() => { el.boot.hidden = true; }, 500);

  if (params.get('metrics') === '1') el.metrics.hidden = false;
  show(0);

  if (params.get('probe') === '1') {
    self.__probe = {
      metrics: () => state.metrics,
      show,
      last: () => state.last,
      async run(samples, questionIndex = 0) {
        show(questionIndex);
        await evaluate(Float32Array.from(samples));
        return state.last;
      },
    };
  }
  self.dispatchEvent(new Event('probe-ready'));
}

// ---------- 出題 ----------

const player = new Audio();
player.preload = 'auto';

function show(i) {
  state.at = i;
  state.answered = false;
  const q = state.questions[i];
  el.qIndex.textContent = `${i + 1} / ${state.questions.length}`;
  el.qJa.textContent = q.ja;
  el.verdict.hidden = true;
  el.hint.hidden = true;
  el.again.hidden = true;
  el.micLabel.textContent = 'ボタンを おして こたえよう';
  el.next.textContent = i === state.questions.length - 1 ? 'さいしょに もどる' : 'つぎの もんだい →';

  el.choices.innerHTML = '';
  q.choices.forEach((c, idx) => {
    const card = document.createElement('div');
    card.className = 'choice';
    card.dataset.index = String(idx);
    card.innerHTML = `<span class="choice-en"></span><span class="choice-ja"></span>`;
    card.querySelector('.choice-en').textContent = c.text;
    card.querySelector('.choice-ja').textContent = c.ja;
    el.choices.append(card);
  });

  play();
}

function play() {
  const src = state.questions[state.at].audio;
  if (!player.src.endsWith(src)) player.src = src;
  player.currentTime = 0;
  player.play().catch(() => { /* 出力が無い環境。無視 */ });
}
el.play.addEventListener('click', play);

el.next.addEventListener('click', () => show((state.at + 1) % state.questions.length));
el.again.addEventListener('click', () => {
  state.answered = false;
  el.verdict.hidden = true;
  el.hint.hidden = true;
  el.again.hidden = true;
  [...el.choices.children].forEach((c) => { c.className = 'choice'; });
});

// ---------- 録音 ----------

el.rec.addEventListener('click', async () => {
  if (state.busy) return;
  if (state.recording) return stopAndJudge();

  try {
    if (!state.recorder) {
      state.recorder = new Recorder(DEFAULT_CONSTRAINTS);
      state.recorder.onOverrun = () => stopAndJudge();
    }
    if (!state.recorder.isOpen) el.micLabel.textContent = 'マイクを じゅんびちゅう…';
    await state.recorder.open();
    state.recorder.start();
  } catch (err) {
    el.micLabel.textContent = 'マイクが つかえません';
    console.error(err);
    return;
  }
  state.recording = true;
  el.rec.classList.add('rec');
  el.micLabel.textContent = 'きいています… おわったら もういちど おしてね';
  el.meter.hidden = false;
  el.verdict.hidden = true;
  drawMeter();
});

let meterRAF = 0;
function drawMeter() {
  const r = state.recorder;
  if (!r || !r.recording) return cancelAnimationFrame(meterRAF);
  const level = r.peek();
  const n = el.bars.length;
  el.bars.forEach((bar, i) => {
    const w = 1 - Math.abs(i - (n - 1) / 2) / (n / 2);
    const h = 6 + level * 38 * (0.35 + 0.65 * w) * (0.75 + Math.random() * 0.5);
    bar.style.height = Math.min(44, h).toFixed(0) + 'px';
  });
  meterRAF = requestAnimationFrame(drawMeter);
}

async function stopAndJudge() {
  const rec = state.recorder;
  state.recording = false;
  el.rec.classList.remove('rec');
  el.meter.hidden = true;
  cancelAnimationFrame(meterRAF);

  enterBusy();
  try {
    const { audio, stats } = await rec.stop();
    state.lastStats = stats;
    renderMetrics();
    await evaluate(audio);
  } catch (err) {
    console.error(err);
    el.micLabel.textContent = 'うまく ろくおん できませんでした';
    await rec.release().catch(() => {});
  } finally {
    exitBusy();
  }
}

let busyDepth = 0;
function enterBusy() { if (busyDepth++ === 0) { state.busy = true; setThinking(true); } }
function exitBusy() { if (--busyDepth === 0) { state.busy = false; setThinking(false); } if (busyDepth < 0) busyDepth = 0; }

function setThinking(on) {
  el.rec.disabled = on;
  el.rec.classList.toggle('thinking', on);
  el.promptCard.classList.toggle('thinking', on);
  el.rec.setAttribute('aria-busy', String(on));
  el.next.disabled = on;
  el.again.disabled = on;
  el.play.disabled = on;
  if (on) el.micLabel.textContent = 'いま きいているよ…';
}

// ---------- 判定 ----------

async function evaluate(audio) {
  if (audio.length < 16000 * 0.2) {
    el.micLabel.textContent = 'こえが きこえなかったよ。もういちど！';
    return;
  }
  enterBusy();
  const asked = state.at;
  try {
    await nextPaint();
    const q = state.questions[asked];
    const out = await state.engine.recognize(audio);

    // 候補それぞれと突き合わせ、いちばん無理の無いものを選ぶ。
    // 重いのは上の推論1回だけで、ここは候補1つあたり 0.5ms 程度。
    const t0 = performance.now();
    const ranked = q.choices
      .map((c, index) => ({ index, text: c.text, score: gopScore(out, c.phones, c.alts).utteranceGop }))
      .sort((a, b) => b.score - a.score);
    const matchMs = performance.now() - t0;

    const margin = ranked[0].score - ranked[1].score;
    // どれとも言い難いときは、正誤を出さずに言い直してもらう。
    // 無理に選ぶと「でたらめでも正解になる」ことになり、判定として嘘になる。
    const unclear = margin < REJECT_MARGIN;

    state.last = {
      picked: ranked[0].index,
      correct: !unclear && ranked[0].index === q.answer,
      unclear,
      margin,
      ranked,
      heard: out.phones.map((p) => p.tok).join(' '),
      inferMs: Math.round(out.ms),
      matchMs: +matchMs.toFixed(2),
    };
    state.metrics.last = state.last;
    renderMetrics();
    if (state.at === asked) render(state.last, q);
  } catch (err) {
    console.error(err);
    el.micLabel.textContent = 'うまく きけませんでした';
  } finally {
    exitBusy();
  }
}

function render(r, q) {
  state.answered = true;
  el.micLabel.textContent = 'もういちど こたえても いいよ';
  el.again.hidden = false;

  [...el.choices.children].forEach((card, i) => {
    card.className = 'choice';
    // 聞き取れなかったときは、どれも選ばない。正解も見せない。
    // 言い直せば当てられるので、答えを教えてしまわない。
    if (r.unclear) return;
    if (i === r.picked) card.classList.add(r.correct ? 'picked-correct' : 'picked-wrong');
    if (!r.correct && i === q.answer) card.classList.add('is-answer');
  });

  el.verdict.hidden = false;
  if (r.unclear) {
    el.verdict.textContent = 'ん？ きこえなかったよ';
    el.verdict.className = 'verdict unclear';
  } else {
    el.verdict.textContent = r.correct ? 'せいかい！' : 'ざんねん…';
    el.verdict.className = `verdict ${r.correct ? 'ok' : 'ng'}`;
  }

  el.hint.hidden = !r.unclear;
  if (r.unclear) el.hint.textContent = 'こたえを えらんで、はっきり いってみてね';
}

// ---------- 計測パネル ----------

el.metricsToggle.addEventListener('click', () => { el.metrics.hidden = !el.metrics.hidden; });
bindModelPicker(el.metricsBody);

function renderMetrics() {
  const m = state.metrics;
  const rows = [
    ...modelRows(m),
    ['backend', `${m.device} / ${m.dtype}`],
    ['自己検証', m.verify ? `${m.verify.ok ? 'OK' : 'NG'} (確信度 ${m.verify.meanTopProb?.toFixed(2) ?? '—'})${m.verify.fellBackFrom ? ' ←WebGPUから退避' : ''}` : '—'],
    ['推論スレッド', m.inWorker ? 'Worker' : 'メイン'],
    ['ロード', `${(m.loadMs / 1000).toFixed(1)}s`],
  ];
  const st = state.lastStats;
  if (st) rows.push(['— 録音 —', ''], ['S/N', `${st.snrDb.toFixed(1)} dB`], ['ピーク', `${(st.peak * 100).toFixed(0)}%`]);
  const r = m.last;
  if (r) {
    rows.push(
      ['— 判定 —', ''],
      ['推論', `${r.inferMs} ms`],
      ['候補の照合', `${r.matchMs} ms / ${r.ranked.length}件`],
      ['1位と2位の差', r.margin.toFixed(3)],
      ['判定', r.unclear ? 'どれでもない' : (r.correct ? '正解' : '不正解')],
      ['きこえた音', r.heard || '（なし）'],
    );
  }
  el.metricsBody.innerHTML = rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('');
  if (r) {
    el.benchOut.textContent = r.ranked
      .map((x, i) => `${i + 1}. ${x.score.toFixed(3)}  ${x.text}`).join('\n');
  }
}

// ---------- ファイルドロップ（検証用） ----------

addEventListener('dragover', (e) => e.preventDefault());
addEventListener('drop', async (e) => {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  if (!file) return;
  try {
    const { audio, stats } = await decodeFile(file);
    state.lastStats = stats;
    await evaluate(audio);
  } catch (err) {
    console.error(err);
    el.micLabel.textContent = 'この ファイルは よめませんでした';
  }
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nextPaint = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
const fmtMB = (b) => `${(b / 1048576).toFixed(1)} MB`;
