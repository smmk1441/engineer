// Worker 側のエンジンを、PronunciationEngine と同じ形で使えるようにする薄い層。
//
// 呼び出し側（app.js）から見た使い勝手を変えずに、推論だけ別スレッドへ送る。
// Worker が作れない環境では、同じインターフェースのままメインスレッドで動かす。

import { PronunciationEngine } from './engine.js';

export class WorkerEngine {
  constructor(options) {
    this.options = options;
    this.worker = new Worker(new URL('./worker.js', import.meta.url), { type: 'module' });
    this.pending = new Map();
    this.seq = 0;
    this.onProgress = null;

    this.worker.onmessage = ({ data }) => {
      if (data.type === 'progress') { this.onProgress?.(data.payload); return; }
      const p = this.pending.get(data.id);
      if (!p) return;
      this.pending.delete(data.id);
      data.error ? p.reject(new Error(data.error)) : p.resolve(data.payload);
    };
    this.worker.onerror = (e) => {
      const err = new Error(`worker: ${e.message}`);
      for (const p of this.pending.values()) p.reject(err);
      this.pending.clear();
    };
  }

  #call(type, payload, transfer = []) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.worker.postMessage({ id, type, payload }, transfer);
    });
  }

  async load(onProgress, threads = 0, source = null) {
    this.onProgress = onProgress;
    const r = await this.#call('load', { options: this.options, threads, source });
    this.threads = r.threads;
    return r.loadMs;
  }

  /** audio は転送する。呼び出し側で使い回さないこと。 */
  recognize(audio) {
    const copy = Float32Array.from(audio);
    return this.#call('recognize', { audio: copy }, [copy.buffer]);
  }

  async dispose() {
    try { await this.#call('dispose'); } catch { /* すでに落ちている */ }
    this.worker.terminate();
  }
}

/**
 * Worker が使えない環境向け。メインスレッドで動かす。
 * 推論中は画面が固まるが、動かないよりはいい。
 */
export class InlineEngine {
  constructor(options) {
    this.engine = new PronunciationEngine(options);
  }

  async load(onProgress, threads = 0, source = null) {
    if (threads) this.engine.T.env.backends.onnx.wasm.numThreads = threads;
    if (source?.remoteHost) this.engine.T.env.remoteHost = source.remoteHost;
    if (source?.remotePathTemplate) this.engine.T.env.remotePathTemplate = source.remotePathTemplate;
    const ms = await this.engine.load(onProgress);
    this.threads = this.engine.T.env.backends.onnx.wasm.numThreads;
    return ms;
  }

  recognize(audio) { return this.engine.recognize(audio); }
  dispose() { return this.engine.dispose(); }
}
