// GOP を星と色に変える。
//
// 方針は引き継ぎメモのとおり「甘め」。ただし甘さは最後の変換だけで作る。
// 測るところ（js/gop.js）は素直に測り、ここで小学生向けに丸める。
//
// 入力は2つ:
//   phones[].gop    音素ごとの「その音がいちばんそれらしく出ていたか」（0 に近いほど良い）
//   utteranceGop    発話全体を正解文として読ませるのに、どれだけ無理をしたか
//                   （余分な音を挟むほど開く。カタカナ英語の母音挿入はここに出る）
//
// 係数は bench/calibrate.mjs で話者ラダーを見ながら決めた。根拠のある値ではなく、
// 「ネイティブが星3つに張り付き、日本語訛りが星2つに落ち、順位が崩れない」位置。

/** この範囲のズレは満点にする。ネイティブでも 0 ぴったりにはならない。 */
export const GOP_DEAD = 0.25;
/** 減り方のなだらかさ。大きいほど甘い。 */
export const GOP_TAU = 2.6;
/** 発話全体の無理をどれだけ効かせるか。 */
export const UTT_WEIGHT = 1.1;

/**
 * 星3つ / 2つ の境目。測り方（GOP）は触らず、ここだけで甘さを作る。
 * ネイティブ系の最低 0.84 と 日本語訛りの最高 0.68 のあいだに 3つ星の線を置いてある。
 * （これは lenient = accuracy^0.8 に対する線）
 */
export const STAR_CUTS = [0.75, 0.42];

/**
 * 星なしの境目。**これは lenient ではなく素点そのものに対する線。**
 * 測ったのが素点の単位なので、constants と実測を一致させてある。
 *
 * 「全く聞き取れない」「全く違うことを言っている」を星なしにするためのもの。
 * 劣化条件を混ぜて実測した（docs/MEASUREMENTS.md §7-12）:
 *
 *   しきい値  正解を弾く  別の英文  でたらめ(日本語)  ほぼ無音
 *   0.25      0/100      93%       58%            100%
 *   0.30      0/100      97%       81%            100%   ← 採用
 *   0.40      3/100     100%       94%            100%
 *
 * **0.30 なら、劣化込み100件の正解を1件も弾かない。**
 * 上げれば日本語を喋ったときも捕まえられるが、弾かれるのは
 * 「訛りがあって環境も悪い正解」から順。子ども向けでは
 * 「ちゃんと読んだのに星なし」の害のほうが大きい（§7-7 と同じ判断）。
 *
 * **余裕は薄い。** 正解でいちばん低かったのは 0.313（実機相当・日本語訛り・
 * How are you today?）で、この線のすぐ上にいる。子どもの声では下がる見込みが
 * あるので（§7-5）、実データが取れたら最初に引き直す値。
 *
 * 絶対値のしきい値には前科があるので、発話GOP は使っていない。
 * あれは雑音が乗ると正しい発話のほうが低くなり、順序が逆転する。
 */
export const STAR_ZERO = 0.30;

/**
 * 「余分な音が入っている」と言い切る境目。
 * 発話GOP は、正解文として読ませるのにどれだけ無理をしたかなので、
 * 母音挿入（アップルズ型）があると一段はっきり下がる。
 * 話者ラダーでは ネイティブ -0.01 / 中国語訛り -0.02 / 日本語訛り -0.25。
 */
const EXTRA_SOUND_CUT = -0.12;

/** 音素1つの色分けの境目 */
const PHONE_CUTS = { good: 0.72, soso: 0.4 };
/** 単語の色分けの境目 */
const WORD_CUTS = { good: 0.72, soso: 0.4 };

/**
 * @param {{words:Array<{display:string,phones:string[]}>, phones:string[]}} sentence
 * @param {{phones:Array, utteranceGop:number}} gop  gopScore() の戻り
 * @param {Array<{tok:string}>} heard 自由デコードの結果（「実際にはこう聞こえた」の表示用）
 * @param {object} [tune] 係数の差し替え（校正スクリプト用）
 */
export function scoreUtterance(sentence, gop, heard = [], tune = {}) {
  const { dead = GOP_DEAD, tau = GOP_TAU, uttWeight = UTT_WEIGHT, cuts = STAR_CUTS } = tune;

  const detail = gop.phones.map((p) => {
    const score = p.squeezed ? 0 : clamp01(Math.exp((p.gop + dead) / tau));
    return {
      ref: p.tok,
      score,
      heard: p.heard,
      level: p.squeezed ? 'del'
        : score >= PHONE_CUTS.good ? 'match'
        : score >= PHONE_CUTS.soso ? 'near'
        : 'sub',
      start: p.start,
      end: p.end,
    };
  });

  // 前置きの文は貼り付けには使うが、点には入れない（js/gop.js の from）。
  const scored = detail.slice(gop.from ?? 0);
  const mean = scored.length ? scored.reduce((a, d) => a + d.score, 0) / scored.length : 0;
  // 発話全体の無理を掛ける。音素単位では拾えない「間に入った余分な音」がここで効く。
  const accuracy = clamp01(mean * Math.exp(gop.utteranceGop * uttWeight));

  const words = [];
  let at = 0;
  for (const w of sentence.words) {
    const part = detail.slice(at, at + w.phones.length);
    at += w.phones.length;
    const ratio = part.length ? part.reduce((a, d) => a + d.score, 0) / part.length : 0;
    words.push({
      display: w.display,
      // 前置きの単語。貼り付けには使うが点には入っていない
      context: !!w.context,
      ratio,
      level: ratio >= WORD_CUTS.good ? 'good' : ratio >= WORD_CUTS.soso ? 'soso' : 'weak',
      detail: part,
    });
  }

  // 甘め補正。素点をそのまま星に落とすと2つ星に寄るので、一枚かませる。
  const lenient = Math.pow(accuracy, 0.8);
  const { zero = STAR_ZERO } = tune;
  const stars = accuracy < zero ? 0
    : lenient >= cuts[0] ? 3 : lenient >= cuts[1] ? 2 : 1;

  return {
    accuracy,
    lenient,
    stars,
    words,
    phones: detail,
    utteranceGop: gop.utteranceGop,
    // 音素は一応ぜんぶ出ているのに、間に余分な音が挟まっている状態。
    // 日本語話者の典型なので、星とは別に一言出す価値がある。
    extraSound: gop.utteranceGop < EXTRA_SOUND_CUT && mean > 0.55,
    fluency: measureFluency(gop.phones.slice(gop.from ?? 0)),
    empty: heard.length === 0,
    // 星なしのとき、声が無かったのか別のことを言ったのか。
    // 自由デコードの音素数が この2つを完全に分ける（無音 0個 / それ以外 最小6個）。
    zeroReason: stars > 0 ? null : heard.length === 0 ? 'silent' : 'different',
    heard: heard.map((h) => h.tok),
  };
}

/**
 * 流暢さ。音素単位の詳しい評価は要らないので、
 * 「間が空きすぎていないか」と「速さが極端でないか」の2点だけ見る。
 * 強制アライメントで得た音素の区間をそのまま使う。
 */
function measureFluency(phones) {
  const said = phones.filter((p) => !p.squeezed);
  if (said.length < 2) return { level: 'unknown', pauses: 0, rate: 0, coverage: 0 };

  const span = Math.max(said[said.length - 1].end - said[0].start, 0.01);
  let pauses = 0, longest = 0;
  for (let i = 1; i < said.length; i++) {
    const gap = said[i].start - said[i - 1].end;
    if (gap > 0.28) pauses++;
    if (gap > longest) longest = gap;
  }

  const rate = said.length / span; // 音素/秒
  // 小学生の音読は 8-14 音素/秒あたり。外れるほど下げる。
  const rateOk = rate >= 6 && rate <= 16;
  let level = pauses === 0 && rateOk ? 'smooth' : pauses <= 2 && rate >= 4 ? 'ok' : 'choppy';

  // 言えている音が足りないのに「すらすら」と出るのは体験として嘘になる。
  const coverage = said.length / Math.max(phones.length, 1);
  if (coverage < 0.8 && level === 'smooth') level = 'ok';

  return { level, pauses, longest, rate, span, coverage };
}

const clamp01 = (x) => Math.max(0, Math.min(1, x));
