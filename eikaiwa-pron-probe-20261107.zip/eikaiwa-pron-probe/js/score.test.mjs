// node --test js/score.test.mjs
//
// 強制アライメントと採点の確認。モデルを動かさずに済むよう、
// 対数事後確率の行列を手で組み立てて食わせる。

import test from 'node:test';
import assert from 'node:assert/strict';
import { forcedAlign, gopScore } from './gop.js';
import { scoreUtterance } from './score.js';

// 圧縮語彙: 0 が blank
const TOKENS = ['<pad>', 'k', 'æ', 't', 'i', 's'];
const INDEX = new Map(TOKENS.map((t, i) => [t, i]));
const K = TOKENS.length;

/**
 * 各フレームで「この音素が確率 p、残りは均等」という行列を作る。
 * frames: [[音素, 確率], ...]
 */
function makeLogp(frames) {
  const T = frames.length;
  const logp = new Float32Array(T * K);
  frames.forEach(([tok, p], t) => {
    const hot = INDEX.get(tok);
    const rest = (1 - p) / (K - 1);
    for (let k = 0; k < K; k++) logp[t * K + k] = Math.log(k === hot ? p : rest);
  });
  return { logp, T, K, blank: 0, tokens: TOKENS, index: INDEX, frameSec: 0.02 };
}

const SENTENCE = {
  text: 'cat',
  words: [{ display: 'cat', phones: ['k', 'æ', 't'] }],
  phones: ['k', 'æ', 't'],
};

// --- 強制アライメント ---

test('きれいに読めた音声は、音素が順番どおりに割り当たる', () => {
  const out = makeLogp([['k', .9], ['k', .9], ['æ', .9], ['æ', .9], ['t', .9], ['t', .9]]);
  const { path } = forcedAlign(out.logp, out.T, out.K, [1, 2, 3], 0);
  // 拡張系列は [b,k,b,æ,b,t,b]。音素は奇数位置。
  assert.deepEqual([...path], [1, 1, 3, 3, 5, 5]);
});

test('あいだに blank が入っても順番は保たれる', () => {
  const out = makeLogp([['k', .9], ['<pad>', .9], ['æ', .9], ['<pad>', .9], ['t', .9]]);
  const { path } = forcedAlign(out.logp, out.T, out.K, [1, 2, 3], 0);
  assert.deepEqual([...path].filter((s) => s % 2 === 1), [1, 3, 5]);
});

// --- GOP ---

test('正しく言えていれば GOP は 0 付近', () => {
  const out = makeLogp([['k', .9], ['k', .9], ['æ', .9], ['æ', .9], ['t', .9], ['t', .9]]);
  const g = gopScore(out, SENTENCE.phones);
  for (const p of g.phones) assert.ok(p.gop > -0.01, `${p.tok} gop=${p.gop}`);
  assert.ok(g.utteranceGop > -0.01);
});

test('別の音になっていれば、その音素だけ GOP が下がる', () => {
  // 真ん中を æ ではなく i で言ってしまった。
  // 音素の切れ目に blank を挟んでおかないと、誤った区間が隣の音素へ食い込み、
  // 前後の GOP まで巻き込まれる（強制アライメントとして正しい挙動）。
  const out = makeLogp([
    ['k', .9], ['k', .9], ['<pad>', .9],
    ['i', .9], ['i', .9], ['<pad>', .9],
    ['t', .9], ['t', .9],
  ]);
  const g = gopScore(out, SENTENCE.phones);
  const [k, ae, t] = g.phones;
  assert.ok(k.gop > -0.01, 'k は無事');
  assert.ok(t.gop > -0.01, 't は無事');
  assert.ok(ae.gop < -1, `æ が下がる gop=${ae.gop}`);
  assert.equal(ae.heard, 'i', '何に聞こえたかが出る');
});

test('余分な音を挟むと発話GOP が開く', () => {
  const clean = gopScore(makeLogp([['k', .9], ['æ', .9], ['t', .9]]), SENTENCE.phones);
  // k と æ のあいだに、正解にない s がはっきり入っている
  const extra = gopScore(
    makeLogp([['k', .9], ['s', .9], ['s', .9], ['æ', .9], ['t', .9]]),
    SENTENCE.phones
  );
  assert.ok(extra.utteranceGop < clean.utteranceGop - 0.3,
    `clean=${clean.utteranceGop.toFixed(2)} extra=${extra.utteranceGop.toFixed(2)}`);
});

test('フレームが足りなければ squeezed になる', () => {
  const out = makeLogp([['k', .9], ['æ', .9]]); // 音素3つに対して2フレーム
  const g = gopScore(out, SENTENCE.phones);
  assert.ok(g.phones.some((p) => p.squeezed));
});

// --- 採点 ---

const clean = () => makeLogp([['k', .9], ['k', .9], ['æ', .9], ['æ', .9], ['t', .9], ['t', .9]]);

test('正しく読めたら星3つ、単語は good', () => {
  const s = scoreUtterance(SENTENCE, gopScore(clean(), SENTENCE.phones), [{ tok: 'k' }]);
  assert.equal(s.stars, 3);
  assert.ok(s.accuracy > 0.95, `acc=${s.accuracy}`);
  assert.deepEqual(s.words.map((w) => w.level), ['good']);
  assert.deepEqual(s.phones.map((p) => p.level), ['match', 'match', 'match']);
});

test('音が違えば、その音素のチップだけ色が変わる', () => {
  const out = makeLogp([
    ['k', .9], ['k', .9], ['<pad>', .9],
    ['i', .95], ['i', .95], ['<pad>', .9],
    ['t', .9], ['t', .9],
  ]);
  const s = scoreUtterance(SENTENCE, gopScore(out, SENTENCE.phones), [{ tok: 'k' }]);
  assert.equal(s.phones[0].level, 'match');
  assert.equal(s.phones[2].level, 'match');
  assert.notEqual(s.phones[1].level, 'match');
  assert.equal(s.phones[1].heard, 'i');
});

test('声が聞こえないときは星なしにする', () => {
  const out = makeLogp([['<pad>', .95], ['<pad>', .95], ['<pad>', .95]]);
  const s = scoreUtterance(SENTENCE, gopScore(out, SENTENCE.phones), []);
  assert.equal(s.stars, 0);
  assert.equal(s.empty, true);
  assert.equal(s.zeroReason, 'silent');
});

test('全く違うことを言っていると星なし。理由は声なしと区別する', () => {
  // 正解は k æ t。まったく別の音を同じ長さだけ出す。
  const out = makeLogp([['s', .95], ['s', .95], ['uː', .95], ['uː', .95], ['p', .95], ['p', .95]]);
  const s = scoreUtterance(SENTENCE, gopScore(out, SENTENCE.phones), [{ tok: 's' }]);
  assert.equal(s.stars, 0);
  assert.equal(s.empty, false);
  assert.equal(s.zeroReason, 'different');
});

test('ちゃんと読めていれば星は残る。zeroReason も立たない', () => {
  const out = makeLogp([['k', .95], ['k', .95], ['æ', .95], ['æ', .95], ['t', .95], ['t', .95]]);
  const s = scoreUtterance(SENTENCE, gopScore(out, SENTENCE.phones), [{ tok: 'k' }]);
  assert.ok(s.stars >= 1, '正しく読んだのに星なしにしてはいけない');
  assert.equal(s.zeroReason, null);
});

test('余分な音が入っていると extraSound が立つ', () => {
  const many = [['k', .95], ['k', .95], ['æ', .95], ['æ', .95], ['t', .95], ['t', .95]];
  const withExtra = [...many.slice(0, 2), ['s', .95], ['s', .95], ['s', .95], ...many.slice(2)];
  const a = scoreUtterance(SENTENCE, gopScore(makeLogp(many), SENTENCE.phones), [{ tok: 'k' }]);
  const b = scoreUtterance(SENTENCE, gopScore(makeLogp(withExtra), SENTENCE.phones), [{ tok: 'k' }]);
  assert.equal(a.extraSound, false);
  assert.equal(b.extraSound, true);
  assert.ok(b.accuracy < a.accuracy, '素点も下がる');
});

test('音素の数とチップの数は必ず一致する', () => {
  const s = scoreUtterance(SENTENCE, gopScore(clean(), SENTENCE.phones), []);
  assert.equal(s.phones.length, SENTENCE.phones.length);
  assert.equal(s.words[0].detail.length, 3);
});
