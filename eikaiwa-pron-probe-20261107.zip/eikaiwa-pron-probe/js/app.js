// 画面の組み立てと進行。
//
// URL パラメータで構成を差し替えられる（計測用）:
//   ?device=wasm|webgpu   実行バックエンド
//   ?dtype=q8|q4|q4f16|fp32
//   ?threads=1            WASM のスレッド数を固定
//   ?metrics=1            計測パネルを開いた状態で起動

import { bootEngine, loadModelAudio, modelRows, bindModelPicker } from './boot.js';
import { gopScore } from './gop.js';
import { scoreUtterance } from './score.js';
import { Recorder, decodeFile, toWav, DEFAULT_CONSTRAINTS } from './audio.js';

/** 同梱のお手本音声。起動時の自己検証にも使う。 */
const MODEL_AUDIO = (i) => `audio/model/s${i + 1}.m4a`;
const params = new URLSearchParams(location.search);

const $ = (id) => document.getElementById(id);
const el = {
  boot: $('boot'), bootMsg: $('boot-msg'), bootFill: $('boot-fill'),
  bootSub: $('boot-sub'), bootRetry: $('boot-retry'),
  app: $('app'), qIndex: $('q-index'), qEn: $('q-en'), qJa: $('q-ja'),
  listen: $('btn-listen'), rec: $('btn-rec'), micLabel: $('mic-label'),
  meter: $('meter'), bars: document.querySelectorAll('.bars i'),
  promptCard: document.querySelector('.prompt-card'),
  result: $('result'), stars: $('stars'), verdict: $('verdict'), words: $('words'),
  fluencyFill: $('fluency-fill'), fluencyText: $('fluency-text'),
  again: $('btn-again'), next: $('btn-next'),
  metrics: $('metrics'), metricsBody: $('metrics-body'), metricsToggle: $('metrics-toggle'),
  bench: $('btn-bench'), benchOut: $('bench-out'), drop: $('drop'), hint: $('hint'),
  saveRec: $('btn-save-rec'), selfTest: $('btn-self-test'),
};

const state = {
  sentences: [], at: 0, engine: null, recorder: null, busy: false,
  lastAudio: null, metrics: {}, lastScore: null, lastStats: null, inWorker: false,
  recording: false,
};

// タブが見えなくなったらマイクを手放す。録音インジケータを点けっぱなしにしない。
addEventListener('visibilitychange', () => {
  if (document.hidden && state.recorder && !state.recording) state.recorder.release();
});

// ---------- 起動 ----------

boot().catch((err) => {
  console.error(err);
  el.bootMsg.textContent = 'じゅんび できませんでした';
  el.bootSub.textContent = String(err.message || err);
  el.bootRetry.hidden = false;
});

el.bootRetry.addEventListener('click', () => location.reload());

async function boot() {
  state.sentences = await fetch('data/reference.json').then((r) => r.json());

  el.bootFill.classList.add('indeterminate');
  const { engine, metrics } = await bootEngine({
    params,
    onStatus: (msg, sub) => {
      el.bootMsg.textContent = msg;
      if (sub) el.bootSub.textContent = sub;
    },
    onProgress: ({ pct, loaded, total }) => {
      el.bootFill.classList.remove('indeterminate');
      el.bootFill.style.width = pct.toFixed(1) + '%';
      el.bootMsg.textContent = `よみこみ中… ${Math.round(pct)}%`;
      el.bootSub.textContent = `${fmtMB(loaded)} / ${fmtMB(total)}`;
    },
  });
  state.engine = engine;
  state.inWorker = metrics.inWorker;
  state.metrics = metrics;
  renderMetrics();

  el.bootFill.classList.remove('indeterminate');
  el.bootFill.style.width = '100%';
  el.bootMsg.textContent = 'じゅんび できました！';
  await sleep(420);
  el.boot.classList.add('done');
  el.app.hidden = false;
  setTimeout(() => { el.boot.hidden = true; }, 500);

  if (params.get('metrics') === '1') el.metrics.hidden = false;
  show(0);

  // 自動計測から叩くための口。デモ時は生えない。
  if (params.get('probe') === '1') {
    self.__probe = {
      metrics: () => state.metrics,
      show,
      async run(samples, sentenceIndex = 0) {
        show(sentenceIndex);
        await evaluate(Float32Array.from(samples));
        return { metrics: state.metrics, score: state.lastScore, hyp: state.lastScore.hyp };
      },
      lastScore: () => state.lastScore,
      // cross-origin isolated なページでだけ使える。WASM のヒープも含む合計が取れる。
      async memory() {
        if (!performance.measureUserAgentSpecificMemory) return null;
        return performance.measureUserAgentSpecificMemory();
      },
      async time(samples, n = 10) {
        const a = Float32Array.from(samples);
        await state.engine.recognize(a.subarray(0, 16000));
        const ts = [];
        for (let i = 0; i < n; i++) ts.push((await state.engine.recognize(a)).ms);
        return { times: ts, sec: a.length / 16000 };
      },
    };
  }
  self.dispatchEvent(new Event('probe-ready'));
}


// ---------- 出題 ----------

function show(i) {
  state.at = i;
  const s = state.sentences[i];
  el.qIndex.textContent = `${i + 1} / ${state.sentences.length}`;
  el.qEn.textContent = s.text;
  el.qJa.textContent = s.ja;
  el.result.hidden = true;
  el.again.hidden = true;
  el.micLabel.textContent = 'ボタンを おして よんでみよう';
  el.next.textContent = i === state.sentences.length - 1 ? 'さいしょに もどる' : 'つぎの もんだい →';
}

el.next.addEventListener('click', () => show((state.at + 1) % state.sentences.length));
el.again.addEventListener('click', () => { el.result.hidden = true; el.again.hidden = true; });

// 「おてほん」は同梱した音声を鳴らす。
//
// 端末の speechSynthesis に任せると、ブラウザが選ぶ既定の声しだいで音が変わる。
// 実測では声によって同じ文の素点が 0.08〜0.98 まで振れた。macOS/Chrome の既定は
// "Aaron" で、同系列の Eddy/Flo は 0.45〜0.49（星2つ）。お手本を聞かせても
// 星3つが出ない、という形で表に出る。詳細は docs/NOTES.md。
//
// 音声ファイルが無い環境のために speechSynthesis へのフォールバックは残すが、
// その場合も声は選ぶ。

/** 品質が確かめられている声。上から順に探す。 */
const PREFERRED_VOICES = [
  'Samantha', 'Google US English', 'Microsoft Zira', 'Microsoft Aria',
  'Alex', 'Ava', 'Allison', 'Susan', 'Victoria', 'Karen', 'Daniel',
];
/** 読み上げ用ではない声。選ばれると音声にならない。 */
const NOVELTY_VOICES = /albert|bad news|bahh|bells|boing|bubbles|cellos|good news|jester|organ|superstar|trinoids|whisper|wobble|zarvox|hysterical|deranged|bells/i;

function pickVoice() {
  const voices = speechSynthesis.getVoices();
  for (const name of PREFERRED_VOICES) {
    const hit = voices.find((v) => v.name.startsWith(name));
    if (hit) return hit;
  }
  return voices.find((v) => v.lang.startsWith('en') && !NOVELTY_VOICES.test(v.name)) || null;
}

// 要素は1つを使い回す。クリックのたびに new Audio すると、
// 読み込み中に次の再生が始まって AbortError になる。
const modelPlayer = new Audio();
modelPlayer.preload = 'auto';
let modelAudioBroken = false;

// 読み込みそのものに失敗したときだけ TTS に落とす。
// 再生が中断された（音声出力が無い等）のは読み込みの失敗ではないので、
// ここで落とすと二重に喋ることになる。
modelPlayer.addEventListener('error', () => {
  modelAudioBroken = true;
  speakWithBestVoice(state.sentences[state.at].text);
});

el.listen.addEventListener('click', () => {
  if (!modelAudioBroken) {
    const src = MODEL_AUDIO(state.at);
    if (!modelPlayer.src.endsWith(src)) modelPlayer.src = src;
    modelPlayer.currentTime = 0;
    modelPlayer.play().catch(() => { /* 出力側の都合。error イベントで拾う */ });
    return;
  }
  speakWithBestVoice(state.sentences[state.at].text);
});

function speakWithBestVoice(text) {
  if (!('speechSynthesis' in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  const voice = pickVoice();
  if (voice) u.voice = voice;
  u.lang = 'en-US';
  u.rate = 0.85;
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
}

// ---------- 録音 ----------

el.rec.addEventListener('click', async () => {
  if (state.busy) return;
  if (state.recording) return stopAndScore();

  try {
    // マイクは開いたまま保持する。開き直すと毎回 800ms 前後かかり、
    // 「ボタンを押しても始まらない」体感になる。
    if (!state.recorder) {
      const flag = (k) => (params.has(k) ? params.get(k) === '1' : null);
      const all = params.get('aec') === '1';
      state.recorder = new Recorder({
        ...DEFAULT_CONSTRAINTS,
        ...(all ? { echoCancellation: true, noiseSuppression: true, autoGainControl: true } : {}),
        ...(flag('ec') !== null ? { echoCancellation: flag('ec') } : {}),
        ...(flag('ns') !== null ? { noiseSuppression: flag('ns') } : {}),
        ...(flag('agc') !== null ? { autoGainControl: flag('agc') } : {}),
      }, { forceRate: params.get('rate') !== 'native' });
      state.recorder.onOverrun = () => stopAndScore();
    }
    if (!state.recorder.isOpen) el.micLabel.textContent = 'マイクを じゅんびちゅう…';
    await state.recorder.open();
    state.recorder.start();
  } catch (err) {
    el.micLabel.textContent = 'マイクが つかえません';
    console.error(err);
    return;
  }
  state.recording = true;
  el.rec.classList.add('rec');
  el.micLabel.textContent = 'きいています… おわったら もういちど おしてね';
  el.meter.hidden = false;
  el.result.hidden = true;
  drawMeter();
});

let meterRAF = 0;
function drawMeter() {
  const r = state.recorder;
  if (!r || !r.recording) return cancelAnimationFrame(meterRAF);
  const level = r.peek();
  const n = el.bars.length;
  el.bars.forEach((bar, i) => {
    // 中央が高くなるよう重みを付けると、音の大小が直感的に読める
    const w = 1 - Math.abs(i - (n - 1) / 2) / (n / 2);
    const h = 6 + level * 38 * (0.35 + 0.65 * w) * (0.75 + Math.random() * 0.5);
    bar.style.height = Math.min(44, h).toFixed(0) + 'px';
  });
  meterRAF = requestAnimationFrame(drawMeter);
}

async function stopAndScore() {
  const rec = state.recorder;
  state.recording = false;
  el.rec.classList.remove('rec');
  el.meter.hidden = true;
  cancelAnimationFrame(meterRAF);

  // 「かんがえ中」は停止を押した瞬間に出す。
  // 録音の取り出し（リサンプルを含む）にも時間がかかるので、
  // そのあいだ無防備にしておくと、もう一度押せてしまう。
  enterBusy();
  try {
    const { audio, stats } = await rec.stop();
    await evaluate(audio, stats);
  } catch (err) {
    console.error(err);
    el.micLabel.textContent = 'うまく ろくおん できませんでした';
    await rec.release().catch(() => {});
  } finally {
    exitBusy();
  }
}

// 採点中かどうかは複数の入口（マイク・ドロップ・自動計測）から立つので、
// 深さで数える。内側が終わっただけで見た目を戻さない。
let busyDepth = 0;
function enterBusy() {
  if (busyDepth++ === 0) { state.busy = true; setThinking(true); }
}
function exitBusy() {
  if (--busyDepth === 0) { state.busy = false; setThinking(false); }
  if (busyDepth < 0) busyDepth = 0;
}

async function evaluate(audio, stats = null) {
  state.lastStats = stats;
  if (stats?.startup) self.__lastStartup = stats.startup;
  if (stats) renderMetrics();
  if (audio.length < 16000 * 0.25) {
    el.micLabel.textContent = 'こえが きこえなかったよ。もういちど！';
    return;
  }
  state.lastAudio = audio;
  // 採点中に問題を切り替えられると、古い結果が新しい問題の画面に出る。
  const asked = state.at;
  enterBusy();

  try {
    // 表示を確実に描いてから推論へ入る。Worker に逃がしていても、
    // 直後に重い処理が続くと状態が見えないまま終わることがある。
    await nextPaint();
    const out = await state.engine.recognize(audio);
    state.metrics.lastMs = Math.round(out.ms);
    state.metrics.lastSec = +out.audioSec.toFixed(2);
    state.metrics.rtf = +(out.ms / 1000 / out.audioSec).toFixed(3);
    const scored = judge(state.sentences[asked], out);
    state.lastScore = { ...scored, hyp: out.phones.map((p) => p.tok) };
    // 採点まで終えてから描く。先に呼ぶと「採点」の欄が1つ前の発話のままになる。
    renderMetrics();
    if (state.at === asked) renderResult(scored);
  } catch (err) {
    console.error(err);
    el.micLabel.textContent = 'うまく きけませんでした';
  } finally {
    exitBusy();
  }
}

/**
 * 採点中の見た目。WASM だと1発話に1〜3秒かかるので、
 * 「押せない」ことと「動いている」ことの両方が伝わる状態にする。
 */
function setThinking(on) {
  el.rec.disabled = on;
  el.rec.classList.toggle('thinking', on);
  el.promptCard.classList.toggle('thinking', on);
  el.rec.setAttribute('aria-busy', String(on));
  // 採点が終わるまでは進めない。押せてしまうと結果の出しどころが無くなる。
  el.next.disabled = on;
  el.again.disabled = on;
  el.listen.disabled = on;
  if (on) el.micLabel.textContent = 'いま きいているよ…';
}

/**
 * 認識結果を採点に通す。
 * 正解音素列を CTC で強制アライメントして音素ごとの GOP を出し（js/gop.js）、
 * それを星と色へ落とす（js/score.js）。自由デコードの結果は
 * 「実際にはこう聞こえた」の表示にだけ使う。
 */
function judge(sentence, out) {
  return scoreUtterance(sentence, gopScore(out, sentence.phones, sentence.alts), out.phones);
}

// ---------- 結果表示 ----------

const VERDICT = {
  3: ['かんぺき！', 'すごい！', 'ばっちり！'],
  2: ['いいね！', 'おしい！', 'あと ちょっと！'],
  1: ['ナイス チャレンジ！', 'よく よめたね！'],
  // 星なし。責める言い方にはしない。
  0: ['もういちど チャレンジ！'],
};

function renderResult(s) {
  el.micLabel.textContent = 'もういちど よんでも いいよ';
  el.result.hidden = false;
  el.again.hidden = false;

  el.stars.innerHTML = '';
  for (let i = 0; i < 3; i++) {
    const span = document.createElement('span');
    span.textContent = i < s.stars ? '⭐️' : '☆';
    span.style.opacity = i < s.stars ? '1' : '.28';
    el.stars.append(span);
  }
  el.verdict.textContent = pick(VERDICT[s.stars]);
  el.verdict.classList.remove('zero');

  el.words.innerHTML = '';
  for (const w of s.words) {
    const box = document.createElement('div');
    box.className = `word ${w.level}`;
    const label = document.createElement('span');
    label.className = 'word-text';
    // 句読点は文のカードで見えているので、単語チップでは落とす
    label.textContent = w.display.replace(/[.,!?]+$/, '');
    box.append(label);

    const row = document.createElement('div');
    row.className = 'phones';
    for (const d of w.detail) row.append(phoneChip(d));
    box.append(row);
    el.words.append(box);
  }

  const f = s.fluency;
  const pct = { smooth: 100, ok: 62, choppy: 28, unknown: 15 }[f.level];
  el.fluencyFill.style.width = pct + '%';
  el.fluencyText.textContent = { smooth: 'すらすら', ok: 'まあまあ', choppy: 'ゆっくり', unknown: '—' }[f.level];

  // 星なし。聞き取れなかったか、別のことを言っている。
  // 理由で言うことを変える。「大きな声で」と「問題文を読んで」では
  // 次にやることがまるで違う。
  if (s.stars === 0) {
    el.verdict.classList.add('zero');
    el.hint.hidden = false;
    el.hint.textContent = s.zeroReason === 'silent'
      ? 'マイクに ちかづいて、もういちど いってみよう'
      : 'もんだいの えいぶんを よんでみよう';
    return;
  }

  // 録音そのものに問題があるときは、発音の話より先にそちらを伝える。
  const st = state.lastStats;
  if (st && st.cutOff) {
    el.hint.hidden = false;
    el.hint.textContent = 'さいごまで いえたかな？ ボタンは よみおわってから おしてね';
    return;
  }
  if (st && st.snrDb < 12) {
    el.hint.hidden = false;
    el.hint.textContent = 'まわりが すこし うるさいみたい';
    return;
  }

  // カタカナ英語（音のあいだに母音が入る）は星とは別に一言出す。
  // 日本語話者の典型で、どこを直せばいいかが星だけでは伝わらない。
  el.hint.hidden = !s.extraSound;
  if (s.extraSound) el.hint.textContent = 'えいごの おとだけで いってみよう';

}

function phoneChip(d) {
  const slot = document.createElement('span');
  slot.className = 'ph-slot';

  const chip = document.createElement('span');
  chip.className = `ph ${d.level}`;
  chip.textContent = d.ref;
  slot.append(chip);

  // 別の音に聞こえたときは、正解チップの下に小さく並べる。
  // チップの中に入れると高さが揃わず、行がガタつく。
  const heard = document.createElement('span');
  heard.className = 'ph-heard';
  heard.textContent = d.level !== 'match' && d.heard ? d.heard : '';
  slot.append(heard);

  const label = {
    match: 'ばっちり', near: 'おしい', sub: 'ちがう音に きこえたよ', del: 'いえてなかった',
  }[d.level];
  slot.title = `${d.ref} — ${label}${d.heard ? `（${d.heard} に近い）` : ''}`;
  return slot;
}

// ---------- 計測パネル ----------

el.metricsToggle.addEventListener('click', () => { el.metrics.hidden = !el.metrics.hidden; });
bindModelPicker(el.metricsBody);

function renderMetrics() {
  const m = state.metrics;
  const rows = [
    ...modelRows(m),
    ['backend', `${m.device} / ${m.dtype}`],
    ['モデル取得元', m.host || '—'],
    ['自己検証', m.verify
      ? `${m.verify.ok ? 'OK' : 'NG'} (確信度 ${m.verify.meanTopProb?.toFixed(2) ?? '—'})${m.verify.fellBackFrom ? ' ←WebGPUから退避' : ''}`
      : '—'],
    ['wasm threads', m.device === 'wasm' ? `${m.threads}${m.crossOriginIsolated ? '' : ' (非分離)'}` : '—'],
    ['推論スレッド', m.inWorker ? 'Worker' : 'メイン（画面が固まる）'],
    ['初回/2回目', m.cached ? 'キャッシュ有' : '初回DL'],
    ['DL量', m.bytes ? fmtMB(m.bytes) : '0 (キャッシュ)'],
    ['ロード', `${(m.loadMs / 1000).toFixed(1)}s`],
    ['直近の推論', m.lastMs != null ? `${m.lastMs}ms / ${m.lastSec}s` : '—'],
    ['RTF', m.rtf != null ? m.rtf.toFixed(3) : '—'],
  ];

  // 録音そのものの品質。点が出ない原因が発音なのか録音環境なのかは、
  // これを見ないと切り分けられない。
  const st = state.lastStats;
  if (st) {
    rows.push(
      ['— 録音 —', ''],
      ['S/N', `${st.snrDb.toFixed(1)} dB`],
      ['声のレベル', db(st.speechRms)],
      ['暗騒音', db(st.noiseRms)],
      ['ピーク', `${(st.peak * 100).toFixed(0)}%`],
      ['クリップ', `${(st.clippedRatio * 100).toFixed(2)}%`],
      ['長さ', `${st.rawSec?.toFixed(2)}s → ${st.trimmedSec?.toFixed(2)}s`],
      ...(st.settings ? [
        ['— マイクの実設定 —', ''],
        ['デバイス', st.settings.label || '—'],
        ['エコー除去', fmtOn(st.settings.echoCancellation)],
        ['ノイズ抑制', fmtOn(st.settings.noiseSuppression)],
        ['自動ゲイン', fmtOn(st.settings.autoGainControl)],
        ['レート/ch', `${st.settings.sampleRate ?? '—'} Hz / ${st.settings.channelCount ?? '—'}`],
      ] : []),
      ...(st.startup ? [
        ['— マイク起動 —', ''],
        ['getUserMedia', st.startup.reused ? '— (再利用)' : `${st.startup.getUserMedia} ms`],
        ['AudioContext', st.startup.reused ? '—' : `${st.startup.audioContext} ms (${st.startup.rate} Hz)`],
        ['AudioWorklet', `${st.startup.worklet} ms`],
        ['起動 合計', `${st.startup.total} ms${st.startup.reused ? '（開いたまま再利用）' : ''}`],
      ] : []),
      ['途中切れ', st.cutOff ? 'あり' : 'なし'],
    );
  }
  const sc = state.lastScore;
  if (sc) {
    rows.push(
      ['— 採点 —', ''],
      ['素点', sc.accuracy.toFixed(3)],
      ['発話GOP', sc.utteranceGop.toFixed(3)],
      ['きこえた音', sc.hyp.join(' ') || '（なし）'],
    );
  }
  el.metricsBody.innerHTML = rows
    .map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('');
}

// マイクを通さず、同梱のお手本音声をそのままエンジンへ入れる。
// ここで星3つが出るなら、エンジンと採点は正常で、問題はマイク経路のほう。
el.selfTest.addEventListener('click', async () => {
  el.selfTest.disabled = true;
  el.benchOut.textContent = '自己診断中…';
  const lines = [];
  try {
    for (let i = 0; i < state.sentences.length; i++) {
      const out = await state.engine.recognize(await loadModelAudio(MODEL_AUDIO(i)));
      const s = judge(state.sentences[i], out);
      lines.push(`${i + 1}. ${'★'.repeat(s.stars)}${'☆'.repeat(3 - s.stars)} ${s.accuracy.toFixed(2)}`);
      el.benchOut.textContent = lines.join('\n');
    }
    const ok = lines.filter((l) => l.includes('★★★')).length;
    lines.push(ok === state.sentences.length
      ? 'エンジンは正常。点が出ないならマイク経路の問題。'
      : `星3つ ${ok}/${state.sentences.length}。エンジン側に問題あり。`);
    el.benchOut.textContent = lines.join('\n');
  } catch (err) {
    el.benchOut.textContent = `自己診断に失敗: ${err.message}`;
  } finally {
    el.selfTest.disabled = false;
  }
});

el.saveRec.addEventListener('click', () => {
  if (!state.lastAudio) { el.benchOut.textContent = 'さきに1回 録音してください'; return; }
  const url = URL.createObjectURL(toWav(state.lastAudio));
  const a = document.createElement('a');
  a.href = url;
  a.download = `rec-${state.at + 1}-${Date.now()}.wav`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

el.bench.addEventListener('click', async () => {
  if (!state.lastAudio) { el.benchOut.textContent = 'さきに1回 録音してください'; return; }
  el.bench.disabled = true;
  el.benchOut.textContent = '計測中…';
  const times = [];
  for (let i = 0; i < 10; i++) {
    const r = await state.engine.recognize(state.lastAudio);
    times.push(r.ms);
    el.benchOut.textContent = `計測中… ${i + 1}/10`;
  }
  times.sort((a, b) => a - b);
  const sec = state.lastAudio.length / 16000;
  el.benchOut.textContent = [
    `n=10  audio=${sec.toFixed(2)}s`,
    `min ${times[0].toFixed(0)}ms  median ${times[5].toFixed(0)}ms  max ${times[9].toFixed(0)}ms`,
    `RTF(median) ${(times[5] / 1000 / sec).toFixed(3)}`,
  ].join('\n');
  el.bench.disabled = false;
});

// ---------- ファイルドロップ（検証用） ----------

let dragDepth = 0;
addEventListener('dragenter', (e) => { e.preventDefault(); if (++dragDepth === 1) el.drop.hidden = false; });
addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; el.drop.hidden = true; } });
addEventListener('dragover', (e) => e.preventDefault());
addEventListener('drop', async (e) => {
  e.preventDefault();
  dragDepth = 0;
  el.drop.hidden = true;
  const file = e.dataTransfer.files[0];
  if (!file) return;
  try {
    const { audio, stats } = await decodeFile(file);
    await evaluate(audio, stats);
  } catch (err) {
    console.error(err);
    el.micLabel.textContent = 'この ファイルは よめませんでした';
  }
});

// ---------- 小物 ----------

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** 変更した見た目が画面に出るまで待つ */
const nextPaint = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const fmtMB = (b) => `${(b / 1048576).toFixed(1)} MB`;
const db = (x) => `${(20 * Math.log10(Math.max(x, 1e-7))).toFixed(0)} dBFS`;
const fmtOn = (v) => (v === undefined ? '不明' : v ? 'ON' : 'OFF');
