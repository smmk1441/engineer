// node --test js/audio.test.mjs
//
// 録音の切り出しまわり。ここが壊れると「ボタンを押しても何も起きない」
// という形で出て、原因が分かりにくい。

import test from 'node:test';
import assert from 'node:assert/strict';
import { analyse, trimSilence } from './audio.js';

const RATE = 16000;

/** 無音 -> 声 -> 無音 の録音を作る。noise は全区間に乗る暗騒音。 */
function make({ speech = 0.05, noise = 0.001, leadSec = 0.5, speechSec = 1.2, tailSec = 0.5 }) {
  const n = Math.round((leadSec + speechSec + tailSec) * RATE);
  const from = Math.round(leadSec * RATE);
  const to = Math.round((leadSec + speechSec) * RATE);
  const a = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    a[i] = (Math.random() * 2 - 1) * noise;
    // 声の部分は正弦波で代用（レベルだけ見ているので中身は問わない）
    if (i >= from && i < to) a[i] += Math.sin(i * 0.1) * speech;
  }
  return a;
}

test('前後の無音が落ちる', () => {
  const a = make({});
  const st = analyse(a);
  const t = trimSilence(a, st.threshold);
  assert.ok(t.length > 0.9 * 1.2 * RATE, `短すぎる ${t.length / RATE}s`);
  assert.ok(t.length < 1.8 * RATE, `削れていない ${t.length / RATE}s`);
});

test('暗騒音が大きくても、しきい値が声を超えない', () => {
  // S/N が 6dB しかない録音。noise*2.5 が speech を追い越す条件。
  const a = make({ speech: 0.02, noise: 0.01 });
  const st = analyse(a);
  assert.ok(st.threshold < st.speechRms, `しきい値 ${st.threshold} >= 声 ${st.speechRms}`);
  assert.ok(trimSilence(a, st.threshold).length > 0, '全部消えてしまった');
});

test('静かな部屋では暗騒音が正しく分かれる', () => {
  const st = analyse(make({ speech: 0.05, noise: 0.0005 }));
  assert.ok(st.snrDb > 20, `S/N が低すぎる ${st.snrDb}`);
  assert.ok(st.noiseRms < st.speechRms);
});

test('うるさい部屋は S/N が低く出る', () => {
  const st = analyse(make({ speech: 0.03, noise: 0.01 }));
  assert.ok(st.snrDb < 20, `S/N が高すぎる ${st.snrDb}`);
});

test('本当の無音は空になる', () => {
  const a = new Float32Array(RATE);
  const st = analyse(a);
  assert.equal(trimSilence(a, st.threshold).length, 0);
});

test('クリップを数える', () => {
  const a = make({ speech: 0.05 });
  for (let i = 0; i < 100; i++) a[i] = 1;
  assert.ok(analyse(a).clippedRatio > 0);
  assert.equal(analyse(make({})).clippedRatio, 0);
});

test('1サンプルも録れていなくても落ちない', async () => {
  // prepare は内部関数なので、analyse/trimSilence の側で境界を確認する
  const empty = new Float32Array(0);
  const st = analyse(empty);
  assert.equal(st.frames, 0);
  assert.equal(trimSilence(empty, st.threshold).length, 0);
});
