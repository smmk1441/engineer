// 子どもの声に対して、いまの教師モデルがどれだけ耐えるかを測る。
//
//   node bench/exp-child.mjs
//
// 小学生の音声データがまだ無いので、成人音声を子ども寄りに変形して代用する。
// 子どもの声が成人と違う主因は **声道が短いこと**で、フォルマント（音色を決める
// 共鳴周波数）が 20〜25% 高くなる。基本周波数も高い。
//
// ここでは2通りの変形を試す:
//
//   VTLP     周波数軸だけを伸ばす。フォルマントは上がるが、長さと基本周波数は変わらない。
//            「声道だけ短くした」に相当する。子どもらしさの主成分
//   再サンプル 速く再生する。フォルマントも基本周波数も上がり、長さも縮む。
//            粗いが、実際の子どもの声に近い変化も含む
//
// これは代用であって、実際の子どもの声ではない。
// **急落するなら実データ収集が必須**という判断材料にするためのもの。

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs';
import path from 'node:path';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { scoreUtterance } from '../js/score.js';
import { readWav } from './wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
transformers.env.cacheDir = path.join(ROOT, '.hfcache');
const RATE = 16000;

// --- 変形 ---

/** 実数FFT（素朴な実装。長さは2のべき乗） */
function fft(re, im) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = -2 * Math.PI / len;
    const wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1, ci = 0;
      for (let k = 0; k < len / 2; k++) {
        const ur = re[i + k], ui = im[i + k];
        const vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci;
        const vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
        re[i + k] = ur + vr; im[i + k] = ui + vi;
        re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi;
        const nr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr; cr = nr;
      }
    }
  }
}

function ifft(re, im) {
  for (let i = 0; i < im.length; i++) im[i] = -im[i];
  fft(re, im);
  for (let i = 0; i < re.length; i++) { re[i] /= re.length; im[i] = -im[i] / re.length; }
}

/**
 * 声道長摂動。周波数軸を alpha 倍に伸ばす（alpha>1 で声道が短い＝子ども寄り）。
 * 長さと基本周波数は変えない。
 */
function vtlp(x, alpha, nfft = 512, hop = 128) {
  const win = new Float32Array(nfft);
  for (let i = 0; i < nfft; i++) win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / nfft);
  const out = new Float32Array(x.length);
  const norm = new Float32Array(x.length);
  const half = nfft / 2;
  // Jaitly & Hinton の折れ線。高域が折り返さないよう境界から先は圧縮する。
  const fHi = 4800 / (RATE / 2) * half;
  const bend = Math.min(alpha, 1) * fHi;
  const warpBack = (k) => (k <= bend ? k / alpha
    : half - (half - bend / alpha) / (half - bend) * (half - k));

  for (let s = 0; s + nfft <= x.length; s += hop) {
    const re = new Float64Array(nfft), im = new Float64Array(nfft);
    for (let i = 0; i < nfft; i++) re[i] = x[s + i] * win[i];
    fft(re, im);
    const nr = new Float64Array(nfft), ni = new Float64Array(nfft);
    for (let k = 0; k <= half; k++) {
      const src = warpBack(k);
      const i0 = Math.floor(src), t = src - i0;
      if (i0 < 0 || i0 + 1 > half) continue;
      nr[k] = re[i0] * (1 - t) + re[Math.min(i0 + 1, half)] * t;
      ni[k] = im[i0] * (1 - t) + im[Math.min(i0 + 1, half)] * t;
      if (k > 0 && k < half) { nr[nfft - k] = nr[k]; ni[nfft - k] = -ni[k]; }
    }
    ifft(nr, ni);
    for (let i = 0; i < nfft; i++) { out[s + i] += nr[i] * win[i]; norm[s + i] += win[i] * win[i]; }
  }
  for (let i = 0; i < out.length; i++) out[i] = norm[i] > 1e-8 ? out[i] / norm[i] : out[i];
  return out;
}

/** 速く再生する。フォルマントも基本周波数も上がり、長さは縮む。 */
function resample(x, factor) {
  const n = Math.round(x.length / factor);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const src = i * factor;
    const i0 = Math.floor(src), t = src - i0;
    out[i] = (x[i0] ?? 0) * (1 - t) + (x[Math.min(i0 + 1, x.length - 1)] ?? 0) * t;
  }
  return out;
}

// --- 実行 ---

const sentences = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/reference.json'), 'utf8'));
const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const enPhones = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/en-phones.json'), 'utf8'));

const engine = new PronunciationEngine({
  transformers, model: 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX',
  dtype: 'q8', device: 'cpu', vocab, allowedIds: enPhones.ids,
});
await engine.load();

const files = fs.readdirSync(path.join(import.meta.dirname, 'audio'))
  .filter((f) => f.endsWith('.wav')).sort();

// 子どもは成人よりフォルマントが 20〜25% 高い。1.0 が原音。
const CASES = [
  { name: '原音', fn: (x) => x },
  { name: 'VTLP +5%', fn: (x) => vtlp(x, 1.05) },
  { name: 'VTLP +10%', fn: (x) => vtlp(x, 1.10) },
  { name: 'VTLP +15%', fn: (x) => vtlp(x, 1.15) },
  { name: 'VTLP +20%（子ども相当）', fn: (x) => vtlp(x, 1.20) },
  { name: 'VTLP +25%', fn: (x) => vtlp(x, 1.25) },
  { name: 'VTLP -10%（逆・大人寄り）', fn: (x) => vtlp(x, 0.90) },
  { name: '再サンプル +10%', fn: (x) => resample(x, 1 / 1.10) },
  { name: '再サンプル +20%', fn: (x) => resample(x, 1 / 1.20) },
];

const rows = [];
for (const c of CASES) {
  for (const f of files) {
    const m = f.match(/^s(\d+)_(.+)\.wav$/);
    const sentence = sentences[Number(m[1]) - 1];
    const { audio } = readWav(path.join(import.meta.dirname, 'audio', f));
    const mod = Float32Array.from(c.fn(Array.from(audio)));
    const out = await engine.recognize(mod);
    const s = scoreUtterance(sentence, gopScore(out, sentence.phones, sentence.alts), out.phones);
    rows.push({ case: c.name, voice: m[2], acc: s.accuracy, stars: s.stars });
  }
  const rs = rows.filter((r) => r.case === c.name);
  const nat = rs.filter((r) => r.voice !== 'Kyoko');
  const jp = rs.filter((r) => r.voice === 'Kyoko');
  const avg = (xs) => xs.reduce((a, r) => a + r.acc, 0) / xs.length;
  const st = (xs) => xs.reduce((a, r) => a + r.stars, 0) / xs.length;
  console.log(
    `${c.name.padEnd(26)} 全体 ${avg(rs).toFixed(3)} (★${st(rs).toFixed(1)})   ` +
    `ネイティブ系 ${avg(nat).toFixed(3)}   日本語訛り ${avg(jp).toFixed(3)}   ` +
    `差 ${(avg(nat) - avg(jp)).toFixed(3)}`
  );
}

// --- VTLN: 推論前に声道長を正規化して戻せるか ---
//
// 子どもの声（フォルマントが高い）を、推論の前に「大人寄り」へ warp し直す。
// 学習は要らない。話者ごとの warp 係数をどう決めるかが問題になるので、
// 2通り試す:
//
//   既知      正解の係数（今回は代用なので分かっている）を当てる。上限の確認
//   探索      いくつか試して、モデルがいちばん自信を持った係数を採る。
//             実運用でも使える方法
//
// 探索は候補の数だけ推論するので重い。ただし声は人ごとに一定なので、
// 本番なら最初の数回で決めて以降は使い回せる。

console.log('\n=== VTLN: 子ども相当の音声を推論前に戻す ===\n');
const CHILD = 1.20;   // 子ども相当とみなす変形量
const SEARCH = [1.0, 0.90, 0.85, 0.80, 0.75];

/** 候補の warp を試し、モデルがいちばん言い切った（最大確率の平均が高い）ものを採る */
async function vtlnSearch(x) {
  let best = null;
  for (const a of SEARCH) {
    const cand = a === 1.0 ? x : vtlp(x, a);
    const out = await engine.recognize(Float32Array.from(cand));
    let sum = 0;
    for (let t = 0; t < out.T; t++) {
      let m = -Infinity;
      for (let k = 0; k < out.K; k++) if (out.logp[t * out.K + k] > m) m = out.logp[t * out.K + k];
      sum += Math.exp(m);
    }
    const conf = sum / out.T;
    if (!best || conf > best.conf) best = { conf, out, alpha: a };
  }
  return best;
}

const vtlnRows = [];
for (const f of files) {
  const m = f.match(/^s(\d+)_(.+)\.wav$/);
  const sentence = sentences[Number(m[1]) - 1];
  const { audio } = readWav(path.join(import.meta.dirname, 'audio', f));
  const child = vtlp(Array.from(audio), CHILD);          // 子ども相当にする

  const score = async (x) => {
    const out = await engine.recognize(Float32Array.from(x));
    return scoreUtterance(sentence, gopScore(out, sentence.phones, sentence.alts), out.phones).accuracy;
  };

  const asIs = await score(child);
  const known = await score(vtlp(Array.from(child), 1 / CHILD));   // 正解の係数で戻す
  const hit = await vtlnSearch(Array.from(child));
  const searched = scoreUtterance(
    sentence, gopScore(hit.out, sentence.phones, sentence.alts), hit.out.phones).accuracy;

  vtlnRows.push({ voice: m[2], asIs, known, searched, alpha: hit.alpha });
}

const g = (sel, key) => {
  const rs = vtlnRows.filter(sel);
  return (rs.reduce((a, r) => a + r[key], 0) / rs.length).toFixed(3);
};
const nat = (r) => r.voice !== 'Kyoko';
const jp = (r) => r.voice === 'Kyoko';
console.log('処理                        ネイティブ系   日本語訛り      差');
for (const [name, key] of [['そのまま（子ども相当）', 'asIs'], ['正解の係数で戻す', 'known'], ['探索して戻す', 'searched']]) {
  console.log(`${name.padEnd(26)} ${g(nat, key).padStart(8)}   ${g(jp, key).padStart(8)}   ${(g(nat, key) - g(jp, key)).toFixed(3)}`);
}
const picked = {};
for (const r of vtlnRows) picked[r.alpha] = (picked[r.alpha] || 0) + 1;
console.log('\n探索が選んだ係数:', Object.entries(picked).map(([a, n]) => `${a}×${n}`).join('  '));

fs.writeFileSync(path.join(ROOT, 'docs/exp-child.json'),
  JSON.stringify({ degrade: rows, vtln: vtlnRows }, null, 2));
console.log('\n-> docs/exp-child.json');
