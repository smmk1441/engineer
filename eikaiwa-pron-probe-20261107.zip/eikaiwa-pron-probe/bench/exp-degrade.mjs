// 「スピーカーで鳴らしてマイクに聞かせる」と点が落ちる件の切り分け。
//
//   node bench/exp-degrade.mjs
//
// 実際の空気を通した録音は環境に依存して再現できないので、その経路で起きる
// 劣化を1つずつ人工的に加えて、どれがどれだけ効くかを測る。
//
//   clip     大音量でマイクに入って波形が潰れる（AGC を切ったので歯止めが無い）
//   lowcut   ノートPCのスピーカーは低域が出ない
//   highcut  安いマイクは高域が落ちる
//   reverb   部屋の反響
//   noise    暗騒音
//   quiet    離れた位置で録って信号が小さい
//
// 元音声はクリーンな TTS。ここから何を足すと崩れるかが分かれば、
// 直すべき場所（録音側の設定か、前処理か、採点か）が決まる。

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs';
import path from 'node:path';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { scoreUtterance } from '../js/score.js';
import { readWav } from './wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
transformers.env.cacheDir = path.join(ROOT, '.hfcache');
const RATE = 16000;

// --- 劣化 ---

/** 振幅を上げてから ±1 で潰す。マイクに近すぎる状態。 */
function clip(x, gain) {
  return x.map((v) => Math.max(-1, Math.min(1, v * gain)));
}

/** 1次ハイパス。ノートPCのスピーカーは低域が出ない。 */
function lowcut(x, hz) {
  const a = 1 / (1 + (2 * Math.PI * hz) / RATE);
  const out = new Float32Array(x.length);
  let prevIn = 0, prevOut = 0;
  for (let i = 0; i < x.length; i++) {
    out[i] = a * (prevOut + x[i] - prevIn);
    prevIn = x[i]; prevOut = out[i];
  }
  return out;
}

/** 1次ローパス。安いマイクの高域落ち。摩擦音が削られる。 */
function highcut(x, hz) {
  const a = (2 * Math.PI * hz) / RATE / (1 + (2 * Math.PI * hz) / RATE);
  const out = new Float32Array(x.length);
  let prev = 0;
  for (let i = 0; i < x.length; i++) { prev += a * (x[i] - prev); out[i] = prev; }
  return out;
}

/** 減衰する反射をいくつか足す。教室や会議室の反響。 */
function reverb(x, seconds, wet) {
  const taps = [0.013, 0.021, 0.037, 0.053, 0.079].map((t) => Math.round(t * RATE));
  const out = Float32Array.from(x);
  for (const d of taps) {
    const g = wet * Math.exp(-3 * (d / RATE) / seconds);
    for (let i = d; i < out.length; i++) out[i] += g * x[i - d];
  }
  const peak = Math.max(...out.map(Math.abs)) || 1;
  return out.map((v) => v / Math.max(1, peak));
}

/** 白色雑音。snrDb は元信号に対する S/N。 */
function noise(x, snrDb) {
  const rms = Math.sqrt(x.reduce((a, v) => a + v * v, 0) / x.length);
  const n = rms / Math.pow(10, snrDb / 20);
  return x.map((v) => v + n * (Math.random() * 2 - 1) * 1.73);
}

const gainOf = (x) => x.map((v) => v);

const CASES = [
  { name: 'そのまま', fn: (x) => gainOf(x) },
  { name: 'クリップ x2', fn: (x) => clip(x, 2) },
  { name: 'クリップ x4', fn: (x) => clip(x, 4) },
  { name: 'クリップ x8', fn: (x) => clip(x, 8) },
  { name: '低域カット 300Hz', fn: (x) => lowcut(x, 300) },
  { name: '高域カット 4kHz', fn: (x) => highcut(x, 4000) },
  { name: '高域カット 3kHz', fn: (x) => highcut(x, 3000) },
  { name: '反響 0.3s', fn: (x) => reverb(x, 0.3, 0.5) },
  { name: '反響 0.6s', fn: (x) => reverb(x, 0.6, 0.7) },
  { name: '雑音 SNR20dB', fn: (x) => noise(x, 20) },
  { name: '雑音 SNR10dB', fn: (x) => noise(x, 10) },
  { name: '小音量 1/10', fn: (x) => x.map((v) => v * 0.1) },
  // スピーカー -> 空気 -> マイク をまとめて再現したもの
  { name: '複合（実機相当）', fn: (x) => noise(reverb(highcut(lowcut(x, 250), 5000), 0.35, 0.45), 25) },
  { name: '複合 + クリップ', fn: (x) => clip(noise(reverb(highcut(lowcut(x, 250), 5000), 0.35, 0.45), 25), 3) },
];

// --- 実行 ---

const sentences = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/reference.json'), 'utf8'));
const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const enPhones = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/en-phones.json'), 'utf8'));

const engine = new PronunciationEngine({
  transformers, model: 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX',
  dtype: 'q8', device: 'cpu', vocab, allowedIds: enPhones.ids,
});
await engine.load();

// ネイティブ音声だけを使う。お手本を聞かせて星3つが出るか、が今回の論点。
const FILES = [
  { file: 's1_Samantha.wav', idx: 0 },
  { file: 's2_Samantha.wav', idx: 1 },
  { file: 's4_Samantha.wav', idx: 3 },
];

const rows = [];
for (const c of CASES) {
  const scores = [];
  for (const f of FILES) {
    const { audio } = readWav(path.join(import.meta.dirname, 'audio', f.file));
    const degraded = Float32Array.from(c.fn(Array.from(audio)));
    const out = await engine.recognize(degraded);
    scores.push(scoreUtterance(sentences[f.idx], gopScore(out, sentences[f.idx].phones), out.phones));
  }
  const acc = scores.reduce((a, s) => a + s.accuracy, 0) / scores.length;
  const stars = scores.reduce((a, s) => a + s.stars, 0) / scores.length;
  const three = scores.filter((s) => s.stars === 3).length;
  rows.push({ name: c.name, acc, stars, three, of: scores.length });
  console.log(`${c.name.padEnd(20)} 素点=${acc.toFixed(3)}  星平均=${stars.toFixed(2)}  星3つ=${three}/${scores.length}`);
}

fs.writeFileSync(path.join(ROOT, 'docs/exp-degrade.json'), JSON.stringify(rows, null, 2));
console.log('\n-> docs/exp-degrade.json');
