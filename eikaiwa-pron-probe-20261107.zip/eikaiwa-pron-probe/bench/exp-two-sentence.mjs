// 2文で答える問題の検証。
//
//   node bench/exp-two-sentence.mjs
//
//   Q. Who is that?
//   A. That is Elly. She is kind.   <- TGT は後半だけ
//
// 前置きまで採点区間に含めると、前置きをはっきり言うほど発話GOP が下がり、
// 上手い子ほど損をする。貼り付けと採点の区間を分けて直した（§7-11）。
// 前置きは言っても言わなくてもよいので、両方の貼り付け方をためして良いほうを採る。

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs'; import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { scoreUtterance } from '../js/score.js';
import { tokenize } from '../tools/ipa.mjs';
import { variantsFor } from '../tools/variants.mjs';
import { readWav } from '../bench/wav.mjs';
const ROOT = path.resolve(import.meta.dirname, '..');
transformers.env.cacheDir = path.join(ROOT, '.hfcache');
const vocab = JSON.parse(fs.readFileSync(ROOT+'/data/vocab.json','utf8'));
const en = JSON.parse(fs.readFileSync(ROOT+'/data/en-phones.json','utf8'));
const toks = new Set(Object.keys(vocab).filter(t=>!t.startsWith('<')));
const espeak = t => execFileSync('espeak-ng',['-v','en-us','-q','--ipa=3',t],{encoding:'utf8'}).trim();
function analyse(text){const words=text.split(/\s+/).map(w=>({display:w,phones:tokenize(espeak(w.replace(/[.,!?]/g,'')),toks)}));
  for(let i=0;i<words.length;i++)words[i].alts=variantsFor(words[i].display,words[i].phones,words[i-1]?.phones??[],words[i+1]?.phones??[]).map(v=>v.filter(p=>toks.has(p)));
  return{text,words,phones:words.flatMap(w=>w.phones),alts:words.flatMap(w=>w.alts)};}
const AUDIO=path.join(ROOT,'work/frame-audio');
function tts(text,voice){const key=`${voice}_${text.replace(/[^A-Za-z]+/g,'_')}`;const wav=path.join(AUDIO,key+'.wav');
  if(!fs.existsSync(wav)){const aiff=path.join(AUDIO,'tmp.aiff');execFileSync('say',['-v',voice,'-r','160','-o',aiff,text]);
  execFileSync('afconvert',['-f','WAVE','-d','LEI16@16000','-c','1',aiff,wav]);fs.rmSync(aiff);}return readWav(wav).audio;}
const engine=new PronunciationEngine({transformers,model:'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX',dtype:'q8',device:'cpu',vocab,allowedIds:en.ids});
await engine.load();

const REF = analyse('That is Elly. She is kind.');
const FROM = analyse('That is Elly.').phones.length;

// 前置きが想定とずれる現実のケース
const SPOKEN = [
  ['想定どおり',              'That is Elly. She is kind.'],
  ['名前がちがう (Mary)',     'That is Mary. She is kind.'],
  ['名前がちがう (Takeshi)',  'That is Takeshi. She is kind.'],
  ['前置きを言わない',        'She is kind.'],
  ['前置きが長い',            'Um, that is my friend Elly. She is kind.'],
  ['TGTを言い間違える',       'That is Elly. She is kid.'],
  ['TGTを言わない',           'That is Elly.'],
];
console.log('\n生徒の発話                        話者        素点   星  発話GOP  TGTの音素ごと');
for (const [name, spoken] of SPOKEN) {
  for (const v of ['Samantha', 'Kyoko']) {
    const out = await engine.recognize(tts(spoken, v));
    const g = gopScore(out, REF.phones, REF.alts, { from: FROM });
    const s = scoreUtterance(REF, g, out.phones);
    const tgt = g.phones.slice(FROM).map(p => `${p.tok}:${p.gop.toFixed(1)}`).join(' ');
    console.log(`${name.padEnd(28)} ${v.padEnd(10)} ${s.accuracy.toFixed(3)}  ★${s.stars}  ${g.utteranceGop.toFixed(3).padStart(7)}  ${tgt}`);
  }
}

// --- 前置きを「任意」にする ---
//
// 前置きを言う子と言わない子が混ざる。どちらの貼り付け方が正しいかは
// 事前に分からないので、両方やって良いほうを採る。
// 強制アライメントは1回 0.4ms 程度なので、2回でも費用は無視できる。
const TGT = analyse('She is kind.');
console.log('\n=== 両方ためして良いほうを採る ===\n');
console.log('生徒の発話                        話者        前置きごと   TGTだけ    採用');
for (const [name, spoken] of SPOKEN) {
  for (const v of ['Samantha', 'Kyoko']) {
    const out = await engine.recognize(tts(spoken, v));
    const a = scoreUtterance(REF, gopScore(out, REF.phones, REF.alts, { from: FROM }), out.phones);
    const b = scoreUtterance(TGT, gopScore(out, TGT.phones, TGT.alts), out.phones);
    const best = b.accuracy > a.accuracy ? b : a;
    const who = b.accuracy > a.accuracy ? 'TGTだけ' : '前置きごと';
    console.log(`${name.padEnd(28)} ${v.padEnd(10)} ${a.accuracy.toFixed(3)} ★${a.stars}    ${b.accuracy.toFixed(3)} ★${b.stars}   ${best.accuracy.toFixed(3)} ★${best.stars} (${who})`);
  }
}
