// 「星なし」をどう判定するか。
//
//   node bench/exp-zero-star.mjs
//
// いまの採点は下を切っていない。声さえ出ていれば必ず星1つは点く。
// 全く聞き取れないときや、全く違うことを喋っているときに星なしにしたい。
//
// **絶対値のしきい値には前科がある。** §7-7 で「どれでもない」を発話GOPの
// 絶対値で切ろうとして、雑音が乗ると正しい発話のほうが低くなり、訛りのある
// 正解を弾いてでたらめを通した。クリーンな音声だけで決めたのが原因。
//
// なのでここでは最初から劣化条件を混ぜて測る。見るのは2つの誤りの率:
//
//   正解を弾く    ちゃんと読んだのに星なし。**子ども向けではこちらの害が大きい**
//   でたらめを通す 全然違うのに星が点く
//
// 候補の指標:
//   accuracy      いまの素点（音素平均 × exp(発話GOP)）
//   mean          音素ごとの点の平均だけ。発話GOP を含まない
//   utteranceGop  §7-7 で使えないと分かっているもの。確認のため並べる
//   coverage      フレームが割り当たった正解音素の割合

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { scoreUtterance } from '../js/score.js';
import { readWav } from './wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
transformers.env.cacheDir = path.join(ROOT, '.hfcache');
const RATE = 16000;

// --- 劣化（bench/exp-degrade.mjs と同じもの） ---
function noise(x, snrDb) {
  const rms = Math.sqrt(x.reduce((a, v) => a + v * v, 0) / x.length);
  const n = rms / Math.pow(10, snrDb / 20);
  return Float32Array.from(x, (v) => v + n * (Math.random() * 2 - 1) * 1.73);
}
function reverb(x, seconds, wet) {
  const taps = [0.013, 0.021, 0.037, 0.053, 0.079].map((t) => Math.round(t * RATE));
  const out = Float32Array.from(x);
  for (const d of taps) {
    const g = wet * Math.exp(-3 * (d / RATE) / seconds);
    for (let i = d; i < out.length; i++) out[i] += g * x[i - d];
  }
  let peak = 0;
  for (const v of out) peak = Math.max(peak, Math.abs(v));
  return Float32Array.from(out, (v) => v / Math.max(1, peak));
}
const room = (x) => noise(reverb(x, 0.35, 0.45), 25);

const CONDS = [
  ['クリーン', (x) => x],
  ['雑音20dB', (x) => noise(x, 20)],
  ['雑音15dB', (x) => noise(x, 15)],
  ['実機相当', room],
];

// --- 音声 ---
const AUDIO = path.join(ROOT, 'work/zero-audio');
fs.mkdirSync(AUDIO, { recursive: true });
function tts(text, voice) {
  // 日本語は英数字に落とすと全部同じ名前になり、別の文が同じファイルを指す。
  // 一度これで「でたらめ」5種類が1種類になっていた。中身からキーを作る。
  const key = `${voice}_${createHash('sha1').update(text).digest('hex').slice(0, 12)}`;
  const wav = path.join(AUDIO, key + '.wav');
  if (!fs.existsSync(wav)) {
    const aiff = path.join(AUDIO, 'tmp.aiff');
    execFileSync('say', ['-v', voice, '-r', '160', '-o', aiff, text]);
    execFileSync('afconvert', ['-f', 'WAVE', '-d', 'LEI16@16000', '-c', '1', aiff, wav]);
    fs.rmSync(aiff);
  }
  return readWav(wav).audio;
}

const sentences = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/reference.json'), 'utf8'));
const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const enPhones = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/en-phones.json'), 'utf8'));
const engine = new PronunciationEngine({
  transformers, model: 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX',
  dtype: 'q8', device: 'cpu', vocab, allowedIds: enPhones.ids,
});
await engine.load();

const files = fs.readdirSync(path.join(ROOT, 'bench/audio')).filter((f) => f.endsWith('.wav')).sort();

/** 1件ぶんの指標を出す */
async function probe(audio, sentence) {
  const out = await engine.recognize(Float32Array.from(audio));
  const g = gopScore(out, sentence.phones, sentence.alts);
  const s = scoreUtterance(sentence, g, out.phones);
  const said = g.phones.filter((p) => !p.squeezed).length;
  const mean = s.phones.reduce((a, d) => a + d.score, 0) / s.phones.length;
  return {
    accuracy: s.accuracy, mean, utteranceGop: g.utteranceGop,
    coverage: said / g.phones.length, heardN: out.phones.length,
  };
}

const rows = [];
const add = (kind, cond, label, m) => rows.push({ kind, cond, label, ...m });

for (const [cname, fn] of CONDS) {
  // 正しく読んだもの。**これを弾いてはいけない**
  for (const f of files) {
    const [, n, voice] = f.match(/^s(\d+)_(.+)\.wav$/);
    const sent = sentences[Number(n) - 1];
    const a = fn(readWav(path.join(ROOT, 'bench/audio', f)).audio);
    add('正解', cname, `${voice} s${n}`, await probe(a, sent));
  }
  // 別の英文を読んでいる
  for (const f of files) {
    const [, n, voice] = f.match(/^s(\d+)_(.+)\.wav$/);
    const other = (Number(n) % 5) + 1;          // s1->s2, s5->s1
    const a = fn(readWav(path.join(ROOT, 'bench/audio', f)).audio);
    add('別の英文', cname, `${voice} s${n}→s${other}`, await probe(a, sentences[other - 1]));
  }
  // 日本語を喋っている / でたらめ
  for (const [text, voice] of [
    ['きょうは いい てんき ですね', 'Kyoko'],
    ['わたしの なまえは たなかです', 'Kyoko'],
    ['ラララ ラララ ラー', 'Kyoko'],
    ['あいうえお かきくけこ', 'Kyoko'],
    ['ええと うーんと あのー', 'Kyoko'],
  ]) {
    for (let i = 0; i < 5; i++)
      add('でたらめ', cname, `${text.slice(0, 6)} / s${i + 1}`,
        await probe(fn(tts(text, voice)), sentences[i]));
  }
}

// 無音に近いもの（息・暗騒音だけ）
for (let i = 0; i < 5; i++) {
  const quiet = Float32Array.from({ length: RATE * 2 }, () => (Math.random() * 2 - 1) * 0.002);
  add('ほぼ無音', '—', `s${i + 1}`, await probe(quiet, sentences[i]));
}

// --- 集計 ---
const KEYS = ['accuracy', 'mean', 'utteranceGop', 'coverage'];
const q = (xs, p) => { const s = [...xs].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(s.length * p))]; };

console.log('\n=== 指標ごとの分布（下位5% / 中央 / 上位5%） ===\n');
for (const key of KEYS) {
  console.log(`--- ${key} ---`);
  for (const kind of ['正解', '別の英文', 'でたらめ', 'ほぼ無音']) {
    for (const [cname] of [...CONDS, ['—']]) {
      const xs = rows.filter((r) => r.kind === kind && r.cond === cname).map((r) => r[key]);
      if (!xs.length) continue;
      console.log(`  ${kind.padEnd(10)} ${cname.padEnd(10)} ${q(xs, 0.05).toFixed(3).padStart(8)} ${q(xs, 0.5).toFixed(3).padStart(8)} ${q(xs, 0.95).toFixed(3).padStart(8)}`);
    }
  }
  console.log();
}

console.log('=== しきい値を振る（これ未満なら星なし） ===\n');
for (const key of KEYS) {
  const good = rows.filter((r) => r.kind === '正解').map((r) => r[key]);
  const bad = rows.filter((r) => r.kind !== '正解').map((r) => r[key]);
  console.log(`--- ${key} ---`);
  console.log('  しきい値   正解を弾く        でたらめを通す');
  const lo = Math.min(...bad), hi = Math.max(...good);
  for (let i = 1; i <= 12; i++) {
    const t = lo + (hi - lo) * (i / 13);
    const fr = good.filter((x) => x < t).length;
    const fa = bad.filter((x) => x >= t).length;
    console.log(`  ${t.toFixed(3).padStart(8)}   ${String(fr).padStart(3)}/${good.length} (${(fr / good.length * 100).toFixed(0).padStart(3)}%)   ${String(fa).padStart(3)}/${bad.length} (${(fa / bad.length * 100).toFixed(0).padStart(3)}%)`);
  }
  console.log();
}

fs.writeFileSync(path.join(ROOT, 'docs/exp-zero-star.json'), JSON.stringify(rows, null, 2));
console.log('-> docs/exp-zero-star.json');
