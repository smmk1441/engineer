// Node 上での精度・速度計測。
//
// ブラウザの数字はブラウザでしか取れないが、「音素列がまともか」
// 「点数の並びが崩れていないか」はここで回すほうが速い。
//
//   node bench/run.mjs [dtype]     dtype: q8(既定) / q4 / bnb4 / fp32
//
// 出力: bench/results-<dtype>.json と、標準出力に要約表。

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs';
import path from 'node:path';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { scoreUtterance } from '../js/score.js';
import { readWav } from './wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const MODEL = 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX';
const dtype = process.argv[2] || 'q8';
const maskEnglish = process.env.MASK !== '0';

transformers.env.cacheDir = path.join(ROOT, '.hfcache');

const sentences = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/reference.json'), 'utf8'));
const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const enPhones = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/en-phones.json'), 'utf8'));

const engine = new PronunciationEngine({
  transformers,
  model: MODEL,
  dtype,
  device: 'cpu', // Node は onnxruntime-node。ブラウザ側の wasm/webgpu とは別経路。
  vocab,
  allowedIds: maskEnglish ? enPhones.ids : null,
});

console.log(`model=${MODEL}  dtype=${dtype}  englishMask=${maskEnglish}`);
const loadMs = await engine.load();
console.log(`load: ${(loadMs / 1000).toFixed(1)}s\n`);

const files = fs.readdirSync(path.join(import.meta.dirname, 'audio'))
  .filter((f) => f.endsWith('.wav')).sort();

const rows = [];
for (const f of files) {
  const m = f.match(/^s(\d+)_(.+)\.wav$/);
  const sentence = sentences[Number(m[1]) - 1];
  const voice = m[2];
  const { audio } = readWav(path.join(import.meta.dirname, 'audio', f));

  await engine.recognize(audio.subarray(0, 16000)); // ウォームアップ
  const runs = [];
  let rec;
  for (let i = 0; i < 3; i++) { rec = await engine.recognize(audio); runs.push(rec.ms); }
  const ms = Math.min(...runs);

  const s = scoreUtterance(sentence, gopScore(rec, sentence.phones, sentence.alts), rec.phones);
  rows.push({
    file: f, voice, sentence: sentence.text,
    audioSec: +rec.audioSec.toFixed(2), ms: Math.round(ms),
    rtf: +(ms / 1000 / rec.audioSec).toFixed(3),
    accuracy: +s.accuracy.toFixed(3), lenient: +s.lenient.toFixed(3),
    stars: s.stars, utteranceGop: +s.utteranceGop.toFixed(3),
    extraSound: s.extraSound, fluency: s.fluency.level,
    hyp: rec.phones.map((p) => p.tok).join(' '),
    ref: sentence.phones.join(' '),
  });
}

// ---- 要約 ----
const voices = [...new Set(rows.map((r) => r.voice))];
const ORDER = ['Samantha', 'Daniel', 'Rishi', 'Tingting', 'Kyoko'];
voices.sort((a, b) => ORDER.indexOf(a) - ORDER.indexOf(b));

console.log('話者ごとの平均（期待: 上ほど高い）');
console.log('voice        acc    stars  発話GOP');
for (const v of voices) {
  const rs = rows.filter((r) => r.voice === v);
  const avg = (k) => rs.reduce((a, r) => a + r[k], 0) / rs.length;
  console.log(`${v.padEnd(12)} ${avg('accuracy').toFixed(3)}  ${avg('stars').toFixed(2)}   ${avg('utteranceGop').toFixed(3)}`);
}

console.log('\n文ごと');
for (const s of sentences) {
  const rs = rows.filter((r) => r.sentence === s.text);
  console.log(`  ${s.text}`);
  for (const v of voices) {
    const r = rs.find((x) => x.voice === v);
    if (r) console.log(`    ${v.padEnd(10)} ${'★'.repeat(r.stars)}${'☆'.repeat(3 - r.stars)} acc=${r.accuracy.toFixed(2)}  ${r.hyp}`);
  }
}

const lat = rows.map((r) => r.ms).sort((a, b) => a - b);
console.log(`\n推論: median ${lat[lat.length >> 1]}ms  p90 ${lat[Math.floor(lat.length * 0.9)]}ms`);
console.log(`RTF : mean ${(rows.reduce((a, r) => a + r.rtf, 0) / rows.length).toFixed(3)}`);

const out = path.join(import.meta.dirname, `results-${dtype}${maskEnglish ? '' : '-nomask'}.json`);
fs.writeFileSync(out, JSON.stringify({ model: MODEL, dtype, maskEnglish, loadMs, rows }, null, 2));
console.log(`\n-> ${path.relative(ROOT, out)}`);
