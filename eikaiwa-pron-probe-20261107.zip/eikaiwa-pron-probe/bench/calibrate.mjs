// 採点の係数を話者ラダーで決める。
//
//   node bench/calibrate.mjs
//
// 25発話ぶんの GOP を一度だけ計算してキャッシュし、そのうえで
// 係数を振って「星の分布」を見る。狙いは:
//
//   - ネイティブ(Samantha) は全部 星3つ
//   - 訛りのあるネイティブ(Daniel/Rishi) と 中国語訛り(Tingting) は概ね 星3つ
//   - 日本語訛り(Kyoko) は 星2つ に落ちる
//   - 素点の話者平均の順位が崩れない
//
// 「厳しすぎないか」を見たいので、星1つが出る発話も一覧に出す。

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs';
import path from 'node:path';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { scoreUtterance } from '../js/score.js';
import { readWav } from './wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const CACHE = path.join(ROOT, 'bench/gop-cache.json');
transformers.env.cacheDir = path.join(ROOT, '.hfcache');

const sentences = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/reference.json'), 'utf8'));

async function collect() {
  if (fs.existsSync(CACHE) && !process.env.FRESH) return JSON.parse(fs.readFileSync(CACHE, 'utf8'));

  const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
  const enPhones = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/en-phones.json'), 'utf8'));
  const engine = new PronunciationEngine({
    transformers, model: 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX',
    dtype: 'q8', device: 'cpu', vocab, allowedIds: enPhones.ids,
  });
  await engine.load();

  const files = fs.readdirSync(path.join(import.meta.dirname, 'audio'))
    .filter((f) => f.endsWith('.wav')).sort();
  const out = [];
  for (const f of files) {
    const m = f.match(/^s(\d+)_(.+)\.wav$/);
    const idx = Number(m[1]) - 1;
    const { audio } = readWav(path.join(import.meta.dirname, 'audio', f));
    const rec = await engine.recognize(audio);
    const g = gopScore(rec, sentences[idx].phones, sentences[idx].alts);
    out.push({
      file: f, voice: m[2], sentenceIndex: idx,
      gop: { phones: g.phones, utteranceGop: g.utteranceGop },
      heard: rec.phones.map((p) => ({ tok: p.tok })),
    });
  }
  fs.writeFileSync(CACHE, JSON.stringify(out));
  return out;
}

const data = await collect();
const ORDER = ['Samantha', 'Tingting', 'Rishi', 'Daniel', 'Kyoko'];
const voices = [...new Set(data.map((d) => d.voice))].sort((a, b) => ORDER.indexOf(a) - ORDER.indexOf(b));

function evaluate(tune) {
  const rows = data.map((d) => ({
    ...d,
    s: scoreUtterance(sentences[d.sentenceIndex], d.gop, d.heard, tune),
  }));
  const per = voices.map((v) => {
    const rs = rows.filter((r) => r.voice === v);
    return {
      voice: v,
      acc: rs.reduce((a, r) => a + r.s.accuracy, 0) / rs.length,
      stars: rs.reduce((a, r) => a + r.s.stars, 0) / rs.length,
      ones: rs.filter((r) => r.s.stars === 1).length,
    };
  });
  return { rows, per };
}

const GRID = [
  { name: '現行', tune: {} },
  { name: '甘め tau=3.4', tune: { tau: 3.4 } },
  { name: '辛め tau=2.0', tune: { tau: 2.0 } },
  { name: '発話GOP 弱 0.6', tune: { uttWeight: 0.6 } },
  { name: '発話GOP 強 1.8', tune: { uttWeight: 1.8 } },
  { name: '星の境目 甘 [0.75,0.42]', tune: { cuts: [0.75, 0.42] } },
];

for (const g of GRID) {
  const { per } = evaluate(g.tune);
  const mono = per.every((p, i) => i === 0 || per[i - 1].acc >= p.acc);
  console.log(`\n=== ${g.name} ${JSON.stringify(g.tune)}  順位${mono ? '維持' : '崩れ'}`);
  console.log('  voice        素点   星平均  星1つ');
  for (const p of per) {
    console.log(`  ${p.voice.padEnd(12)} ${p.acc.toFixed(3)}  ${p.stars.toFixed(2)}    ${p.ones}`);
  }
}

// 採用値での発話ごとの内訳
console.log('\n--- 現行係数での発話ごと ---');
const { rows } = evaluate({});
for (const r of rows) {
  console.log(`${r.file.padEnd(18)} ${'★'.repeat(r.s.stars)}${'☆'.repeat(3 - r.s.stars)} 素点=${r.s.accuracy.toFixed(2)}  弱い単語: ${r.s.words.filter((w) => w.level !== 'good').map((w) => w.display).join(' ') || 'なし'}`);
}
