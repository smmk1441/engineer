// 「何と言ったか当てる」のではなく「どの選択肢に一番合うか選ぶ」方式の実験。
//
//   node bench/exp-choice.mjs
//
// リスニング問題（聞いて、話して答える）を作れるかの検証。
// 開放語彙の音声認識は要らない。選択肢が有限なら、候補それぞれについて
// 「この音声をこの文として読ませるのに、どれだけ無理があるか」を測り、
// いちばん無理の無いものを選べばよい。発音採点で使っている utteranceGop がそのまま使える。
//
// 重い推論は1回だけで、候補を1つ増やすコストは強制アライメント1回（約0.4ms）。
// 選択肢の数はほとんど効かない。
//
// 測るもの:
//   - 選択肢の数を変えたときの正答率
//   - 紛らわしさ（最小対 vs 内容が違う）を変えたときの正答率
//   - 1位と2位の差の分布。「どれだけ差があれば信用してよいか」を決めるため
//
// クリーンな TTS 音声だけだと全問正解してしまい、足切りのしきい値が決められない
// （誤りが無いので精度を測れない）。雑音を載せた条件も一緒に回す。

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { tokenize } from '../tools/ipa.mjs';
import { readWav } from './wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
transformers.env.cacheDir = path.join(ROOT, '.hfcache');

/**
 * 課題文ごとの誤答候補。
 *   hard = 最小対。1音素しか違わない。実際のクイズで一番厳しい条件
 *   easy = 内容が違う。ふつうの4択で並ぶようなもの
 */
const DISTRACTORS = {
  1: {
    truth: 'I like apples.',
    hard: ['I like apple.', 'I bike apples.', 'I like ample.', 'I like apricots.'],
    easy: ['I like grapes.', 'We like apples.', "I don't like apples.", 'I like oranges.',
           'I eat apples.', 'You like apples.', 'I like bananas.', 'I have apples.'],
  },
  2: {
    truth: 'This is my cat.',
    hard: ['This is my cap.', 'This is my hat.', 'This is my bat.', 'That is my cat.'],
    easy: ['This is my dog.', 'This is a cat.', 'These are my cats.', 'This is your cat.',
           'That was my cat.', 'This is my car.', 'Here is my cat.', 'This is my bird.'],
  },
  3: {
    truth: 'How are you today?',
    hard: ['How are you doing?', 'Who are you today?', 'How are we today?', 'How old are you today?'],
    easy: ['Where are you today?', 'What are you doing today?', 'How was your day?',
           'Are you okay today?', 'How are they today?', 'When are you free today?',
           'Why are you here today?', 'How is she today?'],
  },
  4: {
    truth: "Let's play soccer.",
    hard: ["Let's play hockey.", "Let's play rugby.", "Let's pray soccer.", "Let's play softball."],
    easy: ["Let's play tennis.", "Let's watch soccer.", "Let's play baseball.", "We play soccer.",
           "Let's play together.", "Let's play the piano.", "Let's go play soccer.", "I play soccer."],
  },
  5: {
    truth: 'My name is Ken.',
    hard: ['My name is Ben.', 'My name is Jen.', 'My name is Kent.', 'My game is Ken.'],
    easy: ['My name is Tom.', 'His name is Ken.', 'My name was Ken.', 'Your name is Ken.',
           'My friend is Ken.', 'My name is Kenji.', 'I am Ken.', 'My dog is Ken.'],
  },
};

const ORDER = ['Samantha', 'Tingting', 'Rishi', 'Daniel', 'Kyoko'];

// --- 準備 ---

const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const enPhones = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/en-phones.json'), 'utf8'));
const tokens = new Set(Object.keys(vocab).filter((t) => !t.startsWith('<')));

const ipaCache = new Map();
function phonesOf(text) {
  if (!ipaCache.has(text)) {
    const raw = execFileSync('espeak-ng', ['-v', 'en-us', '-q', '--ipa=3', text], { encoding: 'utf8' }).trim();
    ipaCache.set(text, tokenize(raw, tokens));
  }
  return ipaCache.get(text);
}

const engine = new PronunciationEngine({
  transformers, model: 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX',
  dtype: 'q8', device: 'cpu', vocab, allowedIds: enPhones.ids,
});
await engine.load();

// 音声ごとに推論は1回だけ。以降は候補を変えてアライメントし直すだけ。
const files = fs.readdirSync(path.join(import.meta.dirname, 'audio'))
  .filter((f) => /^s[1-5]_/.test(f) && f.endsWith('.wav')).sort();

/** 白色雑音を載せる。実環境で誤りが出る条件を作るため。 */
function addNoise(audio, snrDb) {
  const rms = Math.sqrt(audio.reduce((a, v) => a + v * v, 0) / audio.length);
  const amp = rms / Math.pow(10, snrDb / 20);
  const out = new Float32Array(audio.length);
  for (let i = 0; i < audio.length; i++) out[i] = audio[i] + amp * (Math.random() * 2 - 1) * 1.73;
  return out;
}

const CONDITIONS = [
  { name: 'クリーン', fn: (a) => a },
  { name: '雑音20dB', fn: (a) => addNoise(a, 20) },
  { name: '雑音10dB', fn: (a) => addNoise(a, 10) },
];

const utterances = [];
for (const f of files) {
  const m = f.match(/^s(\d+)_(.+)\.wav$/);
  const { audio } = readWav(path.join(import.meta.dirname, 'audio', f));
  for (const c of CONDITIONS) {
    const t0 = performance.now();
    const out = await engine.recognize(c.fn(audio));
    utterances.push({
      file: f, id: Number(m[1]), voice: m[2], cond: c.name,
      out, inferMs: performance.now() - t0,
    });
  }
}

/** 候補のうち、いちばん無理なく読める文を選ぶ */
function choose(out, candidates) {
  const t0 = performance.now();
  const ranked = candidates
    .map((c) => ({ text: c, score: gopScore(out, phonesOf(c)).utteranceGop }))
    .sort((a, b) => b.score - a.score);
  return { ranked, margin: ranked[0].score - ranked[1].score, ms: performance.now() - t0 };
}

/** 誤答をn個選ぶ。毎回同じ並びになるよう順番に取る。 */
const pick = (pool, n) => pool.slice(0, n);

// --- 実験1: 選択肢の数と紛らわしさ ---

console.log('=== 選択肢の数 × 紛らわしさ ===\n');
const GRID = [
  { label: '2択 ふつう', n: 1, kind: 'easy' },
  { label: '4択 ふつう', n: 3, kind: 'easy' },
  { label: '9択 ふつう', n: 8, kind: 'easy' },
  { label: '2択 最小対', n: 1, kind: 'hard' },
  { label: '3択 最小対', n: 2, kind: 'hard' },
  { label: '5択 最小対', n: 4, kind: 'hard' },
  { label: '9択 混合', n: 4, kind: 'mix' },
];

const rows = [];
for (const g of GRID) {
  for (const u of utterances) {
    const d = DISTRACTORS[u.id];
    const wrong = g.kind === 'mix' ? [...pick(d.hard, g.n), ...pick(d.easy, g.n)] : pick(d[g.kind], g.n);
    const { ranked, margin, ms } = choose(u.out, [d.truth, ...wrong]);
    rows.push({
      grid: g.label, voice: u.voice, cond: u.cond, correct: ranked[0].text === d.truth,
      margin, choices: wrong.length + 1, ms,
    });
  }
}

console.log('（クリーンな音声のみ）');
console.log('条件          全体      ネイティブ系      日本語訛り     1位と2位の差(中央値)');
for (const g of GRID) {
  const rs = rows.filter((r) => r.grid === g.label && r.cond === 'クリーン');
  const acc = (xs) => xs.length ? `${(100 * xs.filter((r) => r.correct).length / xs.length).toFixed(0)}%` : '—';
  const nat = rs.filter((r) => r.voice !== 'Kyoko');
  const jp = rs.filter((r) => r.voice === 'Kyoko');
  const margins = rs.map((r) => r.margin).sort((a, b) => a - b);
  console.log(`${g.label.padEnd(12)}  ${acc(rs).padStart(4)}      ${acc(nat).padStart(4)}          ${acc(jp).padStart(4)}          ${margins[margins.length >> 1].toFixed(3)}`);
}

// --- 実験2: 話者ごと（最小対5択） ---

console.log('\n=== 話者ごと（5択・最小対） ===\n');
const voices = [...new Set(rows.map((r) => r.voice))].sort((a, b) => ORDER.indexOf(a) - ORDER.indexOf(b));
for (const v of voices) {
  const rs = rows.filter((r) => r.grid === '5択 最小対' && r.voice === v && r.cond === 'クリーン');
  const ok = rs.filter((r) => r.correct).length;
  const mg = rs.map((r) => r.margin);
  console.log(`  ${v.padEnd(10)} ${ok}/${rs.length}  差: 最小 ${Math.min(...mg).toFixed(3)} / 平均 ${(mg.reduce((a, b) => a + b, 0) / mg.length).toFixed(3)}`);
}

// --- 実験3: どれだけ差があれば信用してよいか ---

console.log('\n=== 雑音を加えたときの正答率（5択・最小対） ===\n');
for (const c of CONDITIONS) {
  const rs = rows.filter((r) => r.grid === '5択 最小対' && r.cond === c.name);
  const nat = rs.filter((r) => r.voice !== 'Kyoko');
  const jp = rs.filter((r) => r.voice === 'Kyoko');
  const pct = (xs) => xs.length ? `${(100 * xs.filter((r) => r.correct).length / xs.length).toFixed(0)}%` : '—';
  const mg = rs.map((r) => r.margin).sort((a, b) => a - b);
  console.log(`  ${c.name.padEnd(10)} 全体 ${pct(rs).padStart(4)}  ネイティブ系 ${pct(nat).padStart(4)}  日本語訛り ${pct(jp).padStart(4)}  差(中央値) ${mg[mg.length >> 1].toFixed(3)}`);
}

console.log('\n=== 1位と2位の差で足切りしたとき（全条件・紛らわしい選択肢） ===\n');
console.log('しきい値  採用率   採用したものの正答率   捨てた中の正答');
const hard = rows.filter((r) => r.grid === '5択 最小対' || r.grid === '9択 混合');
for (const th of [0, 0.02, 0.04, 0.06, 0.08, 0.12, 0.2]) {
  const taken = hard.filter((r) => r.margin >= th);
  const dropped = hard.filter((r) => r.margin < th);
  const rate = (100 * taken.length / hard.length).toFixed(0);
  const prec = taken.length ? (100 * taken.filter((r) => r.correct).length / taken.length).toFixed(1) : '—';
  const lost = dropped.filter((r) => r.correct).length;
  console.log(`  ${th.toFixed(2)}     ${rate.padStart(3)}%           ${String(prec).padStart(5)}%              ${lost}件`);
}

// --- 実験4: 選択肢を増やすコスト ---

console.log('\n=== 計算コスト ===\n');
const inferMs = utterances.reduce((a, u) => a + u.inferMs, 0) / utterances.length;
const perChoice = rows.reduce((a, r) => a + r.ms / r.choices, 0) / rows.length;
console.log(`  推論（音声1本につき1回）: ${inferMs.toFixed(0)} ms`);
console.log(`  候補1つの照合          : ${perChoice.toFixed(2)} ms`);
console.log(`  → 100択にしても照合は ${(perChoice * 100).toFixed(0)}ms。選択肢の数はほぼ効かない`);

fs.writeFileSync(path.join(ROOT, 'docs/exp-choice.json'), JSON.stringify(rows, null, 2));
console.log('\n-> docs/exp-choice.json');
