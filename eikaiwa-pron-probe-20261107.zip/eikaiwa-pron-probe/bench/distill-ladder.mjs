// 蒸留した生徒モデルを、実際の採点器に通して話者ラダーを見る。
//
//   work/venv/bin/python tools/distill-export.py --layers 12
//   node bench/distill-ladder.mjs
//
// 比較対象:
//   現行(24層)        bench/results-q8.json に記録済みの値
//   層を削っただけ     docs/layer-probe.json / bench/layer-ladder.mjs の結果
//   蒸留した生徒       ここで測る

import fs from 'node:fs';
import path from 'node:path';
import { gopScore } from '../js/gop.js';
import { scoreUtterance } from '../js/score.js';

const ROOT = path.resolve(import.meta.dirname, '..');
const L = Number(process.argv[2] || 12);
// 学習時の --tag と同じものを渡す。省略すると tag 無しのディレクトリを見る。
const TAG = process.argv[3] ? `-${process.argv[3]}` : '';
const DIR = path.join(ROOT, `work/distill-logp-${L}L${TAG}`);
const meta = JSON.parse(fs.readFileSync(path.join(DIR, 'meta.json'), 'utf8'));
const sentences = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/reference.json'), 'utf8'));
const index = new Map(meta.tokens.map((t, i) => [t, i]));
const ORDER = ['Samantha', 'Tingting', 'Rishi', 'Daniel', 'Kyoko'];

const rows = [];
for (const { file, T } of meta.files) {
  const m = file.match(/^s(\d+)_(.+)\.wav$/);
  const sentence = sentences[Number(m[1]) - 1];
  const buf = fs.readFileSync(path.join(DIR, `${file.slice(0, -4)}.bin`));
  const logp = new Float32Array(buf.buffer, buf.byteOffset, buf.length / 4);
  const out = { logp, T, K: meta.K, blank: 0, tokens: meta.tokens, index, frameSec: 0.02, phones: [] };
  const s = scoreUtterance(sentence, gopScore(out, sentence.phones, sentence.alts), []);
  rows.push({ voice: m[2], acc: s.accuracy, stars: s.stars });
}

const voices = [...new Set(rows.map((r) => r.voice))].sort((a, b) => ORDER.indexOf(a) - ORDER.indexOf(b));
console.log(`蒸留した生徒（${meta.layers}層 / ${meta.sizeMB} MB）\n`);
console.log('話者          素点    星平均');
const per = voices.map((v) => {
  const rs = rows.filter((r) => r.voice === v);
  const acc = rs.reduce((a, r) => a + r.acc, 0) / rs.length;
  const st = rs.reduce((a, r) => a + r.stars, 0) / rs.length;
  console.log(`${v.padEnd(12)} ${acc.toFixed(3)}   ${st.toFixed(1)}`);
  return acc;
});
const mono = per.every((a, i) => i === 0 || per[i - 1] >= a);
console.log(`\n順位: ${mono ? '維持' : '崩れ'}`);
console.log(`ネイティブと日本語訛りの差: ${(per[0] - per[per.length - 1]).toFixed(3)}`);
