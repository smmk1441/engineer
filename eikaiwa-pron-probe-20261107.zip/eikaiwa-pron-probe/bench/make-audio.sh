#!/bin/bash
# 検証用の音声を macOS の内蔵TTSで作る。
#
# 自前録音を集めずに「目盛りが崩れていないか」を見るための素材。
# ネイティブ(en_US) -> 訛りのあるネイティブ(en_GB/en_IN) -> 非ネイティブ(ja/zh)
# という順で、発音の近さが段階的に落ちる並びになるよう声を選んである。
#
#   bash bench/make-audio.sh
set -e
cd "$(dirname "$0")"
mkdir -p audio

# ラダーの順（期待する得点の高い順）
VOICES=(Samantha Daniel Rishi Tingting Kyoko)

i=1
while IFS= read -r line; do
  [ -z "$line" ] && continue
  for v in "${VOICES[@]}"; do
    f="audio/s${i}_${v}"
    say -v "$v" -o "${f}.aiff" "$line" 2>/dev/null || { echo "voice not installed: $v"; continue; }
    afconvert -f WAVE -d LEI16@16000 -c 1 "${f}.aiff" "${f}.wav" >/dev/null
    rm -f "${f}.aiff"
  done
  i=$((i + 1))
done < sentences.txt

echo "$(ls audio/*.wav | wc -l | tr -d ' ') files in bench/audio"
