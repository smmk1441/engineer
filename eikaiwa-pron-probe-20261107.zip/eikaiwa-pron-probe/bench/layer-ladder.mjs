// 層を削ったモデルの出力を、実際の採点器に通して話者ラダーを見る。
//
//   python3 tools/layer-ladder.py     # 先に対数事後確率を書き出す
//   node bench/layer-ladder.mjs
//
// フレーム一致率は代理指標にすぎない。見たいのは
// 「ネイティブが星3つ、日本語訛りが星2つ、順位が崩れない」かどうか。

import fs from 'node:fs';
import path from 'node:path';
import { gopScore } from '../js/gop.js';
import { scoreUtterance } from '../js/score.js';

const ROOT = path.resolve(import.meta.dirname, '..');
const DIR = path.join(ROOT, 'work/ladder-logp');
const meta = JSON.parse(fs.readFileSync(path.join(DIR, 'meta.json'), 'utf8'));
const sentences = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/reference.json'), 'utf8'));

const index = new Map(meta.tokens.map((t, i) => [t, i]));
const ORDER = ['Samantha', 'Tingting', 'Rishi', 'Daniel', 'Kyoko'];

const rows = [];
for (const L of meta.layers) {
  for (const { file, T } of meta.files) {
    const m = file.match(/^s(\d+)_(.+)\.wav$/);
    const sentence = sentences[Number(m[1]) - 1];
    const buf = fs.readFileSync(path.join(DIR, `${file.slice(0, -4)}__L${L}.bin`));
    const logp = new Float32Array(buf.buffer, buf.byteOffset, buf.length / 4);
    const out = {
      logp, T, K: meta.K, blank: 0, tokens: meta.tokens, index, frameSec: 0.02,
      phones: [],
    };
    const s = scoreUtterance(sentence, gopScore(out, sentence.phones, sentence.alts), []);
    rows.push({ layer: L, voice: m[2], acc: s.accuracy, stars: s.stars });
  }
}

const voices = [...new Set(rows.map((r) => r.voice))].sort((a, b) => ORDER.indexOf(a) - ORDER.indexOf(b));
console.log('層ごとの話者ラダー（素点 / 星平均）\n');
console.log('層    ' + voices.map((v) => v.padEnd(14)).join('') + ' 順位');
for (const L of meta.layers) {
  const cells = voices.map((v) => {
    const rs = rows.filter((r) => r.layer === L && r.voice === v);
    const acc = rs.reduce((a, r) => a + r.acc, 0) / rs.length;
    const st = rs.reduce((a, r) => a + r.stars, 0) / rs.length;
    return { v, acc, s: `${acc.toFixed(3)}/${st.toFixed(1)}`.padEnd(14) };
  });
  const mono = cells.every((c, i) => i === 0 || cells[i - 1].acc >= c.acc);
  console.log(`${String(L).padStart(3)}   ${cells.map((c) => c.s).join('')} ${mono ? '維持' : '崩れ'}`);
}

const params = (L) => {
  const per = (4 * 1024 ** 2 + 4 * 1024) + (2 * 1024 * 4096 + 4096 + 1024) + 4 * 1024;
  return (4.2e6 + 0.5e6 + per * L + 1024 * 60) / 1e6;
};
console.log('\n層    パラメータ    q8 目安    現行比');
for (const L of meta.layers) {
  const p = params(L);
  console.log(`${String(L).padStart(3)}   ${p.toFixed(0).padStart(6)}M   ${p.toFixed(0).padStart(5)} MB   ${(100 * p / params(24)).toFixed(0)}%`);
}
