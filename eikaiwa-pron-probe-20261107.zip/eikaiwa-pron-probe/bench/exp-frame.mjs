// 「枠は同じで、入る語だけが違う」候補から選べるかの検証。
//
//   node bench/exp-frame.mjs
//
// 教材側から来た問題形式（音読 / 対話 / 発表）のうち、対話と発表は
// 生徒の答えが事前に決まっていない。ただし答えには枠がある
// （I like ___. / My treasure is this ___.）ので、枠を埋める語を並べた
// 閉じた候補集合として選べるかを測る。
//
// リスニング問題（§7-2）との決定的な違い:
//   あちらは候補の文がまるごと違った。ここは **枠が全部同じで、入れ替わるのは1語だけ**。
//   しかもその1語どうしが似ている（baseball / basketball / volleyball）。
//   同じ手が通じるとは限らない。

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { tokenize } from '../tools/ipa.mjs';
import { variantsFor } from '../tools/variants.mjs';
import { readWav } from '../bench/wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
transformers.env.cacheDir = path.join(ROOT, '.hfcache');
const RATE = 16000;

const SETS = {
  'スポーツ (I like ___.)': {
    frame: (w) => `I like ${w}.`,
    slots: ['baseball', 'basketball', 'soccer', 'tennis', 'swimming',
            'volleyball', 'badminton', 'dancing', 'dodgeball', 'skiing'],
  },
  '色 (I like ___.)': {
    frame: (w) => `I like ${w}.`,
    slots: ['red', 'blue', 'green', 'yellow', 'black',
            'white', 'pink', 'purple', 'orange', 'brown'],
  },
  '宝物 (My treasure is this ___.)': {
    frame: (w) => `My treasure is this ${w}.`,
    slots: ['book', 'bag', 'cap', 'watch', 'bike',
            'dog', 'pen', 'camera', 'racket', 'ball'],
  },
  '単語のみ（音読1）': {
    frame: (w) => w,
    slots: ['baseball', 'basketball', 'soccer', 'tennis', 'swimming',
            'volleyball', 'badminton', 'dancing', 'dodgeball', 'skiing'],
  },
};

const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const enPhones = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/en-phones.json'), 'utf8'));
const tokset = new Set(Object.keys(vocab).filter((t) => !t.startsWith('<')));
const espeak = (t) => execFileSync('espeak-ng', ['-v', 'en-us', '-q', '--ipa=3', t], { encoding: 'utf8' }).trim();

function analyse(text) {
  const words = text.split(/\s+/).map((w) => ({
    display: w, phones: tokenize(espeak(w.replace(/[.,!?]/g, '')), tokset),
  }));
  for (let i = 0; i < words.length; i++) {
    words[i].alts = variantsFor(words[i].display, words[i].phones,
      words[i - 1]?.phones ?? [], words[i + 1]?.phones ?? []).map((v) => v.filter((p) => tokset.has(p)));
  }
  return { text, words, phones: words.flatMap((w) => w.phones), alts: words.flatMap((w) => w.alts) };
}

// --- TTS ---
const AUDIO = path.join(ROOT, 'work/frame-audio');
fs.mkdirSync(AUDIO, { recursive: true });
function tts(text, voice) {
  const key = `${voice}_${text.replace(/[^A-Za-z]+/g, '_')}`;
  const wav = path.join(AUDIO, key + '.wav');
  if (!fs.existsSync(wav)) {
    const aiff = path.join(AUDIO, 'tmp.aiff');
    execFileSync('say', ['-v', voice, '-r', '160', '-o', aiff, text]);
    execFileSync('afconvert', ['-f', 'WAVE', '-d', 'LEI16@16000', '-c', '1', aiff, wav]);
    fs.rmSync(aiff);
  }
  return readWav(wav).audio;
}

function noise(x, snrDb) {
  const rms = Math.sqrt(x.reduce((a, v) => a + v * v, 0) / x.length);
  const n = rms / Math.pow(10, snrDb / 20);
  return Float32Array.from(x, (v) => v + n * (Math.random() * 2 - 1) * 1.73);
}

const engine = new PronunciationEngine({
  transformers, model: 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX',
  dtype: 'q8', device: 'cpu', vocab, allowedIds: enPhones.ids,
});
await engine.load();

const CONDS = [
  { name: 'クリーン', fn: (x) => x },
  { name: '雑音20dB', fn: (x) => noise(x, 20) },
  { name: '雑音15dB', fn: (x) => noise(x, 15) },
];
const VOICES = [['Samantha', 'ネイティブ'], ['Kyoko', '日本語訛り']];

const rows = [];
for (const [setName, def] of Object.entries(SETS)) {
  const cands = def.slots.map((w) => analyse(def.frame(w)));
  for (const [voice, label] of VOICES) {
    for (const cond of CONDS) {
      let hit = 0; const margins = []; const misses = [];
      for (let i = 0; i < cands.length; i++) {
        const audio = cond.fn(tts(cands[i].text, voice));
        const out = await engine.recognize(Float32Array.from(audio));
        const ranked = cands
          .map((c, j) => ({ j, score: gopScore(out, c.phones, c.alts).utteranceGop }))
          .sort((a, b) => b.score - a.score);
        if (ranked[0].j === i) hit++;
        else misses.push(`${def.slots[i]}→${def.slots[ranked[0].j]}`);
        margins.push(ranked[0].score - ranked[1].score);
      }
      margins.sort((a, b) => a - b);
      rows.push({ set: setName, voice: label, cond: cond.name,
        acc: hit / cands.length, n: cands.length,
        medMargin: margins[Math.floor(margins.length / 2)], misses });
    }
  }
}

console.log('\n候補集合                           話者        条件       正答率   1位2位差(中央)  取り違え');
for (const r of rows) {
  console.log(
    `${r.set.padEnd(34)} ${r.voice.padEnd(10)} ${r.cond.padEnd(10)} ` +
    `${String(Math.round(r.acc * 100)).padStart(3)}% (${Math.round(r.acc * r.n)}/${r.n})  ` +
    `${r.medMargin.toFixed(3).padStart(8)}      ${r.misses.slice(0, 3).join(' ') || '—'}`);
}
fs.writeFileSync(path.join(ROOT, 'docs/exp-frame.json'), JSON.stringify(rows, null, 2));
console.log('\n-> docs/exp-frame.json');
