// 旧採点（自由デコード + Needleman-Wunsch）と
// 新採点（CTC 強制アライメント + GOP）を、同じ25発話で並べて比べる。
//
//   node bench/compare-scoring.mjs
//
// 見るのは絶対値ではなく「話者ラダーの分離」。
// ネイティブが満点に張り付き、訛りが段階的に下がり、その順が崩れないこと。

import * as transformers from '@huggingface/transformers';
import fs from 'node:fs';
import path from 'node:path';
import { PronunciationEngine } from '../js/engine.js';
import { gopScore } from '../js/gop.js';
import { scoreUtterance as legacyScore } from './legacy/score.js';
import { scoreUtterance } from '../js/score.js';
import { readWav } from './wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
transformers.env.cacheDir = path.join(ROOT, '.hfcache');

const sentences = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/reference.json'), 'utf8'));
const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const enPhones = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/en-phones.json'), 'utf8'));

const engine = new PronunciationEngine({
  transformers,
  model: 'onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX',
  dtype: 'q8',
  device: 'cpu',
  vocab,
  allowedIds: enPhones.ids,
});
await engine.load();

const files = fs.readdirSync(path.join(import.meta.dirname, 'audio'))
  .filter((f) => f.endsWith('.wav')).sort();

const rows = [];
for (const f of files) {
  const m = f.match(/^s(\d+)_(.+)\.wav$/);
  const sentence = sentences[Number(m[1]) - 1];
  const { audio } = readWav(path.join(import.meta.dirname, 'audio', f));
  const out = await engine.recognize(audio);

  const old = legacyScore(sentence, out.phones);
  const g = gopScore(out, sentence.phones);

  rows.push({
    file: f,
    voice: m[2],
    sentence: sentence.text,
    oldAcc: old.accuracy,
    newAcc: scoreUtterance(sentence, gopScore(out, sentence.phones), out.phones).accuracy,
    meanGop: g.phones.reduce((a, p) => a + p.gop, 0) / g.phones.length,
    minGop: Math.min(...g.phones.map((p) => p.gop)),
    utteranceGop: g.utteranceGop,
    meanPosterior: g.phones.reduce((a, p) => a + p.posterior, 0) / g.phones.length,
    worst: g.phones.slice().sort((a, b) => a.gop - b.gop).slice(0, 3)
      .map((p) => `${p.tok}${p.heard ? `(${p.heard})` : ''}:${p.gop.toFixed(1)}`),
  });
}

const ORDER = ['Samantha', 'Daniel', 'Rishi', 'Tingting', 'Kyoko'];
const voices = [...new Set(rows.map((r) => r.voice))].sort((a, b) => ORDER.indexOf(a) - ORDER.indexOf(b));

console.log('話者ごとの平均');
console.log('voice        旧acc  新acc   平均GOP  最小GOP  発話GOP');
for (const v of voices) {
  const rs = rows.filter((r) => r.voice === v);
  const avg = (k) => rs.reduce((a, r) => a + r[k], 0) / rs.length;
  console.log(
    `${v.padEnd(12)} ${avg('oldAcc').toFixed(3)}  ${avg('newAcc').toFixed(3)}  ` +
    `${avg('meanGop').toFixed(3).padStart(7)}  ${avg('minGop').toFixed(2).padStart(7)}  ` +
    `${avg('utteranceGop').toFixed(3).padStart(7)}`
  );
}

console.log('\n発話ごと（悪い音素 上位3つ）');
for (const r of rows) {
  console.log(`${r.file.padEnd(18)} 旧=${r.oldAcc.toFixed(2)} 新=${r.newAcc.toFixed(2)} 発話GOP=${r.utteranceGop.toFixed(2)}  ${r.worst.join(' ')}`);
}

fs.writeFileSync(path.join(ROOT, 'docs/compare-scoring.json'), JSON.stringify(rows, null, 2));
console.log('\n-> docs/compare-scoring.json');
