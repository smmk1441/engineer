// Needleman-Wunsch による音素列アライメント。
//
// 正解音素列と認識音素列は長さが違う（言い落とし・余計な音）ので、
// 単純な位置合わせでは比べられない。大域アライメントで対応付けてから
// 置換 / 脱落 / 挿入を数える。

// 混同しても大きくは減点しない音素ペア。
// 日本語話者がつまずきやすく、かつ「言えていないわけではない」ものを近いとみなす。
const NEAR_PAIRS = [
  ['l', 'ɹ'], ['l', 'ɾ'], ['ɹ', 'ɚ'], ['ɹ', 'ɐ'], ['ɚ', 'ɐ'], ['ɚ', 'ə'],
  ['θ', 's'], ['ð', 'z'], ['ð', 'd'], ['θ', 't'], ['s', 'ʃ'], ['z', 'ʒ'],
  ['v', 'b'], ['f', 'h'], ['w', 'ʊ'], ['j', 'i'],
  ['æ', 'a'], ['æ', 'ɛ'], ['ɑː', 'a'], ['ɑː', 'ɔː'], ['ʌ', 'ɐ'], ['ʌ', 'a'],
  ['ə', 'ʌ'], ['ə', 'ɐ'], ['ə', 'a'], ['ə', 'ᵻ'], ['ɪ', 'ᵻ'],
  ['ɪ', 'i'], ['iː', 'i'], ['ɪ', 'iː'], ['ʊ', 'u'], ['uː', 'u'], ['ʊ', 'uː'],
  ['oʊ', 'o'], ['eɪ', 'e'], ['ɔː', 'o'], ['aɪ', 'a'], ['aʊ', 'a'],
  ['ŋ', 'n'], ['ɾ', 't'], ['ɾ', 'd'], ['n', 'm'], ['n', 'n̩'], ['əl', 'l'],
  ['ɑːɹ', 'ɑː'], ['ɔːɹ', 'ɔː'], ['ɛɹ', 'ɛ'], ['ɪɹ', 'ɪ'], ['ʊɹ', 'ʊ'],
];

const nearSet = new Set();
const key = (a, b) => `${a}${b}`;
for (const [a, b] of NEAR_PAIRS) { nearSet.add(key(a, b)); nearSet.add(key(b, a)); }

const strip = (s) => s.replace(/[ːˑˈˌ]/g, '');

/** 2音素が「ほぼ同じ」とみなせるか */
export function isNear(a, b) {
  if (a === b) return true;
  if (nearSet.has(key(a, b))) return true;
  // 長音記号や強勢記号だけの違い（uː と u など）は同一扱い
  const sa = strip(a), sb = strip(b);
  return sa.length > 0 && sa === sb;
}

// 一致に大きく報い、ギャップは軽く。挿入・脱落を作ってでも
// 一致を拾いにいくほうが、可視化として素直な対応付けになる。
const SCORE = { match: 2, near: 1, mismatch: -1, gap: -1 };

/**
 * @param {string[]} ref 正解音素列
 * @param {string[]} hyp 認識音素列
 * @returns {Array<{type:'match'|'near'|'sub'|'del'|'ins', ref?:string, hyp?:string, refIdx?:number, hypIdx?:number}>}
 */
export function align(ref, hyp) {
  const n = ref.length, m = hyp.length;
  // dp[i][j] = ref[0..i) と hyp[0..j) を揃えたときの最良スコア
  const dp = Array.from({ length: n + 1 }, () => new Float64Array(m + 1));
  const bt = Array.from({ length: n + 1 }, () => new Uint8Array(m + 1)); // 0:斜め 1:上(脱落) 2:左(挿入)

  for (let i = 1; i <= n; i++) { dp[i][0] = i * SCORE.gap; bt[i][0] = 1; }
  for (let j = 1; j <= m; j++) { dp[0][j] = j * SCORE.gap; bt[0][j] = 2; }

  for (let i = 1; i <= n; i++) {
    const a = ref[i - 1];
    for (let j = 1; j <= m; j++) {
      const b = hyp[j - 1];
      const sub = a === b ? SCORE.match : isNear(a, b) ? SCORE.near : SCORE.mismatch;
      const d = dp[i - 1][j - 1] + sub;
      const u = dp[i - 1][j] + SCORE.gap;
      const l = dp[i][j - 1] + SCORE.gap;
      if (d >= u && d >= l) { dp[i][j] = d; bt[i][j] = 0; }
      else if (u >= l) { dp[i][j] = u; bt[i][j] = 1; }
      else { dp[i][j] = l; bt[i][j] = 2; }
    }
  }

  const out = [];
  let i = n, j = m;
  while (i > 0 || j > 0) {
    const move = i > 0 && j > 0 ? bt[i][j] : i > 0 ? 1 : 2;
    if (move === 0) {
      const a = ref[i - 1], b = hyp[j - 1];
      out.push({
        type: a === b ? 'match' : isNear(a, b) ? 'near' : 'sub',
        ref: a, hyp: b, refIdx: i - 1, hypIdx: j - 1,
      });
      i--; j--;
    } else if (move === 1) {
      out.push({ type: 'del', ref: ref[i - 1], refIdx: i - 1 });
      i--;
    } else {
      out.push({ type: 'ins', hyp: hyp[j - 1], hypIdx: j - 1 });
      j--;
    }
  }
  return out.reverse();
}
