// node --test js/
//
// アライメントと採点の最低限の確認。音素列が絡む部分は目視だと
// 合っているか分からなくなるので、期待を書き下しておく。

import test from 'node:test';
import assert from 'node:assert/strict';
import { align, isNear } from './align.js';
import { scoreUtterance } from './score.js';

const types = (ref, hyp) => align(ref.split(' '), hyp.split(' ')).map((o) => o.type).join(' ');

test('完全一致はすべて match', () => {
  assert.equal(types('l ɛ t s', 'l ɛ t s'), 'match match match match');
});

test('言い落としは del になる', () => {
  assert.equal(types('k æ t', 'k t'), 'match del match');
});

test('余計な音は ins になる', () => {
  assert.equal(types('k æ t', 'k æ ə t'), 'match match ins match');
});

test('近い音は sub ではなく near', () => {
  assert.equal(types('ɹ', 'l'), 'near');
  assert.equal(types('θ', 's'), 'near');
  assert.equal(types('k', 'z'), 'sub');
});

test('長音記号だけの違いは同一扱い', () => {
  assert.ok(isNear('uː', 'u'));
  assert.ok(isNear('ɑː', 'ɑ'));
  assert.ok(!isNear('uː', 'iː'));
});

test('空の認識結果でも落ちない', () => {
  assert.equal(align('k æ t'.split(' '), []).map((o) => o.type).join(' '), 'del del del');
});

// --- 採点 ---

const SENTENCE = {
  text: "Let's play soccer.",
  words: [
    { display: "Let's", phones: ['l', 'ɛ', 't', 's'] },
    { display: 'play', phones: ['p', 'l', 'eɪ'] },
    { display: 'soccer.', phones: ['s', 'ɑː', 'k', 'ɚ'] },
  ],
  phones: ['l', 'ɛ', 't', 's', 'p', 'l', 'eɪ', 's', 'ɑː', 'k', 'ɚ'],
};

const utter = (toks, dur = 1.2) => toks.map((tok, i) => ({
  tok, p: 0.9,
  start: (i * dur) / toks.length,
  end: ((i + 1) * dur) / toks.length,
}));

test('正しく読めたら星3つ、全単語 good', () => {
  const s = scoreUtterance(SENTENCE, utter(SENTENCE.phones));
  assert.equal(s.stars, 3);
  assert.equal(s.accuracy, 1);
  assert.deepEqual(s.words.map((w) => w.level), ['good', 'good', 'good']);
});

test('後半を落とすと、その単語だけ weak になる', () => {
  const s = scoreUtterance(SENTENCE, utter(['l', 'ɛ', 't', 's', 'p', 'l', 'eɪ']));
  assert.equal(s.words[0].level, 'good');
  assert.equal(s.words[1].level, 'good');
  assert.equal(s.words[2].level, 'weak');
  assert.ok(s.stars < 3, `stars=${s.stars}`);
});

test('声が出ていなくても星は1つ残る', () => {
  const s = scoreUtterance(SENTENCE, []);
  assert.equal(s.stars, 1);
  assert.equal(s.empty, true);
});

test('音がほとんど拾えていないときは「すらすら」にしない', () => {
  const s = scoreUtterance(SENTENCE, utter(['l', 'ɛ'], 0.25));
  assert.notEqual(s.fluency.level, 'smooth');
});

test('チップの並びは正解音素と同じ長さ', () => {
  const s = scoreUtterance(SENTENCE, utter(['l', 'ɛ', 'ə', 't', 's', 'p', 'l', 'eɪ']));
  assert.equal(s.phones.length, SENTENCE.phones.length);
  const withExtra = s.phones.filter((p) => p.extra.length);
  assert.equal(withExtra.length, 1, '挿入された音がどこかのチップに付いている');
});
