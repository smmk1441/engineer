// アライメント結果を採点に変える。
//
// 方針は引き継ぎメモのとおり「甘め」。小学生が読み上げる前提なので、
// 素点をそのまま出さず、言えている部分を拾い上げる方向に倒してある。
// 表示も数値ではなく星3段階。

import { align } from './align.js';

/** 部分点。近い音（l/ɹ, θ/s など）は「言えていない」とは扱わない。 */
const CREDIT = { match: 1, near: 0.72, sub: 0, del: 0 };
/** 余分な音の減点。挿入は言い直しでも増えるので軽く見る。 */
const INSERT_COST = 0.25;

// 星3つ / 2つ の境目（甘め補正をかけた値に対して）。
// ネイティブ音声と外国語訛りの読み上げが同じ星にならない位置に置いてある。
// 下は切らない — 声が出ていれば必ず1つは点く。
const STAR_CUTS = [0.80, 0.42];

/**
 * @param {{words:Array<{display:string,phones:string[]}>, phones:string[]}} sentence
 * @param {Array<{tok:string,start:number,end:number,p:number}>} recognized
 */
export function scoreUtterance(sentence, recognized) {
  const ref = sentence.phones;
  const hyp = recognized.map((r) => r.tok);
  const ops = align(ref, hyp);

  // 単語ごとに正解音素のどの範囲を持っているか
  const spans = [];
  let at = 0;
  for (const w of sentence.words) {
    spans.push({ word: w, from: at, to: at + w.phones.length });
    at += w.phones.length;
  }

  let credit = 0;
  let inserts = 0;
  const perRef = new Array(ref.length).fill(null);

  for (const op of ops) {
    if (op.type === 'ins') { inserts++; continue; }
    credit += CREDIT[op.type];
    perRef[op.refIdx] = op;
  }

  const accuracy = clamp01(
    (credit - INSERT_COST * Math.min(inserts, ref.length * 0.5)) / Math.max(ref.length, 1)
  );

  // 認識の自信。音がはっきりしていないと全体に下がるので、
  // 音素の当たり外れとは別に「もごもご度」の指標として使える。
  const confidence = recognized.length
    ? recognized.reduce((a, r) => a + r.p, 0) / recognized.length
    : 0;

  const fluency = measureFluency(recognized, ref.length);

  // 甘め補正。素点をそのまま星に落とすと 2 つ星に寄りすぎるので、
  // 上に持ち上げる曲線を一枚かませる。
  const lenient = Math.pow(accuracy, 0.78);
  const stars = lenient >= STAR_CUTS[0] ? 3 : lenient >= STAR_CUTS[1] ? 2 : 1;

  return {
    ops,
    accuracy,
    lenient,
    confidence,
    fluency,
    stars,
    words: spans.map((s) => scoreWord(s, perRef)),
    phones: buildPhoneView(ops, recognized),
    empty: recognized.length === 0,
  };
}

function scoreWord({ word, from, to }, perRef) {
  let credit = 0;
  const detail = [];
  for (let i = from; i < to; i++) {
    const op = perRef[i];
    const c = op ? CREDIT[op.type] : 0;
    credit += c;
    detail.push({ ref: word.phones[i - from], type: op ? op.type : 'del', hyp: op?.hyp });
  }
  const ratio = credit / Math.max(to - from, 1);
  return {
    display: word.display,
    ratio,
    level: ratio >= 0.75 ? 'good' : ratio >= 0.4 ? 'soso' : 'weak',
    detail,
  };
}

/**
 * 音素チップの並び。正解音素を軸に、そこへ何が入ったかを添える。
 * 挿入は直後の正解音素にぶら下げる（単独のチップにすると読みにくい）。
 */
function buildPhoneView(ops, recognized) {
  const view = [];
  let pendingIns = [];
  for (const op of ops) {
    if (op.type === 'ins') { pendingIns.push(op.hyp); continue; }
    view.push({
      ref: op.ref,
      hyp: op.hyp ?? null,
      type: op.type,
      extra: pendingIns,
      p: op.hypIdx != null ? recognized[op.hypIdx]?.p ?? 0 : 0,
    });
    pendingIns = [];
  }
  if (pendingIns.length && view.length) view[view.length - 1].trailing = pendingIns;
  return view;
}

/**
 * 流暢さ。音素単位の詳しい評価は要らないので、
 * 「間が空きすぎていないか」と「速さが極端でないか」の2点だけ見る。
 */
function measureFluency(recognized, refLen) {
  if (recognized.length < 2) return { level: 'unknown', pauses: 0, rate: 0 };
  const start = recognized[0].start;
  const end = recognized[recognized.length - 1].end;
  const span = Math.max(end - start, 0.01);

  let pauses = 0;
  let longest = 0;
  for (let i = 1; i < recognized.length; i++) {
    const gap = recognized[i].start - recognized[i - 1].end;
    if (gap > 0.28) pauses++;
    if (gap > longest) longest = gap;
  }

  const rate = recognized.length / span; // 音素/秒
  // 小学生の音読は 8-14 音素/秒あたり。外れるほど下げる。
  const rateOk = rate >= 6 && rate <= 16;
  let level = pauses === 0 && rateOk ? 'smooth' : pauses <= 2 && rate >= 4 ? 'ok' : 'choppy';

  // 音がほとんど拾えていないのに「すらすら」と出るのは体験として嘘なので、
  // 読めた量が足りないときは上を抑える。
  const coverage = recognized.length / Math.max(refLen, 1);
  if (coverage < 0.8 && level === 'smooth') level = 'ok';

  return { level, pauses, longest, rate, span, coverage };
}

const clamp01 = (x) => Math.max(0, Math.min(1, x));
