// espeak-ng の IPA 出力を、モデルの vocab に載っている音素トークン列へ切り分ける。
// gen-reference / gen-en-inventory の両方から使う。

const ZWJ = '‍';
// 直前の字にくっつく修飾記号（長音・シラビック・鼻音化など）
const MODIFIER = /[ːˑ̩̞̤̪̃ʰʲʷ͜͡]/;

/**
 * espeak-ng --ipa=3 の出力を音素単位に切る。
 *
 * --ipa=3 は二重母音や音節主音的子音の内側を ZWJ(U+200D) で綴じてくれるので、
 * 「ZWJ で繋がっている / 修飾記号である」以外の文字が来たら新しい音素、
 * という規則だけで正しく割れる。最長一致より確実で、`Let's` を
 * 破擦音 ts と読み違えるような多言語 vocab 由来の事故も起きない。
 */
export function tokenize(ipa, tokens) {
  const s = ipa.replace(/[ˈˌ]/g, '').replace(/\s+/g, '');
  const units = [];
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === ZWJ) continue;
    const joined = i > 0 && s[i - 1] === ZWJ;
    if (units.length && (joined || MODIFIER.test(c))) units[units.length - 1] += c;
    else units.push(c);
  }
  return units.filter((u) => {
    if (tokens.has(u)) return true;
    console.error(`[warn] vocab にない音素を捨てました: ${JSON.stringify(u)} (in ${ipa})`);
    return false;
  });
}
