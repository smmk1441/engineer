#!/bin/bash
# LibriSpeech を取ってきて 16kHz モノラル wav に変換する。
#
#   bash tools/fetch-librispeech.sh
#
# 蒸留の学習データ用。教師がラベルを作るので書き起こしは使わない。
# dev-clean + test-clean = 約10.8時間 / 80話者。
# TTS 36分・5話者に比べて、量で18倍、話者の多様性で16倍。
#
# ライセンスは CC BY 4.0（商用利用可）。https://www.openslr.org/12
# FLAC の変換は macOS 標準の afconvert で足りる（ffmpeg 不要）。

set -e
cd "$(dirname "$0")/.."
DL=work/librispeech
OUT=work/corpus-ls
mkdir -p "$DL" "$OUT"

for part in dev-clean test-clean; do
  tgz="$DL/$part.tar.gz"
  if [ ! -f "$tgz" ]; then
    echo "ダウンロード: $part（約340MB）"
    curl -L --progress-bar -o "$tgz" "https://www.openslr.org/resources/12/$part.tar.gz"
  fi
  if [ ! -d "$DL/LibriSpeech/$part" ]; then
    echo "展開: $part"
    tar xzf "$tgz" -C "$DL"
  fi
done

echo "16kHz wav へ変換中…"
n=0
find "$DL/LibriSpeech" -name '*.flac' | while read -r f; do
  base=$(basename "$f" .flac)
  dst="$OUT/$base.wav"
  [ -f "$dst" ] && continue
  afconvert -f WAVE -d LEI16@16000 -c 1 "$f" "$dst" >/dev/null 2>&1 || continue
  n=$((n + 1))
  [ $((n % 500)) -eq 0 ] && echo "  $n 件"
done

echo "完了: $(ls "$OUT" | wc -l | tr -d ' ') ファイル / $(du -sh "$OUT" | cut -f1)"
python3 -c "
import wave, glob
fs = glob.glob('$OUT/*.wav')
t = sum(wave.open(f).getnframes() for f in fs) / 16000
print(f'  合計 {t/3600:.1f} 時間 / 推定 {t*50:,.0f} フレーム')
"
