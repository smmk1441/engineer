#!/bin/bash
# スピーキング問題の音声を作る。
#
#   bash tools/gen-speaking-audio.sh
#
# 音読は「お手本」、対話は「ジェーン先生のしつ問」。発表には流す音声が無い。
# 端末の TTS に任せず同梱する理由は tools/gen-model-audio.sh と同じ
# （声の当たり外れで点が 0.98〜0.08 まで動く）。商用では要差し替え。
set -e
cd "$(dirname "$0")/.."
VOICE=${VOICE:-Samantha}
RATE=${RATE:-160}
OUT=audio/speaking
mkdir -p "$OUT"

python3 -c "
import json
for q in json.load(open('data/speaking.json')):
    t = q.get('ask') or (q.get('target') or {}).get('text')
    if t: print(q['id'] + '\t' + t)
" | while IFS=$'\t' read -r id text; do
  [ -z "$id" ] && continue
  say -v "$VOICE" -r "$RATE" -o "$OUT/tmp.aiff" "$text"
  afconvert -f m4af -d aac -b 48000 -c 1 "$OUT/tmp.aiff" "$OUT/$id.m4a" >/dev/null
  rm -f "$OUT/tmp.aiff"
  echo "$OUT/$id.m4a  <- $text"
done
du -sh "$OUT"
