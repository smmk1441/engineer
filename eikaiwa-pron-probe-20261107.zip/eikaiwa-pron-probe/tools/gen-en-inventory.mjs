// 英語音素の在庫リストを作る。
//
// 使っているモデル (wav2vec2-lv-60-espeak-cv-ft) の vocab は 392 トークンの
// 多言語 IPA で、中国語の声調付き母音なども混ざっている。実際、英語音声に
// 対して ɑ5 / ts.h のような中国語トークンを吐いた例が計測中に出た。
// 英語だけに絞った id リストを作り、推論時に logits をマスクする。
//
//   node tools/gen-en-inventory.mjs > data/en-phones.json

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { tokenize } from './ipa.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'vocab.json'), 'utf8'));
const tokens = new Set(Object.keys(vocab).filter((t) => !t.startsWith('<')));

// 辞書の全語を一括で espeak に通し、出てきた音素をすべて集める。
const WORDLIST = '/usr/share/dict/words';
const words = fs.readFileSync(WORDLIST, 'utf8').split('\n').filter((w) => /^[a-z]{2,}$/.test(w));
console.error(`${words.length} words from ${WORDLIST}`);

const found = new Map();
const CHUNK = 2000;
for (let i = 0; i < words.length; i += CHUNK) {
  const chunk = words.slice(i, i + CHUNK);
  const out = execFileSync('espeak-ng', ['-v', 'en-us', '-q', '--ipa=3'], {
    input: chunk.join('\n'),
    encoding: 'utf8',
    maxBuffer: 1 << 28,
  });
  for (const line of out.split('\n')) {
    if (!line.trim()) continue;
    for (const p of tokenize(line, tokens)) found.set(p, (found.get(p) || 0) + 1);
  }
}

// 出現1回きりのものは表記ゆれや外来語綴りの事故なので落とす。
const MIN = 20;
const kept = [...found.entries()].filter(([, n]) => n >= MIN).sort((a, b) => b[1] - a[1]);
const dropped = [...found.entries()].filter(([, n]) => n < MIN);

console.error(`phones kept: ${kept.length}  dropped(<${MIN}): ${dropped.map(([p, n]) => `${p}:${n}`).join(' ')}`);

const phones = kept.map(([p]) => p);
process.stdout.write(JSON.stringify({ phones, ids: phones.map((p) => vocab[p]) }, null, 2) + '\n');
