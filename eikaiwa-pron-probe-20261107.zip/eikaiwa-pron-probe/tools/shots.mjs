// デモ用スクリーンショットを撮る。
//
//   node tools/serve.mjs &
//   node tools/shots.mjs        -> docs/shot-*.png
//
// 星3つ / 星2つ / 星1つ が同じ画面でどう見えるかを並べて確認するため、
// 話者の違う音声を同じ課題文に流し込んでいる。

import puppeteer from 'puppeteer-core';
import path from 'node:path';
import fs from 'node:fs';
import { readWav } from '../bench/wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const BASE = process.env.BASE || 'http://localhost:8080';

const SHOTS = [
  { name: 'native', file: 's1_Samantha.wav', sentence: 0, note: 'ネイティブ音声' },
  { name: 'accented', file: 's1_Kyoko.wav', sentence: 0, note: '日本語訛り' },
  { name: 'weak', file: 's4_Kyoko.wav', sentence: 3, note: '崩れた発音' },
];

fs.mkdirSync(path.join(ROOT, 'docs'), { recursive: true });

const browser = await puppeteer.launch({
  executablePath: CHROME,
  headless: true,
  userDataDir: path.join(ROOT, '.chrome-profile'),
  args: ['--no-sandbox', '--font-render-hinting=none'],
});
const page = await browser.newPage();
await page.setViewport({ width: 880, height: 1180, deviceScaleFactor: 2 });
await page.goto(`${BASE}/?device=wasm&dtype=q8&probe=1`, { waitUntil: 'domcontentloaded' });
await page.waitForFunction('!!self.__probe', { timeout: 15 * 60 * 1000, polling: 500 });

for (const shot of SHOTS) {
  const samples = Array.from(readWav(path.join(ROOT, 'bench/audio', shot.file)).audio);
  const r = await page.evaluate((a, i) => self.__probe.run(a, i), samples, shot.sentence);
  await new Promise((res) => setTimeout(res, 800));
  const out = path.join(ROOT, `docs/shot-${shot.name}.png`);
  await page.screenshot({ path: out });
  console.log(`${shot.note.padEnd(12)} ★${r.score.stars}  acc=${r.score.accuracy.toFixed(2)}  -> ${path.relative(ROOT, out)}`);
}

// 起動中の画面も1枚
const fresh = await browser.newPage();
await fresh.setViewport({ width: 880, height: 700, deviceScaleFactor: 2 });
await fresh.goto(`${BASE}/?device=wasm&dtype=fp32&probe=1`, { waitUntil: 'domcontentloaded' });
await new Promise((res) => setTimeout(res, 2500));
await fresh.screenshot({ path: path.join(ROOT, 'docs/shot-loading.png') });
console.log('ロード中 -> docs/shot-loading.png');

await browser.close();
