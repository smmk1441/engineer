#!/bin/bash
# リスニング問題の設問音声を作る。
#
#   bash tools/gen-listening-audio.sh
#
# 端末の TTS に任せず音声ファイルとして同梱する理由は tools/gen-model-audio.sh と同じ。
# 商用では要差し替え（docs/LICENSES.md）。
set -e
cd "$(dirname "$0")/.."
VOICE=${VOICE:-Samantha}
RATE=${RATE:-160}
OUT=audio/listen
mkdir -p "$OUT"

# 生成済みの data/listening.json から読む。
# gen-listening.mjs を import すると、その場で JSON を標準出力へ吐くので混ざる。
python3 -c "
import json
for q in json.load(open('data/listening.json')): print(q['id'] + '\t' + q['prompt'])
" | while IFS=$'\t' read -r id text; do
  [ -z "$id" ] && continue
  say -v "$VOICE" -r "$RATE" -o "$OUT/tmp.aiff" "$text"
  afconvert -f m4af -d aac -b 48000 -c 1 "$OUT/tmp.aiff" "$OUT/$id.m4a" >/dev/null
  rm -f "$OUT/tmp.aiff"
  echo "$OUT/$id.m4a  <- $text"
done
du -sh "$OUT"
