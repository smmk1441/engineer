// リスニング問題のデータを作る。
//
//   node tools/gen-listening.mjs > data/listening.json
//   bash tools/gen-listening-audio.sh        # 設問の読み上げ音声
//
// 設問（英語の音声）を聞いて、選択肢のうち正しいものを声に出して答える形式。
// 選択肢が有限なので開放語彙の音声認識は要らない。候補それぞれについて
// 「この音声をこの文として読ませるのにどれだけ無理があるか」を測り、
// いちばん無理の無いものを選ぶ（docs/MEASUREMENTS.md §7-2）。

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { tokenize } from './ipa.mjs';
import { variantsFor } from './variants.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');

export const QUESTIONS = [
  {
    id: 'q1',
    prompt: 'It is sunny today.',
    ja: 'きょうの てんきは？',
    choices: [
      { text: "It's sunny.", ja: 'はれ' },
      { text: "It's rainy.", ja: 'あめ' },
      { text: "It's cloudy.", ja: 'くもり' },
    ],
    answer: 0,
  },
  {
    id: 'q2',
    prompt: 'I have a cat and a dog.',
    ja: 'なんの どうぶつを かっている？',
    choices: [
      { text: 'A cat and a dog.', ja: 'ねこ と いぬ' },
      { text: 'A cat and a bird.', ja: 'ねこ と とり' },
      { text: 'A dog and a rabbit.', ja: 'いぬ と うさぎ' },
    ],
    answer: 0,
  },
  {
    id: 'q3',
    prompt: 'My birthday is in May.',
    ja: 'たんじょうびは いつ？',
    choices: [
      { text: 'In May.', ja: '5月' },
      { text: 'In March.', ja: '3月' },
      { text: 'In April.', ja: '4月' },
    ],
    answer: 0,
  },
  {
    id: 'q4',
    prompt: 'I go to school by bus.',
    ja: 'どうやって がっこうへ いく？',
    choices: [
      { text: 'By bus.', ja: 'バス' },
      { text: 'By bike.', ja: 'じてんしゃ' },
      { text: 'On foot.', ja: 'あるいて' },
    ],
    answer: 0,
  },
  {
    id: 'q5',
    prompt: 'I want to be a teacher.',
    ja: 'なりたいものは？',
    choices: [
      { text: 'A teacher.', ja: 'せんせい' },
      { text: 'A doctor.', ja: 'おいしゃさん' },
      { text: 'A soccer player.', ja: 'サッカーせんしゅ' },
    ],
    answer: 0,
  },
];

const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const tokens = new Set(Object.keys(vocab).filter((t) => !t.startsWith('<')));
const espeak = (t) => execFileSync('espeak-ng', ['-v', 'en-us', '-q', '--ipa=3', t], { encoding: 'utf8' }).trim();

/** 発音チャレンジと同じ形（words / phones / alts）に揃える */
function analyse(text) {
  const words = text.split(/\s+/).map((w) => ({
    display: w,
    phones: tokenize(espeak(w.replace(/[.,!?]/g, '')), tokens),
  }));
  for (let i = 0; i < words.length; i++) {
    words[i].alts = variantsFor(
      words[i].display, words[i].phones,
      words[i - 1]?.phones ?? [], words[i + 1]?.phones ?? []
    ).map((v) => v.filter((p) => tokens.has(p)));
  }
  return {
    words,
    phones: words.flatMap((w) => w.phones),
    alts: words.flatMap((w) => w.alts),
  };
}

const out = QUESTIONS.map((q) => ({
  ...q,
  audio: `audio/listen/${q.id}.m4a`,
  choices: q.choices.map((c) => ({ ...c, ...analyse(c.text) })),
}));

process.stdout.write(JSON.stringify(out, null, 2) + '\n');
