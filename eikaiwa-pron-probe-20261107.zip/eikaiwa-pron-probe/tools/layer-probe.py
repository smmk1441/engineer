#!/usr/bin/env python3
"""Transformer を何層まで削れるかを測る。

    python3 tools/layer-probe.py

wav2vec2-large のパラメータは 95.7% が Transformer 24層にある
（docs/MEASUREMENTS.md §7）。ここを削らないとモデルは小さくならない。
では何層あれば足りるのか、を先に知りたい。

PyTorch は使わない。ONNX グラフに各層の出力を追加の出力として生やし、
onnxruntime で1回走らせれば全層の中間表現が同時に取れる。
そこから先（layer_norm と lm_head）は重みを取り出して numpy で掛ける。

2通りで測る:

  そのまま切る   層Nの出力を、元のまま layer_norm + lm_head に通す。
                「学習なしで層を削ったらどうなるか」。実際にはこれで動くとは
                 期待していないが、下限として測っておく。

  線形プローブ   層Nの出力に、新しい線形層を当てはめて教師の出力を再現させる。
                「その層に音素の情報がどれだけ残っているか」を見る。
                 蒸留で到達しうる上限の目安になる。

現行モデルには一切触らない。改造した ONNX は work/ に出す。
"""
import json
import os
import sys
import time

import numpy as np
import onnx
import onnxruntime as ort
from onnx import helper

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, '.hfcache/onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX/onnx/model.onnx')
WORK = os.path.join(ROOT, 'work')
PROBED = os.path.join(WORK, 'model-with-hidden.onnx')
N_LAYERS = 24


def build_probed_model():
    """各層の出力をグラフの出力に足したモデルを作る。元ファイルは触らない。"""
    if os.path.exists(PROBED):
        return
    os.makedirs(WORK, exist_ok=True)
    print('中間出力つきモデルを作成中…', flush=True)
    m = onnx.load(SRC)
    for L in range(N_LAYERS):
        name = f'/wav2vec2/encoder/layers.{L}/Add_1_output_0'
        m.graph.output.append(helper.make_tensor_value_info(name, onnx.TensorProto.FLOAT, None))
    onnx.save(m, PROBED)
    print(f'  -> {PROBED} ({os.path.getsize(PROBED)/1e6:.0f} MB)', flush=True)


def head_weights():
    """最終の layer_norm と lm_head の重みを取り出す。

    lm_head の行列は ONNX 変換で `onnx::MatMul_3745` のような名前になっていて
    元の名前が残らない。名前ではなく形（1024×392）で拾う。
    """
    m = onnx.load(SRC)
    init = {i.name: onnx.numpy_helper.to_array(i) for i in m.graph.initializer}

    gamma = init['wav2vec2.encoder.layer_norm.weight']
    beta = init['wav2vec2.encoder.layer_norm.bias']
    b = init['lm_head.bias']
    cands = [a for k, a in init.items() if a.ndim == 2 and set(a.shape) == {1024, len(b)}]
    assert len(cands) == 1, f'lm_head の行列が {len(cands)} 個見つかった'
    W = cands[0]
    if W.shape[0] != 1024:
        W = W.T
    return gamma, beta, W, b


def layer_norm(x, gamma, beta, eps=1e-5):
    mu = x.mean(-1, keepdims=True)
    var = ((x - mu) ** 2).mean(-1, keepdims=True)
    return (x - mu) / np.sqrt(var + eps) * gamma + beta


def read_wav(path):
    import wave
    import struct
    with wave.open(path) as w:
        n = w.getnframes()
        raw = w.readframes(n)
    a = np.frombuffer(raw, dtype='<i2').astype(np.float32) / 32768.0
    return a


def normalize(a):
    """Wav2Vec2FeatureExtractor の do_normalize と同じ（平均0・分散1）"""
    return (a - a.mean()) / np.sqrt(a.var() + 1e-7)


def log_softmax(x):
    x = x - x.max(-1, keepdims=True)
    return x - np.log(np.exp(x).sum(-1, keepdims=True))


def main():
    build_probed_model()
    gamma, beta, W, b = head_weights()
    print(f'head: layer_norm {gamma.shape}, lm_head {W.shape} + {b.shape}', flush=True)

    en = json.load(open(os.path.join(ROOT, 'data/en-phones.json')))
    vocab = json.load(open(os.path.join(ROOT, 'data/vocab.json')))
    keep = np.array([vocab['<pad>']] + [i for i in en['ids'] if i != vocab['<pad>']])
    K = len(keep)

    corpus = os.path.join(WORK, 'corpus')
    files = sorted(f for f in os.listdir(corpus) if f.endswith('.wav'))
    if not files:
        sys.exit('work/corpus に音声がありません。bash work/make-corpus.sh を先に。')

    # 文で分ける。同じ文の別話者が学習と評価にまたがると、当てはめが甘くなる。
    def sid(f):
        return f.split('_')[0]
    ids = sorted({sid(f) for f in files})
    test_ids = set(ids[::5])          # 5文に1文を評価用
    train = [f for f in files if sid(f) not in test_ids]
    test = [f for f in files if sid(f) in test_ids]
    print(f'{len(files)} ファイル → 学習 {len(train)} / 評価 {len(test)}', flush=True)

    print('モデル読み込み中（1.3GB）…', flush=True)
    t0 = time.time()
    sess = ort.InferenceSession(PROBED, providers=['CPUExecutionProvider'])
    print(f'  {time.time()-t0:.1f}s', flush=True)
    out_names = ['logits'] + [f'/wav2vec2/encoder/layers.{L}/Add_1_output_0' for L in range(N_LAYERS)]

    D = 1024
    # 線形プローブ用の正規方程式を層ごとに積む。中間表現そのものは持たない
    # （全部保持すると 10GB を超える）。
    XtX = np.zeros((N_LAYERS, D + 1, D + 1), np.float64)
    XtY = np.zeros((N_LAYERS, D + 1, K), np.float64)
    # そのまま切った場合の集計
    naive_agree = np.zeros(N_LAYERS, np.int64)
    naive_kl = np.zeros(N_LAYERS, np.float64)
    naive_n = 0
    # 評価用は float16 で保持（これなら数百MBに収まる）
    test_h, test_lp = [], []

    t0 = time.time()
    for i, f in enumerate(files):
        a = normalize(read_wav(os.path.join(corpus, f)))[None, :]
        res = sess.run(out_names, {'input_values': a})
        tlp = log_softmax(res[0][0][:, keep]).astype(np.float32)
        targ = tlp.argmax(-1)
        hs = [r[0] for r in res[1:]]

        if f in test_ids or sid(f) in test_ids:
            test_h.append(np.stack(hs).astype(np.float16))
            test_lp.append(tlp)
            # そのまま切った場合は評価用だけで測る
            for L in range(N_LAYERS):
                lp = log_softmax((layer_norm(hs[L], gamma, beta) @ W + b)[:, keep])
                naive_agree[L] += int((lp.argmax(-1) == targ).sum())
                naive_kl[L] += float((np.exp(tlp) * (tlp - lp)).sum())
            naive_n += len(targ)
        else:
            for L in range(N_LAYERS):
                X1 = np.concatenate([hs[L], np.ones((len(hs[L]), 1), np.float32)], 1).astype(np.float64)
                XtX[L] += X1.T @ X1
                XtY[L] += X1.T @ tlp
        if (i + 1) % 50 == 0:
            el = time.time() - t0
            print(f'\r  推論 {i+1}/{len(files)}  {el:.0f}s (残り {el/(i+1)*(len(files)-i-1):.0f}s)', end='', flush=True)
    print()

    print('\n=== そのまま切った場合（学習なし） ===')
    print('層   フレーム一致率   教師との KL')
    naive = {}
    for L in range(N_LAYERS):
        naive[L] = (naive_agree[L] / naive_n, naive_kl[L] / naive_n)
        if L >= 15 or L % 4 == 3:
            print(f'{L+1:>3}   {100*naive[L][0]:>10.1f}%   {naive[L][1]:>10.3f}')

    print('\n=== 線形プローブ（層Nに新しい出力層を当てはめる） ===')
    print('   その層に音素の情報がどれだけ残っているか。蒸留で狙える上限の目安')
    print('層   フレーム一致率   教師との KL')
    probe = {}
    for L in range(N_LAYERS):
        A = XtX[L] + 1.0 * np.eye(D + 1)
        Wp = np.linalg.solve(A, XtY[L]).astype(np.float32)
        agree, kl, n = 0, 0.0, 0
        for h16, tlp in zip(test_h, test_lp):
            h = h16[L].astype(np.float32)
            h1 = np.concatenate([h, np.ones((len(h), 1), np.float32)], 1)
            lp = log_softmax(h1 @ Wp)
            agree += int((lp.argmax(-1) == tlp.argmax(-1)).sum())
            kl += float((np.exp(tlp) * (tlp - lp)).sum())
            n += len(lp)
        probe[L] = (agree / n, kl / n)
        if L >= 15 or L % 4 == 3:
            print(f'{L+1:>3}   {100*probe[L][0]:>10.1f}%   {probe[L][1]:>10.3f}')

    json.dump({'naive': {str(k): list(v) for k, v in naive.items()},
               'probe': {str(k): list(v) for k, v in probe.items()},
               'frames': {'train': int(naive_n), 'test': int(naive_n)},
               'files': len(files)},
              open(os.path.join(ROOT, 'docs/layer-probe.json'), 'w'), indent=2)
    print('\n-> docs/layer-probe.json')


if __name__ == '__main__':
    main()
