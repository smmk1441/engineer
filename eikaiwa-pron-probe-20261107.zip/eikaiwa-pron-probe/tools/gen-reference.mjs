// 課題文 -> 正解音素列(JSON) を作るビルド時スクリプト。
//
// espeak-ng で書記素->IPA に変換し、モデルの vocab.json に載っている
// トークン単位へ最長一致で切り直す。単語ごとに音素を持たせるので、
// アライメント結果を単語の色分けに戻せる。
//
//   node tools/gen-reference.mjs > data/reference.json
//
// 本番では課題文の登録時にサーバ側で一度だけ回せばよい類の処理。

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { tokenize } from './ipa.mjs';
import { variantsFor } from './variants.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const VOCAB_URL = 'https://huggingface.co/onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX/resolve/main/vocab.json';

const SENTENCES = [
  { id: 's1', text: 'I like apples.', ja: 'わたしは りんごが すきです。' },
  { id: 's2', text: 'This is my cat.', ja: 'これは わたしの ねこです。' },
  { id: 's3', text: 'How are you today?', ja: 'きょうは ちょうし どうですか？' },
  { id: 's4', text: "Let's play soccer.", ja: 'サッカーを しようよ。' },
  { id: 's5', text: 'My name is Ken.', ja: 'わたしの なまえは ケンです。' },
  { id: 's6', text: 'I go to school by bus.', ja: 'バスで がっこうへ いきます。' },
  { id: 's7', text: 'What time do you usually get up in the morning?', ja: 'あさは いつも なんじに おきますか？' },
  { id: 's8', text: 'Thursday', ja: 'もくようび' },
  { id: 's9', text: 'My best memory is the field trip', ja: '私のいちばんの思い出は遠足です' },
];

async function loadVocab() {
  const cached = path.join(ROOT, 'data', 'vocab.json');
  if (fs.existsSync(cached)) return JSON.parse(fs.readFileSync(cached, 'utf8'));
  const res = await fetch(VOCAB_URL);
  const v = await res.json();
  fs.writeFileSync(cached, JSON.stringify(v));
  return v;
}

function espeak(text) {
  return execFileSync('espeak-ng', ['-v', 'en-us', '-q', '--ipa=3', text], { encoding: 'utf8' }).trim();
}

const vocab = await loadVocab();
const tokens = new Set(Object.keys(vocab).filter((t) => !t.startsWith('<')));

const out = SENTENCES.map((s) => {
  const words = s.text.split(/\s+/).map((w) => ({
    display: w,
    phones: tokenize(espeak(w.replace(/[.,!?]/g, '')), tokens),
  }));

  // 許容する発音の異形。辞書形と自然な発話のずれで減点しないため。
  for (let i = 0; i < words.length; i++) {
    words[i].alts = variantsFor(
      words[i].display,
      words[i].phones,
      words[i - 1]?.phones ?? [],
      words[i + 1]?.phones ?? []
    ).map((v) => v.filter((p) => tokens.has(p)));
  }

  return {
    ...s,
    words,
    phones: words.flatMap((w) => w.phones),
    alts: words.flatMap((w) => w.alts),
  };
});

process.stdout.write(JSON.stringify(out, null, 2) + '\n');
