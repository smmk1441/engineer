// 教材の問題サンプル（音読 / 対話 / 発表）をデータにする。
//
//   node tools/gen-speaking.mjs > data/speaking.json
//   bash tools/gen-speaking-audio.sh        # 設問の読み上げ音声
//
// 3つの種別があるが、**採点の経路は1本**にしてある。
//
//   音読  お手本と同じ文を言う            -> 正解文は最初から既知
//   対話  質問に答える                    -> 答えを選んでから言う。選んだ時点で既知
//   発表  メモを見て自分のことを伝える     -> 同上
//
// 対話と発表で「何を答えたか」を機械に当てさせる手もあるが、測ったら
// 日本語訛り＋雑音で 40〜60% まで落ちた（docs/MEASUREMENTS.md §7-9）。
// **先に選ばせれば正解文が既知になり、音読と同じ精度になる。**
// 「何を答えるか考える」段階は画面の側に残るので、教材として失うものは無い。

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { tokenize } from './ipa.mjs';
import { variantsFor } from './variants.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');

/** 答えの選択肢。枠に語を入れて文にする。 */
const SPORTS = [
  ['baseball', 'やきゅう', '⚾'], ['soccer', 'サッカー', '⚽'],
  ['tennis', 'テニス', '🎾'], ['swimming', 'すいえい', '🏊'],
  ['basketball', 'バスケ', '🏀'],
];
const TREASURES = [
  ['book', 'ほん', '📕'], ['bag', 'かばん', '🎒'],
  ['cap', 'ぼうし', '🧢'], ['watch', 'とけい', '⌚'],
  ['soccer ball', 'サッカーボール', '⚽'],
];
const COLORS = [
  ['blue', 'あお', '🔵'], ['red', 'あか', '🔴'],
  ['green', 'みどり', '🟢'], ['yellow', 'きいろ', '🟡'],
  ['white', 'しろ', '⚪'],
];
const ACTIVITIES = [
  ['dancing', 'ダンス', '💃'], ['baseball', 'やきゅう', '⚾'],
  ['soccer', 'サッカー', '⚽'], ['swimming', 'すいえい', '🏊'],
  ['reading', 'どくしょ', '📖'],
];

const like = (xs) => xs.map(([w, ja, icon]) => ({ text: `I like ${w}.`, ja, icon }));
const treasure = (xs) => xs.map(([w, ja, icon]) => ({ text: `My treasure is this ${w}.`, ja, icon }));
/** 選択肢の並び。先頭を正解にしない（押す位置を覚えさせない） */
const rotate = (xs, n) => [...xs.slice(n), ...xs.slice(0, n)];

export const QUESTIONS = [
  {
    id: 'p1', group: '練習問題', no: 1, type: 'read',
    scene: null,
    instruction: 'お手本を聞いて、イラストにあう英単語を、声に出して言ってみよう。',
    icon: '⚾', target: 'baseball',
  },
  {
    id: 'p2', group: '練習問題', no: 2, type: 'read',
    scene: 'リサと好きなスポーツについて話しているよ。',
    instruction: 'お手本を聞いて、お手本と同じ英文を、声に出して言ってみよう。',
    icon: '⚾', target: 'I like baseball.',
  },
  {
    id: 'p3', group: '練習問題', no: 3, type: 'dialog',
    scene: '教室でジェーン先生と好きなスポーツについて話しているよ。',
    instruction: 'ジェーン先生のしつ問に英語で答えよう。',
    ask: 'What sport do you like?', askJa: 'すきな スポーツは なに？',
    choices: like(rotate(SPORTS, 2)),
  },
  {
    id: 'p4', group: '練習問題', no: 4, type: 'read',
    scene: 'リサと宝物について話しているよ。',
    instruction: 'お手本を聞いて、お手本と同じ英文を、声に出して言ってみよう。',
    icon: '📕', target: 'My treasure is this book.',
  },
  {
    id: 'p5', group: '練習問題', no: 5, type: 'dialog',
    scene: '教室でジェーン先生と宝物について話しているよ。',
    instruction: 'ジェーン先生のしつ問に英語で答えよう。',
    ask: 'What is your treasure?', askJa: 'あなたの たからものは なに？',
    choices: treasure(rotate(TREASURES, 1)),
  },
  {
    id: 'm1', group: 'まとめ問題', no: 1, type: 'read',
    scene: 'リサと好きな色について話しているよ。',
    instruction: 'お手本を聞いて、お手本と同じ英文を、声に出して言ってみよう。',
    icon: '🔴', target: 'I like red.',
  },
  {
    id: 'm2', group: 'まとめ問題', no: 2, type: 'dialog',
    // 元の表では問題文が「週末の過ごし方」だが、音声も答えも色の話。
    // 重複シートでも同じ問題文のまま音声だけ別物だったので、流用し残しと判断した。
    scene: '教室でジェーン先生と好きな色について話しているよ。',
    instruction: 'ジェーン先生のしつ問に英語で答えよう。',
    ask: 'What color do you like?', askJa: 'すきな いろは なに？',
    choices: like(COLORS),
  },
  {
    id: 'm3', group: 'まとめ問題', no: 3, type: 'read',
    scene: 'リサと宝物について話しているよ。',
    instruction: 'お手本を聞いて、お手本と同じ英文を、声に出して言ってみよう。',
    icon: '🎒', target: 'My treasure is this bag.',
  },
  {
    id: 'm4', group: 'まとめ問題', no: 4, type: 'dialog',
    scene: '教室でジェーン先生と宝物について話しているよ。',
    instruction: 'ジェーン先生のしつ問に英語で答えよう。',
    ask: 'What is your treasure?', askJa: 'あなたの たからものは なに？',
    choices: treasure(rotate(TREASURES, 4)),
  },
  {
    id: 'm5', group: 'まとめ問題', no: 5, type: 'present',
    scene: 'パーティー会場であなたのことを発表するよ。',
    instruction: 'メモを見てあなたのことを伝えよう。',
    memo: 'あなたの好きなスポーツを文で伝える',
    choices: like(ACTIVITIES),
  },
];

/**
 * 2文で答える問題。
 *
 * **教材の表には無い。** いただいた例題（Who is that? / That is Elly. She is kind.）
 * から起こしたもので、残り4問はこちらで考えた例。
 *
 * lead は前置きで、**言っても言わなくてもよく、採点にも入らない**。
 * 採点するのは TGT（choices の文）だけ（docs/MEASUREMENTS.md §7-11）。
 * そのぶん lead には固有名詞を置ける — 名前が何であっても点は変わらない。
 *
 * 文の作りを散らしてある。同じ形ばかりだと、形式が通用する範囲が分からない。
 */
const TWO_SENTENCE = [
  {
    id: 't1',
    scene: '教室でジェーン先生と友だちについて話しているよ。',
    ask: 'Who is that?', askJa: 'あの人は だれ？',
    lead: 'That is Elly.',
    choices: [['She is kind.', 'やさしい', '😊'],
              ['She is funny.', 'おもしろい', '😄'],
              ['She is cute.', 'かわいい', '🥰']],
  },
  {
    id: 't2',
    scene: '行ってみたい国について話しているよ。',
    ask: 'Where do you want to go?', askJa: 'どこへ 行きたい？',
    lead: 'I want to go to Australia.',
    choices: [['I want to see koalas.', 'コアラが 見たい', '🐨'],
              ['I want to swim in the sea.', '海で およぎたい', '🏊'],
              ['I want to eat ice cream.', 'アイスが 食べたい', '🍦']],
  },
  {
    id: 't3',
    scene: '週末のことを話しているよ。',
    ask: 'What did you do last weekend?', askJa: 'しゅうまつ 何を した？',
    lead: 'I went to the zoo.',
    choices: [['It was fun.', 'たのしかった', '😆'],
              ['It was exciting.', 'わくわくした', '🤩'],
              ['It was great.', 'さいこうだった', '👍']],
  },
  {
    id: 't4',
    scene: 'なりたいものについて話しているよ。',
    ask: 'What do you want to be?', askJa: 'なりたいものは なに？',
    lead: 'I want to be a vet.',
    choices: [['I like animals.', 'どうぶつが すき', '🐶'],
              ['I like science.', 'りかが すき', '🔬'],
              ['I like helping people.', '人を たすけるのが すき', '🤝']],
  },
  {
    id: 't5',
    scene: '自分の町をしょうかいしているよ。',
    ask: 'Tell me about your town.', askJa: 'あなたの町を おしえて',
    lead: 'We have a big park.',
    choices: [['It is beautiful.', 'きれい', '🌸'],
              ['It is famous.', 'ゆうめい', '⭐'],
              ['It is popular.', '人気がある', '🎉']],
  },
];

for (const [i, q] of TWO_SENTENCE.entries()) {
  QUESTIONS.push({
    id: q.id, group: '2文で答える', no: i + 1, type: 'dialog',
    scene: q.scene,
    instruction: 'ジェーン先生のしつ問に英語で答えよう。',
    ask: q.ask, askJa: q.askJa,
    lead: q.lead,
    choices: q.choices.map(([text, ja, icon]) => ({ text, ja, icon })),
  });
}

// --- 音素列 ---

const vocab = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/vocab.json'), 'utf8'));
const tokens = new Set(Object.keys(vocab).filter((t) => !t.startsWith('<')));
const espeak = (t) => execFileSync('espeak-ng', ['-v', 'en-us', '-q', '--ipa=3', t], { encoding: 'utf8' }).trim();

/** 発音チャレンジと同じ形（words / phones / alts）に揃える */
function analyse(text) {
  const words = text.split(/\s+/).map((w) => ({
    display: w,
    phones: tokenize(espeak(w.replace(/[.,!?]/g, '')), tokens),
  }));
  for (let i = 0; i < words.length; i++) {
    words[i].alts = variantsFor(
      words[i].display, words[i].phones,
      words[i - 1]?.phones ?? [], words[i + 1]?.phones ?? []
    ).map((v) => v.filter((p) => tokens.has(p)));
  }
  return {
    text, words,
    phones: words.flatMap((w) => w.phones),
    alts: words.flatMap((w) => w.alts),
  };
}

/**
 * 前置きのある答えを、2通りの貼り付け方で用意する。
 *
 *   target  TGT の文だけ。前置きを言わなかった子向け
 *   full    前置き＋TGT。from から後ろだけを採点する
 *
 * どちらが正しいかは言ってみるまで分からないので、画面側で両方やって
 * 良いほうを採る（docs/MEASUREMENTS.md §7-11）。
 */
function withLead(c, lead) {
  if (!lead) return { ...c, ...analyse(c.text) };
  const full = analyse(`${lead} ${c.text}`);
  const leadN = analyse(lead).phones.length;
  // 前置きの単語は採点に入らない。画面で区別して見せるための目印。
  const leadWords = lead.split(/\s+/).length;
  full.words.forEach((w, i) => { if (i < leadWords) w.context = true; });
  full.from = leadN;
  return { ...c, ...analyse(c.text), lead, full };
}

const out = QUESTIONS.map((q) => ({
  ...q,
  // 音読は「お手本」、対話は「先生のしつ問」。発表は流す音声が無い。
  audio: q.type === 'present' ? null : `audio/speaking/${q.id}.m4a`,
  ...(q.target ? { target: analyse(q.target) } : {}),
  ...(q.choices ? { choices: q.choices.map((c) => withLead(c, q.lead)) } : {}),
}));

process.stdout.write(JSON.stringify(out, null, 2) + '\n');
