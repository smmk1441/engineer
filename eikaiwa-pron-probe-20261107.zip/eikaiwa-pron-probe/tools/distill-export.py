#!/usr/bin/env python3
"""蒸留した生徒モデルを ONNX へ書き出し、量子化して、評価用の出力を作る。

    work/venv/bin/python tools/distill-export.py --layers 12
    node bench/distill-ladder.mjs

現行モデルには一切触らない。生成物はすべて work/ に置く。
"""
import argparse
import json
import os
import wave

import numpy as np
import torch
from transformers import Wav2Vec2ForCTC

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read_wav(path):
    with wave.open(path) as w:
        raw = w.readframes(w.getnframes())
    return np.frombuffer(raw, dtype='<i2').astype(np.float32) / 32768.0


def normalize(a):
    return (a - a.mean()) / np.sqrt(a.var() + 1e-7)


def log_softmax(x):
    x = x - x.max(-1, keepdims=True)
    return x - np.log(np.exp(x).sum(-1, keepdims=True))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--layers', type=int, default=12)
    ap.add_argument('--tag', default='', help='学習時の --tag と同じもの')
    ap.add_argument('--child-test', type=float, default=0.0,
                    help='評価音声を子ども寄りに変形してから通す（例 1.20）')
    args = ap.parse_args()

    suffix = f'-{args.tag}' if args.tag else ''
    src = os.path.join(ROOT, f'work/student-{args.layers}L{suffix}')
    model = Wav2Vec2ForCTC.from_pretrained(src)
    model.eval()
    model.config.apply_spec_augment = False
    n = sum(p.numel() for p in model.parameters())
    print(f'生徒 {args.layers}層 / {n/1e6:.0f}M パラメータ', flush=True)

    onnx_path = os.path.join(src, 'model.onnx')
    if not os.path.exists(onnx_path):
        print('ONNX へ書き出し中…', flush=True)
        dummy = torch.randn(1, 32000)
        torch.onnx.export(
            model, dummy, onnx_path,
            input_names=['input_values'], output_names=['logits'],
            dynamic_axes={'input_values': {1: 'n'}, 'logits': {1: 't'}},
            opset_version=14, do_constant_folding=True)
    print(f'  {os.path.getsize(onnx_path)/1e6:.0f} MB (fp32)', flush=True)

    # q8 量子化。現行モデルと同じ土俵で比べるため。
    q8_path = os.path.join(src, 'model_q8.onnx')
    if not os.path.exists(q8_path):
        from onnxruntime.quantization import quantize_dynamic, QuantType
        print('q8 に量子化中…', flush=True)
        quantize_dynamic(onnx_path, q8_path, weight_type=QuantType.QUInt8)
    print(f'  {os.path.getsize(q8_path)/1e6:.0f} MB (q8)', flush=True)

    # 評価用の音声について、採点器が読める形で対数事後確率を書き出す
    import onnxruntime as ort
    sess = ort.InferenceSession(q8_path, providers=['CPUExecutionProvider'])
    en = json.load(open(os.path.join(ROOT, 'data/en-phones.json')))
    vocab = json.load(open(os.path.join(ROOT, 'data/vocab.json')))
    keep = np.array([vocab['<pad>']] + [i for i in en['ids'] if i != vocab['<pad>']])

    bench = os.path.join(ROOT, 'bench/audio')
    child = args.child_test
    out_dir = os.path.join(ROOT,
        f'work/distill-logp-{args.layers}L{suffix}' + (f'-child{int(child*100)}' if child else ''))
    os.makedirs(out_dir, exist_ok=True)
    files = sorted(f for f in os.listdir(bench) if f.endswith('.wav'))
    meta = []
    for f in files:
        raw = read_wav(os.path.join(bench, f))
        if child:
            import importlib.util as _il
            _sp = _il.spec_from_file_location('dt', os.path.join(ROOT, 'tools/distill-train.py'))
            if 'vtlp' not in globals():
                _src = open(os.path.join(ROOT, 'tools/distill-train.py')).read()
                _ns = {'__file__': 'x'}
                exec(compile(_src[:_src.index('def main()')], 'x', 'exec'), _ns)
                globals()['vtlp'] = _ns['vtlp']
            raw = vtlp(raw, child)
        a = normalize(raw)[None, :]
        logits = sess.run(['logits'], {'input_values': a})[0][0]
        lp = log_softmax(logits[:, keep]).astype(np.float32)
        lp.tofile(os.path.join(out_dir, f'{f[:-4]}.bin'))
        meta.append({'file': f, 'T': int(lp.shape[0])})
    json.dump({'K': len(keep), 'tokens': ['<pad>'] + list(en['phones']),
               'files': meta, 'layers': args.layers,
               'sizeMB': round(os.path.getsize(q8_path) / 1e6)},
              open(os.path.join(out_dir, 'meta.json'), 'w'), indent=2)
    print(f'-> {out_dir}')


if __name__ == '__main__':
    main()
