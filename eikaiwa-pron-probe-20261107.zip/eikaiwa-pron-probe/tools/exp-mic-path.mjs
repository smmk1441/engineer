// 「同じ音声なのに、マイク経由だと点が下がるのか」を切り分ける実験。
//
//   node tools/serve.mjs --isolate &
//   node tools/exp-mic-path.mjs
//
// 同じ wav を3通りで通して素点を比べる:
//   direct   モデルへ直接（マイクを通らない。bench/run.mjs と同じ経路）
//   mic:aec  getUserMedia を通話向け設定（AEC/NS/AGC 有効）で通す
//   mic:raw  getUserMedia を音声処理オフで通す
//
// Chrome の --use-file-for-fake-audio-capture は、指定した wav を
// マイク入力として流したうえで getUserMedia の音声処理を通す。
// つまり AEC/NS/AGC がどれだけ音を壊しているかを、実機のマイクなしで測れる。

import puppeteer from 'puppeteer-core';
import path from 'node:path';
import fs from 'node:fs';
import { readWav } from '../bench/wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const BASE = process.env.BASE || 'http://localhost:8080';

// 文番号(1始まり) と話者。ネイティブと訛りの両方で見る。
const CASES = [
  { file: 's1_Samantha.wav', sentence: 0 },
  { file: 's2_Samantha.wav', sentence: 1 },
  { file: 's4_Samantha.wav', sentence: 3 },
  { file: 's1_Kyoko.wav', sentence: 0 },
  { file: 's4_Kyoko.wav', sentence: 3 },
];

async function open(wav, aec) {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: true,
    userDataDir: path.join(ROOT, '.chrome-profile'),
    protocolTimeout: 20 * 60 * 1000,
    args: [
      '--no-sandbox',
      '--use-fake-ui-for-media-stream',
      '--use-fake-device-for-media-stream',
      `--use-file-for-fake-audio-capture=${wav}%noloop`,
    ],
  });
  const page = await browser.newPage();
  await browser.defaultBrowserContext().overridePermissions(BASE, ['microphone']);
  await page.goto(`${BASE}/?device=wasm&dtype=q8&probe=1${aec ? '&aec=1' : ''}`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('!!self.__probe', { timeout: 15 * 60 * 1000, polling: 500 });
  return { browser, page };
}

/**
 * マイクボタンを押して、音声が流れ切るのを待ってから止める。
 * 偽マイクは wav を1回だけ流すので、鳴り終わってから止めないと途中で切れる。
 */
async function viaMic(page, sentence, seconds) {
  await page.evaluate((i) => self.__probe.show(i), sentence);
  await page.click('#btn-rec');
  await page.waitForFunction('document.getElementById("btn-rec").classList.contains("rec")', { timeout: 10000 });
  await new Promise((r) => setTimeout(r, seconds * 1000 + 900));
  await page.click('#btn-rec');
  try {
    await page.waitForSelector('#result:not([hidden])', { timeout: 180000 });
  } catch {
    // 採点まで届かなかった。無音と判定された場合など。
    const msg = await page.$eval('#mic-label', (e) => e.textContent);
    return { accuracy: NaN, stars: 0, hyp: [], failed: msg };
  }
  return page.evaluate(() => self.__probe.lastScore());
}

const rows = [];
for (const c of CASES) {
  const wav = path.join(ROOT, 'bench/audio', c.file);
  const { audio } = readWav(wav);
  const samples = Array.from(audio);
  const seconds = audio.length / 16000;

  const out = { file: c.file };

  // direct
  {
    const { browser, page } = await open(wav, false);
    const r = await page.evaluate((a, i) => self.__probe.run(a, i), samples, c.sentence);
    out.direct = { acc: r.score.accuracy, stars: r.score.stars, hyp: r.hyp.join(' ') };
    await browser.close();
  }
  // mic: 通話向け設定
  {
    const { browser, page } = await open(wav, true);
    const s = await viaMic(page, c.sentence, seconds);
    out.micAec = { acc: s.accuracy, stars: s.stars, hyp: (s.hyp || []).join(' '), failed: s.failed };
    await browser.close();
  }
  // mic: 音声処理オフ
  {
    const { browser, page } = await open(wav, false);
    const s = await viaMic(page, c.sentence, seconds);
    out.micRaw = { acc: s.accuracy, stars: s.stars, hyp: (s.hyp || []).join(' '), failed: s.failed };
    await browser.close();
  }

  rows.push(out);
  console.log(`\n${c.file}`);
  const line = (k) => {
    const r = out[k];
    return r.failed ? `  ${k.padEnd(8)} 取得できず: ${r.failed}`
      : `  ${k.padEnd(8)} acc=${r.acc.toFixed(2)} ★${r.stars}  ${r.hyp}`;
  };
  console.log([line('direct'), line('micAec'), line('micRaw')].join('\n'));
}

const avg = (k) => {
  const v = rows.map((r) => r[k].acc).filter(Number.isFinite);
  return v.length ? (v.reduce((a, b) => a + b, 0) / v.length).toFixed(3) : '—';
};
console.log(`\n平均素点   direct=${avg('direct')}  mic:aec=${avg('micAec')}  mic:raw=${avg('micRaw')}`);

fs.writeFileSync(path.join(ROOT, 'docs/exp-mic-path.json'), JSON.stringify(rows, null, 2));
console.log('-> docs/exp-mic-path.json');
