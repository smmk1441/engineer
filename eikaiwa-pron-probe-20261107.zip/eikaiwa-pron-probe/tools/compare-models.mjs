// 選べるようにしたモデルを、実際のブラウザの経路でそのまま比べる。
//
//   node tools/serve.mjs --isolate &          # ROOT=dist なら配信物をそのまま
//   node tools/compare-models.mjs
//   node tools/compare-models.mjs teacher s12 # 一部だけ
//
// bench/ の比較は Node + 事前計算の対数事後確率で回すが、ここは違う。
// **画面と同じ経路**（Worker / WASM / 英語音素マスク / GOP / 星の刻み）を通す。
// モデルを差し替えたときに効くのは、モデル単体の精度ではなく、この一連を
// 通したあとの星の出方だから。
//
// 見るもの:
//   ロード       初回ダウンロードを含む立ち上がり
//   自己検証     フレーム最大確率の平均。壊れた出力の検知に使っているもの
//   推論         1発話あたり
//   話者の階段   ネイティブ系が高く、日本語訛りが低い順序が保たれているか
//
// 正解ラベルは無い。**順序が壊れていないか**だけを見る（引き継ぎメモ §4）。

import puppeteer from 'puppeteer-core';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { readWav } from '../bench/wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const BASE = process.env.BASE || 'http://localhost:8080';

const catalog = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/models.json'), 'utf8')).models;
const want = process.argv.slice(2);
const targets = want.length ? catalog.filter((m) => want.includes(m.id)) : catalog;
if (!targets.length) throw new Error(`該当するモデルがありません: ${want.join(' ')}`);

const files = fs.readdirSync(path.join(ROOT, 'bench/audio')).filter((f) => f.endsWith('.wav')).sort();

async function measure(model) {
  // キャッシュを空から始める。切り替えたユーザが実際に待つ時間を見るため。
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'cmp-'));
  const browser = await puppeteer.launch({
    executablePath: CHROME, headless: true, userDataDir: profile,
    protocolTimeout: 20 * 60 * 1000,
    args: ['--no-sandbox', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'],
  });
  try {
    const page = await browser.newPage();
    page.on('console', (m) => { if (m.type() === 'error') console.error('  [browser]', m.text()); });
    await page.goto(`${BASE}/index.html?probe=1&metrics=1&model=${model.id}`, { waitUntil: 'load' });
    await page.waitForFunction('self.__probe', { timeout: 15 * 60 * 1000 });
    const m0 = await page.evaluate('self.__probe.metrics()');

    const rows = [];
    for (const f of files) {
      const [, n, voice] = f.match(/^s(\d+)_(.+)\.wav$/);
      const samples = Array.from(readWav(path.join(ROOT, 'bench/audio', f)).audio);
      const r = await page.evaluate(
        (s, i) => self.__probe.run(s, i), samples, Number(n) - 1);
      rows.push({ voice, sentence: Number(n), acc: r.score.accuracy, stars: r.score.stars, ms: r.metrics.lastMs });
    }
    return { boot: m0, rows };
  } finally {
    await browser.close();
    fs.rmSync(profile, { recursive: true, force: true });
  }
}

const med = (xs) => [...xs].sort((a, b) => a - b)[Math.floor(xs.length / 2)];
const avg = (xs) => xs.reduce((a, b) => a + b, 0) / xs.length;

const all = [];
for (const model of targets) {
  process.stdout.write(`${model.label} (${model.id}) を計測中…\n`);
  const r = await measure(model);
  all.push({ model, ...r });
}

console.log('\n=== 立ち上がりと速さ ===\n');
console.log('モデル                        サイズ   ロード    推論(中央)  自己検証');
for (const a of all) {
  console.log(
    `${a.model.label.padEnd(26)} ${String(a.model.sizeMB).padStart(4)}MB  ` +
    `${(a.boot.loadMs / 1000).toFixed(1).padStart(5)}s  ` +
    `${String(med(a.rows.map((r) => r.ms))).padStart(7)}ms  ` +
    `${a.boot.verify.ok ? 'OK' : 'NG'} ${a.boot.verify.meanTopProb.toFixed(2)}`);
}

console.log('\n=== 話者ごとの素点（高いほど良い） ===\n');
const voices = [...new Set(all[0].rows.map((r) => r.voice))];
console.log('話者          ' + all.map((a) => a.model.id.padStart(12)).join(''));
for (const v of voices) {
  const cells = all.map((a) => avg(a.rows.filter((r) => r.voice === v).map((r) => r.acc)).toFixed(3).padStart(12));
  console.log(v.padEnd(14) + cells.join(''));
}
console.log('\n平均星        ' + all.map((a) => avg(a.rows.map((r) => r.stars)).toFixed(2).padStart(12)).join(''));

// ネイティブ系と日本語訛りの差。これが縮むと「採点として壊れている」
const gap = (a) => {
  const nat = a.rows.filter((r) => r.voice !== 'Kyoko').map((r) => r.acc);
  const jp = a.rows.filter((r) => r.voice === 'Kyoko').map((r) => r.acc);
  return avg(nat) - avg(jp);
};
console.log('訛りとの差    ' + all.map((a) => gap(a).toFixed(3).padStart(12)).join(''));

fs.writeFileSync(path.join(ROOT, 'docs/compare-models.json'),
  JSON.stringify(all.map((a) => ({ id: a.model.id, sizeMB: a.model.sizeMB, boot: a.boot, rows: a.rows })), null, 2));
console.log('\n-> docs/compare-models.json');
