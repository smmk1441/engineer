// 「正しく読んでいるのに減点される」を減らすための、許容する発音の異形。
//
// espeak-ng が出すのは辞書形（citation form）で、自然な発話とは体系的にずれる。
// 実測した例:
//
//   to school   辞書 t uː   実際 t ə    (機能語の弱形)
//   get up      辞書 ɡ ɛ t  実際 ɡ ɛ ɾ  (t のフラップ化)
//   usually     辞書 ʒ uː əl i 実際 ʒ ʊ l i
//   beautiful   辞書 ɾ i f   実際 ɾ ɪ f  (弱母音のゆれ)
//   want        辞書 w ɔ n t 実際 w ʌ n t (短い ɔ のゆれ)
//
// どれも英語として正しい発音なので、減点するのは誤り。
// ここで挙げた異形は GOP の計算時に「正解と同じ扱い」にする。
//
// 甘くしすぎると評価にならないので、対象は英語として確立した現象だけに絞る:
//   - 機能語の弱形（to / of / for ... の母音が ə になる）
//   - 母音に挟まれた t / d のフラップ化（American English では通常の発音）
//   - 音節主音的な l / n（apple の əl が l になる）

/** 強勢を受けない機能語。これらの母音は曖昧母音でもよい。 */
const FUNCTION_WORDS = new Set([
  'a', 'an', 'the', 'to', 'of', 'for', 'and', 'or', 'but', 'at', 'as', 'that',
  'is', 'are', 'was', 'were', 'am', 'be', 'been', 'do', 'does', 'did',
  'can', 'could', 'will', 'would', 'shall', 'should', 'have', 'has', 'had',
  'you', 'your', 'he', 'she', 'we', 'they', 'them', 'his', 'her', 'their',
  'in', 'on', 'from', 'by', 'with', 'up', 'out', 'there', 'some',
]);

/** 母音（弱形やフラップ化の判定に使う） */
const VOWELS = new Set([
  'i', 'iː', 'ɪ', 'ɛ', 'æ', 'ə', 'ɚ', 'ɜː', 'ʌ', 'ɑː', 'ɔː', 'ʊ', 'uː', 'ɐ', 'ᵻ',
  'aɪ', 'aʊ', 'eɪ', 'oʊ', 'ɔɪ', 'iə', 'ɑːɹ', 'ɔːɹ', 'ɛɹ', 'ɪɹ', 'ʊɹ', 'aɪɚ', 'aɪə', 'ɔ',
]);

/**
 * 文脈に依らず認める入れ替え。
 *
 * `i` と `ɔ` を入れたのは、espeak がこの2つを**弱い位置にしか使わない**ため。
 * 強い位置は別の記号になるので、意味の対立を壊さずに緩められる。
 *
 *   i   happy母音。beautiful / happy / city / family。
 *       see / sheep は iː なので別物。ship(ɪ) と sheep(iː) の対立は触らない
 *   ɔ   短いほう。want / orange くらいにしか出ない。
 *       caught / call / all / talk は ɔː で別物
 */
const ALWAYS = {
  'əl': ['l'],
  'ən': ['n'],
  'l': ['əl'],
  'n': ['n̩'],
  'ɚ': ['ɹ', 'ə'],
  'ɾ': ['t', 'd'],
  'i': ['ɪ', 'ᵻ', 'ə'],
  'ɔ': ['ʌ', 'ɑː'],
};

/**
 * 単語の音素列に対して、位置ごとの許容異形を返す。
 * @param {string} word 表記（句読点なし・小文字化して判定）
 * @param {string[]} phones その単語の音素列
 * @param {string[]} prevPhones 直前の単語の音素列（フラップ判定に使う）
 * @param {string[]} nextPhones 直後の単語の音素列
 * @returns {string[][]} phones と同じ長さ。各要素は許容する別音素の配列。
 */
export function variantsFor(word, phones, prevPhones = [], nextPhones = []) {
  const bare = word.replace(/[^A-Za-z']/g, '').toLowerCase();
  const isFunction = FUNCTION_WORDS.has(bare);

  return phones.map((ph, i) => {
    const set = new Set(ALWAYS[ph] || []);

    // 機能語の母音は曖昧母音でもよい（to = tuː / tə）
    if (isFunction && VOWELS.has(ph)) { set.add('ə'); set.add('ɪ'); set.add('ʊ'); }

    // 母音に挟まれた t / d はフラップになる（get up = ɡɛɾʌp）
    if (ph === 't' || ph === 'd') {
      const before = i > 0 ? phones[i - 1] : prevPhones[prevPhones.length - 1];
      const after = i < phones.length - 1 ? phones[i + 1] : nextPhones[0];
      if (VOWELS.has(before) && VOWELS.has(after)) set.add('ɾ');
    }

    set.delete(ph);
    return [...set];
  });
}
