// マイク経路の通し確認。
//
//   node tools/serve.mjs --isolate &
//   node tools/test-mic.mjs
//
// Chrome の `--use-file-for-fake-audio-capture` で wav をマイク入力に差し込み、
// 実際にボタンを押して録音 → 停止 → 採点まで走らせる。
// probe 経由の計測は Recorder を通らないので、AudioWorklet / リサンプル /
// 無音トリムはここでしか踏めない。

import puppeteer from 'puppeteer-core';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..');
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const BASE = process.env.BASE || 'http://localhost:8080';
const WAV = process.env.WAV || path.join(ROOT, 'bench/audio/s1_Samantha.wav');
// ファイル名の s<n> が課題文の番号。取り違えると別の文で採点してしまう。
const SENTENCE = Number(path.basename(WAV).match(/^s(\d+)_/)?.[1] || 1) - 1;

const browser = await puppeteer.launch({
  executablePath: CHROME,
  headless: true,
  userDataDir: path.join(ROOT, '.chrome-profile'),
  protocolTimeout: 10 * 60 * 1000,
  args: [
    '--no-sandbox',
    '--use-fake-ui-for-media-stream',
    '--use-fake-device-for-media-stream',
    `--use-file-for-fake-audio-capture=${WAV}%noloop`,
  ],
});

const page = await browser.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });

const ctx = browser.defaultBrowserContext();
await ctx.overridePermissions(BASE, ['microphone']);

await page.goto(`${BASE}/?device=wasm&dtype=q8&metrics=1`, { waitUntil: 'domcontentloaded' });
await page.waitForSelector('#app:not([hidden])', { timeout: 15 * 60 * 1000 });
console.log('起動: ok');

for (let i = 0; i < SENTENCE; i++) await page.click('#btn-next');
console.log(`課題文: ${await page.$eval('#q-en', (e) => e.textContent)}`);

await page.click('#btn-rec');
await page.waitForFunction('document.getElementById("btn-rec").classList.contains("rec")', { timeout: 10000 });
console.log('録音開始: ok');

// メーターが動いているか（録音中の状態表示）。
// 偽マイクは wav を1回流して終わるので、鳴っている間に何度か覗く。
let peak = 0;
for (let i = 0; i < 8; i++) {
  await new Promise((r) => setTimeout(r, 150));
  const hs = await page.$$eval('.bars i', (els) => els.map((e) => parseFloat(e.style.height) || 0));
  peak = Math.max(peak, ...hs);
}
console.log(`レベルメーター: ${peak > 8 ? `ok (peak ${peak}px)` : `動いていない (peak ${peak}px)`}`);

await page.click('#btn-rec');
await page.waitForSelector('#result:not([hidden])', { timeout: 120000 });

const result = await page.evaluate(() => ({
  stars: document.querySelectorAll('#stars span').length,
  filled: [...document.querySelectorAll('#stars span')].filter((s) => s.style.opacity === '1').length,
  verdict: document.getElementById('verdict').textContent,
  words: [...document.querySelectorAll('.word')].map((w) => `${w.querySelector('.word-text').textContent}:${w.className.replace('word ', '')}`),
  chips: [...document.querySelectorAll('.ph')].map((c) => `${c.textContent}/${c.className.replace('ph ', '')}`),
  fluency: document.getElementById('fluency-text').textContent,
  hint: document.getElementById('hint').hidden ? '' : document.getElementById('hint').textContent,
  metrics: [...document.querySelectorAll('#metrics-body dt')].map((dt, i) =>
    `${dt.textContent}=${dt.nextElementSibling.textContent}`).join(' '),
}));

console.log(`採点: ★${result.filled}/${result.stars}  「${result.verdict}」  すらすら度=${result.fluency}${result.hint ? `  ヒント=「${result.hint}」` : ''}`);
console.log(`単語: ${result.words.join('  ')}`);
console.log(`音素: ${result.chips.join(' ')}`);
console.log(`録音: ${result.metrics}`);
console.log(errors.length ? `\nエラー:\n${errors.join('\n')}` : '\nJSエラー: なし');

await page.screenshot({ path: path.join(ROOT, 'docs/shot-mic.png') });
await browser.close();
process.exit(errors.length ? 1 : 0);
