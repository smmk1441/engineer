#!/bin/bash
# 「おてほん」の音声を作る。
#
#   bash tools/gen-model-audio.sh
#
# 端末の speechSynthesis に任せると、ブラウザが選ぶ既定の声しだいで
# 音が変わる。実測では声によって素点が 0.08〜0.98 まで振れた
# （macOS/Chrome の既定 Aaron と同系列の Eddy/Flo は 0.45〜0.49）。
# お手本がお手本として採点されないのは、デモとしても教材としても困るので、
# 音声そのものを同梱して端末差を無くす。
#
# 少しゆっくり (-r 149 ≒ rate 0.85) にしてあるのは小学生向けの読み上げのため。
# この速度なら採点にはほぼ影響しない（実測 0.97 対 1.00）。
set -e
cd "$(dirname "$0")/.."

VOICE=${VOICE:-Samantha}
RATE=${RATE:-149}
OUT=audio/model
mkdir -p "$OUT"

if ! say -v '?' | awk '{print $1}' | grep -qx "$VOICE"; then
  echo "音声 '$VOICE' が見つかりません。say -v '?' で確認してください。" >&2
  exit 1
fi

i=1
python3 -c "
import json
for s in json.load(open('data/reference.json')): print(s['text'])
" | while IFS= read -r line; do
  [ -z "$line" ] && continue
  say -v "$VOICE" -r "$RATE" -o "$OUT/tmp.aiff" "$line"
  # 再生用なので 24kHz。モデルが見るのはマイクが拾った音なので、ここは聞こえ優先。
  afconvert -f m4af -d aac -b 48000 --src-complexity bats -r 127 \
    -c 1 "$OUT/tmp.aiff" "$OUT/s${i}.m4a" >/dev/null
  rm -f "$OUT/tmp.aiff"
  echo "$OUT/s${i}.m4a  <- $line"
  i=$((i + 1))
done

du -sh "$OUT"
