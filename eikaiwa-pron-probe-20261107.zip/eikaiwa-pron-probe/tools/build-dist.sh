#!/bin/bash
# 配信するファイルだけを dist/ に集める。
#
#   bash tools/build-dist.sh
#
# リポジトリをまるごと上げると docs/ も公開されてしまう。
# docs/ には検証メモ（規模・費用の見積もり・社内の進め方）が入っているので、
# 公開URLに置くものではない。bench/ と tools/ も配信には要らない。

set -e
cd "$(dirname "$0")/.."

rm -rf dist
mkdir -p dist

cp index.html listen.html speaking.html dist/
cp -R css js data audio dist/
cp tools/staticwebapp.config.json dist/

# ブラウザが読まないものは落とす
find dist -name '*.test.mjs' -delete
find dist -name '.DS_Store' -delete

echo "--- dist/ ---"
find dist -type f | sort | sed 's/^/  /'
echo
du -sh dist
