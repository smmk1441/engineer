#!/usr/bin/env python3
"""層を減らした生徒モデルを、教師の出力を真似るように学習する（案A）。

    work/venv/bin/python tools/distill-train.py --layers 12 --epochs 8

やっていること:

  1. 教師（wav2vec2-large 24層）の重みを読む
  2. 層を等間隔に間引いて生徒（N層）を作る。**重みは教師から引き継ぐ**ので
     一から学習するより桁違いに少ないデータで済む
  3. 教師のフレームごとの確率分布に近づける（KLダイバージェンス）

なぜ幅（hidden 1024）は減らさないか:
  幅を変えると次元が合わず教師の重みを流用できない。一から学習することになり、
  手元の TTS 36分ではまったく足りない（教師の土台は6万時間）。
  幅を落とすのは、数百時間規模の音声を用意してからの話。

層削減だけでは 12層で壊れることが計測で分かっている（docs/MEASUREMENTS.md §7-3、
全話者が素点 0.5 前後で横並び）。**それが蒸留で戻るかどうか**が、この実験の問い。
"""
import argparse
import json
import os
import random
import time

import numpy as np
import torch
import torch.nn.functional as F
from transformers import Wav2Vec2ForCTC

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEACHER_ID = 'facebook/wav2vec2-lv-60-espeak-cv-ft'
RATE = 16000


def vtlp(x, alpha, nfft=512, hop=128):
    """声道長摂動。周波数軸を alpha 倍に伸ばす（alpha>1 で声道が短い＝子ども寄り）。

    子どもの声は声道が短く、フォルマントが成人より 20〜25% 高い。
    教師はこの帯域に弱い（docs/MEASUREMENTS.md §7-5。+20% で判別力がほぼ消える）。

    **教師の目標は原音から取り、生徒の入力だけを変形する。** こうすると生徒は
    「子どもっぽい音でも中身は同じ音素だ」と学ぶ。教師にできないことを生徒が
    身につける形で、生徒が教師を超えられる数少ないパターン。
    """
    win = np.hanning(nfft).astype(np.float32)
    half = nfft // 2
    f_hi = 4800 / (RATE / 2) * half
    bend = min(alpha, 1.0) * f_hi
    k = np.arange(half + 1, dtype=np.float32)
    src = np.where(k <= bend, k / alpha,
                   half - (half - bend / alpha) / (half - bend) * (half - k))
    src = np.clip(src, 0, half)
    i0 = np.floor(src).astype(int)
    frac = (src - i0).astype(np.float32)
    i1 = np.minimum(i0 + 1, half)

    out = np.zeros(len(x), np.float32)
    norm = np.zeros(len(x), np.float32)
    for s0 in range(0, len(x) - nfft + 1, hop):
        spec = np.fft.rfft(x[s0:s0 + nfft] * win)
        warped = spec[i0] * (1 - frac) + spec[i1] * frac
        frame = np.fft.irfft(warped, nfft).astype(np.float32)
        out[s0:s0 + nfft] += frame * win
        norm[s0:s0 + nfft] += win * win
    y = np.where(norm > 1e-8, out / np.maximum(norm, 1e-8), out).astype(np.float32)
    # 複素スペクトルを補間すると重ね合わせの位相が揃わず、振幅が数倍になる。
    # 特徴量抽出が平均0・分散1に正規化するので結果には効かないが、
    # 紛らわしいので元の音量に合わせておく。
    rms_in = float(np.sqrt((x ** 2).mean())) + 1e-9
    rms_out = float(np.sqrt((y ** 2).mean())) + 1e-9
    return (y * (rms_in / rms_out)).astype(np.float32)


def build_student(teacher, n_layers):
    """教師の層を等間隔に間引いて生徒を作る。重みはそのまま引き継ぐ。"""
    import copy
    student = copy.deepcopy(teacher)
    total = len(teacher.wav2vec2.encoder.layers)
    # 等間隔に選ぶ。浅い層と深い層の両方を残したいので端を含める。
    idx = [round(i * (total - 1) / (n_layers - 1)) for i in range(n_layers)]
    print(f'  教師の層 {idx} を引き継ぐ')
    layers = torch.nn.ModuleList(
        [copy.deepcopy(teacher.wav2vec2.encoder.layers[i]) for i in idx])
    student.wav2vec2.encoder.layers = layers
    student.config.num_hidden_layers = n_layers
    return student


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--layers', type=int, default=12)
    ap.add_argument('--epochs', type=int, default=8)
    ap.add_argument('--lr', type=float, default=5e-5)
    ap.add_argument('--limit', type=int, default=0, help='使う音声の数（0で全部）')
    ap.add_argument('--targets', default='work/targets', help='教師ラベルの場所')
    ap.add_argument('--tag', default='', help='保存先の識別子')
    ap.add_argument('--child-aug', type=float, default=0.0,
                    help='生徒の入力を子ども寄りに変形する確率（0で無効）')
    ap.add_argument('--max-sec', type=float, default=10.0,
                    help='1件あたりの最大秒数。長い発話は切り出す')
    args = ap.parse_args()
    targets_dir = os.path.join(ROOT, args.targets)
    tag = args.tag or ('child' if args.child_aug else 'plain')

    dev = 'mps' if torch.backends.mps.is_available() else 'cpu'
    print(f'device={dev}', flush=True)

    files = sorted(f for f in os.listdir(targets_dir) if f.endswith('.npz'))
    if args.limit:
        files = files[:args.limit]
    # 文単位で分ける。同じ文の別話者がまたがると評価が甘くなる。
    sid = lambda f: f.split('_')[0]
    ids = sorted({sid(f) for f in files})
    val_ids = set(ids[::10])
    train = [f for f in files if sid(f) not in val_ids]
    val = [f for f in files if sid(f) in val_ids]
    print(f'{len(files)} ファイル → 学習 {len(train)} / 検証 {len(val)}', flush=True)

    print('教師を読み込み中…', flush=True)
    teacher = Wav2Vec2ForCTC.from_pretrained(TEACHER_ID)
    teacher.eval()

    print(f'生徒を作成（{args.layers}層）…', flush=True)
    student = build_student(teacher, args.layers)
    del teacher  # 教師の出力は事前計算済み。本体はもう要らない
    n_param = sum(p.numel() for p in student.parameters())
    print(f'  生徒 {n_param/1e6:.0f}M パラメータ（q8 で約 {n_param/1e6:.0f}MB）', flush=True)

    # 畳み込み特徴抽出器は凍結。音の低次特徴は教師のままでよく、
    # ここを動かすと少ないデータで簡単に壊れる。
    student.wav2vec2.feature_extractor._freeze_parameters()
    # SpecAugment を切る。教師の出力（同じ音声に対するもの）を真似る蒸留では
    # 入力の一部を隠す意味が無く、ずれた目標を学ばせることになる。
    # MPS では nonzero が CPU にフォールバックして遅くもなる。
    student.config.apply_spec_augment = False
    student.config.mask_time_prob = 0.0
    student.config.mask_feature_prob = 0.0
    student.to(dev)

    opt = torch.optim.AdamW(
        [p for p in student.parameters() if p.requires_grad], lr=args.lr, weight_decay=0.01)
    steps = args.epochs * len(train)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=args.lr, total_steps=steps, pct_start=0.1)

    # MPS は畳み込みの出力チャンネル数が 65536 までなので、長い発話は通らない。
    # フレーム境界（320サンプル）に合わせて切り出す。式は実データで確認済み:
    #   フレーム数 = (サンプル数 - 400) // 320 + 1
    max_samples = int(args.max_sec * 16000) // 320 * 320

    def load(f, augment=False):
        d = np.load(os.path.join(targets_dir, f))
        a, lp = d['audio'], d['logp']
        if len(a) > max_samples:
            # 学習時は毎回違う位置を切る（これ自体が水増しにもなる）。
            # 検証は先頭固定にして、回ごとに数字がぶれないようにする。
            n_pos = (len(a) - max_samples) // 320 + 1
            start = random.randrange(n_pos) * 320 if augment else 0
            a = a[start:start + max_samples]
            f0 = start // 320
            lp = lp[f0:f0 + (max_samples - 400) // 320 + 1]
        # 教師の目標は原音のまま。生徒の入力だけ変形する。
        if augment and random.random() < args.child_aug:
            a = vtlp(a, random.uniform(1.05, 1.25))
        return (torch.from_numpy(np.ascontiguousarray(a)).to(dev),
                torch.from_numpy(np.ascontiguousarray(lp).astype(np.float32)).to(dev))

    def evaluate():
        student.eval()
        kl, agree, n = 0.0, 0, 0
        with torch.no_grad():
            for f in val:
                a, tlp = load(f)
                slp = F.log_softmax(student(a[None, :]).logits[0], -1)
                m = min(len(slp), len(tlp))
                kl += F.kl_div(slp[:m], tlp[:m], log_target=True, reduction='sum').item()
                agree += int((slp[:m].argmax(-1) == tlp[:m].argmax(-1)).sum())
                n += m
        student.train()
        return kl / n, agree / n

    kl0, ag0 = evaluate()
    print(f'学習前（層を削っただけ）: KL={kl0:.4f}  フレーム一致率={100*ag0:.1f}%', flush=True)
    best = (kl0, ag0)

    t0 = time.time()
    step = 0
    for ep in range(args.epochs):
        random.shuffle(train)
        run = 0.0
        for f in train:
            a, tlp = load(f, augment=True)
            slp = F.log_softmax(student(a[None, :]).logits[0], -1)
            m = min(len(slp), len(tlp))
            loss = F.kl_div(slp[:m], tlp[:m], log_target=True, reduction='batchmean')
            loss.backward()
            torch.nn.utils.clip_grad_norm_(student.parameters(), 1.0)
            opt.step(); sched.step(); opt.zero_grad(set_to_none=True)
            run += loss.item(); step += 1
            if step % 50 == 0:
                el = time.time() - t0
                print(f'\r  ep{ep+1} {step}/{steps}  loss={run/50:.4f}  '
                      f'{el:.0f}s (残り {el/step*(steps-step):.0f}s)', end='', flush=True)
                run = 0.0
            # 長時間回すので、途中で落ちても最初からにならないようにする
            if step % 500 == 0:
                student.save_pretrained(os.path.join(ROOT, f'work/student-{args.layers}L-{tag}'))
        kl, ag = evaluate()
        mark = ''
        if kl < best[0]:
            best = (kl, ag)
            student.save_pretrained(os.path.join(ROOT, f'work/student-{args.layers}L-{tag}'))
            mark = '  ← 保存'
        print(f'\n  ep{ep+1} 終了: KL={kl:.4f}  フレーム一致率={100*ag:.1f}%{mark}', flush=True)

    out = os.path.join(ROOT, f'work/student-{args.layers}L-{tag}')
    json.dump({'layers': args.layers, 'params': n_param, 'childAug': args.child_aug,
               'targets': args.targets, 'files': len(files),
               'kl_before': kl0, 'agree_before': ag0,
               'kl_after': best[0], 'agree_after': best[1]},
              open(os.path.join(out, 'distill-log.json'), 'w'), indent=2)
    print(f'-> {out}')


if __name__ == '__main__':
    main()
