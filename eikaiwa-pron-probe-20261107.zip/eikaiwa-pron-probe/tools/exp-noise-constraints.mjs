// 雑音がある条件で、getUserMedia の音声処理は得か損か。
//
//   node tools/serve.mjs --isolate &
//   node tools/exp-noise-constraints.mjs
//
// 前回 tools/exp-mic-path.mjs でこれを測ったが、**クリーンな音声**を流していたので
// ノイズ抑制の「害」しか出ていなかった。消すべき雑音が無いのだから当然で、
// あの結果だけで既定オフにしたのは早すぎた。ここでは雑音を載せた音声で測り直す。
//
// 比較する設定:
//   off   3つとも無効（現在の既定）
//   ns    ノイズ抑制だけ有効。エコー打ち消しは切ったまま
//         （「おてほん」をスピーカーで鳴らして聞かせる使い方を殺さないため）
//   all   通話向けの既定。3つとも有効

import puppeteer from 'puppeteer-core';
import path from 'node:path';
import fs from 'node:fs';
import { readWav } from '../bench/wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const BASE = process.env.BASE || 'http://localhost:8080';

const MODES = {
  off: '',
  ns: '&ns=1',
  all: '&aec=1',
};

const CASES = [
  { file: 's1_Samantha.wav', sentence: 0 },
  { file: 's2_Samantha.wav', sentence: 1 },
  { file: 's4_Samantha.wav', sentence: 3 },
];

// クリーン / 雑音つき の2種類の素材で同じことをやる
const CLEAN_DIR = path.join(ROOT, 'bench/audio');
const NOISY_DIR = path.join(ROOT, 'bench/audio-noisy');
const SOURCES = [
  { name: 'クリーン', dir: CLEAN_DIR },
  { name: '雑音SNR15dB', dir: NOISY_DIR },
];

/** 雑音を載せた素材を作る。無ければ自動で用意する（生成物なので commit しない）。 */
function makeNoisy(snrDb = 15) {
  fs.mkdirSync(NOISY_DIR, { recursive: true });
  for (const c of CASES) {
    const dst = path.join(NOISY_DIR, c.file);
    if (fs.existsSync(dst)) continue;
    const src = path.join(CLEAN_DIR, c.file);
    const raw = fs.readFileSync(src);
    const { audio } = readWav(src);
    const rms = Math.sqrt(audio.reduce((a, v) => a + v * v, 0) / audio.length);
    const amp = rms / Math.pow(10, snrDb / 20);
    // data チャンクの位置を探して、そこだけ書き換える（ヘッダはそのまま使う）
    let off = 12;
    while (off + 8 <= raw.length && raw.toString('ascii', off, off + 4) !== 'data') {
      off += 8 + raw.readUInt32LE(off + 4);
    }
    const out = Buffer.from(raw);
    const start = off + 8;
    for (let i = 0; i < audio.length; i++) {
      const v = audio[i] + amp * (Math.random() * 2 - 1) * 1.73;
      out.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(v * 32768))), start + i * 2);
    }
    fs.writeFileSync(dst, out);
    console.log(`作成: ${path.relative(ROOT, dst)} (SNR ${snrDb}dB)`);
  }
}

makeNoisy();

/**
 * 偽マイクに流す wav は起動フラグで決まるので、音声ファイルごとに1回だけ
 * ブラウザを起こし、設定（URL パラメータ）はその中で切り替える。
 * 起動を繰り返すと Chrome が落ちることがあるため。
 */
async function withMic(wav, fn) {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: true,
    userDataDir: path.join(ROOT, '.chrome-profile'),
    protocolTimeout: 20 * 60 * 1000,
    args: [
      '--no-sandbox',
      '--use-fake-ui-for-media-stream',
      '--use-fake-device-for-media-stream',
      `--use-file-for-fake-audio-capture=${wav}%noloop`,
    ],
  });
  try {
    await browser.defaultBrowserContext().overridePermissions(BASE, ['microphone']);
    return await fn(browser);
  } finally {
    await browser.close().catch(() => {});
  }
}

/** 1回ぶん: ページを開き、録音ボタンを押して、採点を読む */
async function record(browser, query, sentence, seconds) {
  const page = await browser.newPage();
  try {
    await page.goto(`${BASE}/?device=wasm&dtype=q8&probe=1${query}`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('!!self.__probe', { timeout: 15 * 60 * 1000, polling: 500 });
    await page.evaluate((i) => self.__probe.show(i), sentence);
    await page.click('#btn-rec');
    await page.waitForFunction('document.getElementById("btn-rec").classList.contains("rec")', { timeout: 10000 });
    await new Promise((r) => setTimeout(r, seconds * 1000 + 900));
    await page.click('#btn-rec');
    try {
      await page.waitForSelector('#result:not([hidden])', { timeout: 180000 });
    } catch {
      return { accuracy: NaN, stars: 0, failed: await page.$eval('#mic-label', (e) => e.textContent) };
    }
    return await page.evaluate(() => self.__probe.lastScore());
  } finally {
    await page.close().catch(() => {});
  }
}

const results = new Map(); // `${source}|${mode}` -> スコアの配列

for (const src of SOURCES) {
  for (const c of CASES) {
    const wav = path.join(src.dir, c.file);
    const seconds = readWav(wav).audio.length / 16000;
    await withMic(wav, async (browser) => {
      for (const [mode, query] of Object.entries(MODES)) {
        const s = await record(browser, query, c.sentence, seconds);
        const key = `${src.name}|${mode}`;
        if (!results.has(key)) results.set(key, []);
        results.get(key).push(s);
        process.stdout.write(`  ${src.name} ${c.file} ${mode}: ${Number.isFinite(s.accuracy) ? s.accuracy.toFixed(2) : s.failed}\n`);
      }
    });
  }
}

console.log('\n素材        設定  素点   星3つ');
const table = [];
for (const src of SOURCES) {
  for (const mode of Object.keys(MODES)) {
    const got = results.get(`${src.name}|${mode}`) || [];
    const ok = got.filter((s) => Number.isFinite(s.accuracy));
    const acc = ok.length ? ok.reduce((a, s) => a + s.accuracy, 0) / ok.length : NaN;
    const three = got.filter((s) => s.stars === 3).length;
    table.push({ source: src.name, mode, acc, three, of: CASES.length });
    console.log(`${src.name.padEnd(12)} ${mode.padEnd(4)} ${Number.isFinite(acc) ? acc.toFixed(3) : '—'}  ${three}/${CASES.length}`);
  }
}

fs.writeFileSync(path.join(ROOT, 'docs/exp-noise-constraints.json'), JSON.stringify(table, null, 2));
console.log('\n-> docs/exp-noise-constraints.json');
