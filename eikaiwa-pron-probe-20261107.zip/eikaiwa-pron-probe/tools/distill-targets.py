#!/usr/bin/env python3
"""蒸留の教師ラベルを先に作っておく。

    python3 tools/distill-targets.py

教師（現行の wav2vec2-large）に音声を通し、フレームごとの対数事後確率を
ディスクへ書き出す。**書き起こしは要らない。** 教師の出力がそのまま正解になる。

学習中に教師を動かすとメモリと時間を食うので、先に全部出しておく。
ONNX 版を使うので PyTorch も要らない（生徒の学習でだけ使う）。

出力: work/targets/<name>.npz  { audio: float32[N], logp: float16[T,392] }
"""
import json
import os
import time
import wave

import numpy as np
import onnxruntime as ort

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEACHER = os.path.join(ROOT, '.hfcache/onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX/onnx/model.onnx')
import sys as _sys
# 既定は TTS コーパス。LibriSpeech を使うときは引数で切り替える。
_which = _sys.argv[1] if len(_sys.argv) > 1 else 'tts'
_MAP = {
    'tts': ('work/corpus', 'work/targets'),
    'ls': ('work/corpus-ls', 'work/targets-ls'),
    'dev': ('work/corpus-dev', 'work/targets-ls'),   # LibriSpeech dev-clean のみ
}
CORPUS, OUT = (os.path.join(ROOT, x) for x in _MAP[_which])


def read_wav(path):
    with wave.open(path) as w:
        raw = w.readframes(w.getnframes())
    return np.frombuffer(raw, dtype='<i2').astype(np.float32) / 32768.0


def normalize(a):
    """Wav2Vec2FeatureExtractor の do_normalize と同じ"""
    return (a - a.mean()) / np.sqrt(a.var() + 1e-7)


def log_softmax(x):
    x = x - x.max(-1, keepdims=True)
    return x - np.log(np.exp(x).sum(-1, keepdims=True))


def main():
    os.makedirs(OUT, exist_ok=True)
    files = sorted(f for f in os.listdir(CORPUS) if f.endswith('.wav'))
    if not files:
        raise SystemExit('work/corpus に音声がありません。bash work/make-corpus.sh を先に。')

    print(f'教師を読み込み中（1.3GB）…', flush=True)
    sess = ort.InferenceSession(TEACHER, providers=['CPUExecutionProvider'])

    t0 = time.time()
    total_frames = 0
    for i, f in enumerate(files):
        dst = os.path.join(OUT, f[:-4] + '.npz')
        if os.path.exists(dst):
            continue
        raw = read_wav(os.path.join(CORPUS, f))
        logits = sess.run(['logits'], {'input_values': normalize(raw)[None, :]})[0][0]
        lp = log_softmax(logits).astype(np.float16)
        # 音声そのものも一緒に置く。学習時に wav を読み直さなくて済む
        np.savez(dst, audio=raw.astype(np.float32), logp=lp)
        total_frames += len(lp)
        if (i + 1) % 50 == 0:
            el = time.time() - t0
            print(f'\r  {i+1}/{len(files)}  {el:.0f}s '
                  f'(残り {el/(i+1)*(len(files)-i-1):.0f}s)', end='', flush=True)
    print()

    sizes = sum(os.path.getsize(os.path.join(OUT, f)) for f in os.listdir(OUT))
    print(f'-> {OUT}  {len(os.listdir(OUT))} ファイル / {sizes/1e6:.0f} MB')


if __name__ == '__main__':
    main()
