// ブラウザ側の実測。引き継ぎメモ §3 の数字を取るためのスクリプト。
//
//   node tools/serve.mjs --isolate &     # スレッド有効で測るとき
//   node tools/measure-browser.mjs
//
// 測るもの:
//   - モデルの実ダウンロード量と初回ロード時間（キャッシュ空の状態から）
//   - 2回目（Cache Storage あり）のロード時間
//   - 1発話あたりの推論時間（median / p90）
//   - CPU を絞ったときの推論時間（Chromebook 想定）
//   - WASM スレッド有無での差
//
// 実 Chrome を puppeteer-core から使う。Chromium は落としてこない。

import puppeteer from 'puppeteer-core';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { readWav } from '../bench/wav.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const BASE = process.env.BASE || 'http://localhost:8080';
const SAMPLE = path.join(ROOT, 'bench/audio/s1_Samantha.wav');

const samples = Array.from(readWav(SAMPLE).audio);

async function session({ profile, url, cpuThrottle = 1, collectBytes = false }) {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: true,
    userDataDir: profile,
    // 4bit 量子化 + CPU 絞りだと1回の推論が数秒かかる。既定の 180s では足りない。
    protocolTimeout: 20 * 60 * 1000,
    args: [
      '--no-sandbox',
      '--use-fake-ui-for-media-stream',
      '--use-fake-device-for-media-stream',
      '--enable-unsafe-webgpu',
      '--enable-features=Vulkan',
    ],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 900, height: 1200, deviceScaleFactor: 2 });

  let bytes = 0;
  if (collectBytes) {
    page.on('response', async (res) => {
      if (!res.url().includes('huggingface.co') && !res.url().includes('hf.co')) return;
      const len = Number(res.headers()['content-length'] || 0);
      bytes += len;
    });
  }

  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });

  if (cpuThrottle > 1) {
    const client = await page.createCDPSession();
    await client.send('Emulation.setCPUThrottlingRate', { rate: cpuThrottle });
  }

  const t0 = Date.now();
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('!!self.__probe', { timeout: 15 * 60 * 1000, polling: 500 });
  const wallMs = Date.now() - t0;

  return { browser, page, errors, bytes: () => bytes, wallMs };
}

function stats(times) {
  const s = [...times].sort((a, b) => a - b);
  const at = (q) => s[Math.min(s.length - 1, Math.floor(s.length * q))];
  return { min: Math.round(s[0]), median: Math.round(at(0.5)), p90: Math.round(at(0.9)), max: Math.round(s[s.length - 1]) };
}

const report = [];
// 一部だけ回したいとき: ONLY='q4' node tools/measure-browser.mjs
const ONLY = process.env.ONLY;

async function scenario(name, opts) {
  if (ONLY && !name.includes(ONLY)) return null;
  process.stdout.write(`\n### ${name}\n`);
  let s;
  try {
    s = await session(opts);
  } catch (err) {
    // Chrome 側が落ちることがある。1件の失敗で計測全体を止めない。
    console.log(`  失敗: ${err.message}`);
    report.push({ name, failed: String(err.message) });
    return null;
  }
  const metrics = await s.page.evaluate(() => self.__probe.metrics());
  const timing = await s.page.evaluate((a) => self.__probe.time(a, 10), samples);
  const st = stats(timing.times);
  const row = {
    name,
    device: metrics.device,
    dtype: metrics.dtype,
    threads: metrics.threads,
    isolated: metrics.crossOriginIsolated,
    cached: metrics.cached,
    downloadedMB: +(s.bytes() / 1048576).toFixed(1),
    loadSec: +(metrics.loadMs / 1000).toFixed(1),
    pageReadySec: +(s.wallMs / 1000).toFixed(1),
    audioSec: +timing.sec.toFixed(2),
    ...st,
    rtf: +(st.median / 1000 / timing.sec).toFixed(3),
    errors: s.errors.slice(0, 3),
  };
  report.push(row);
  console.log(JSON.stringify(row, null, 2));
  if (opts.screenshot) {
    // 実際に採点まで通して、見た目も1枚残す
    await s.page.evaluate((a) => self.__probe.run(a, 0), samples);
    await new Promise((r) => setTimeout(r, 600));
    await s.page.screenshot({ path: opts.screenshot, fullPage: true });
    console.log(`screenshot -> ${path.relative(ROOT, opts.screenshot)}`);
  }
  await s.browser.close();
  return row;
}

const freshProfile = () => fs.mkdtempSync(path.join(os.tmpdir(), 'pron-probe-'));

// 1. 初回（キャッシュ空）
const cold = freshProfile();
await scenario('初回DL wasm/q8 (isolated)', {
  profile: cold, url: `${BASE}/?device=wasm&dtype=q8&probe=1&metrics=1`,
  collectBytes: true, screenshot: path.join(ROOT, 'docs/shot-result.png'),
});

// 2. 2回目（同じプロファイル＝Cache Storage あり）
await scenario('2回目 wasm/q8 (isolated)', {
  profile: cold, url: `${BASE}/?device=wasm&dtype=q8&probe=1`, collectBytes: true,
});

// 3. CPU を絞る（学校端末の想定）
for (const rate of [4, 6]) {
  await scenario(`CPU 1/${rate} wasm/q8`, {
    profile: cold, url: `${BASE}/?device=wasm&dtype=q8&probe=1`, cpuThrottle: rate,
  });
}

// 4. スレッド1本（cross-origin isolation が取れない場合の下限）
await scenario('WASM 1スレッド', {
  profile: cold, url: `${BASE}/?device=wasm&dtype=q8&threads=1&probe=1`,
});

// 5. WebGPU（使えれば）
await scenario('WebGPU q4f16', {
  profile: freshProfile(), url: `${BASE}/?device=webgpu&dtype=q4f16&probe=1`, collectBytes: true,
});

// 6. 軽い量子化の比較（DL量と速度のトレードオフ）
for (const dtype of ['q4', 'bnb4']) {
  await scenario(`初回DL wasm/${dtype}`, {
    profile: freshProfile(), url: `${BASE}/?device=wasm&dtype=${dtype}&probe=1`, collectBytes: true,
  });
}

// 7. COOP/COEP なし（= SharedArrayBuffer 不可 → WASM がシングルスレッドに落ちる）
// 別ポートで素のサーバを上げてから: PORT=8081 node tools/serve.mjs &
if (process.env.PLAIN_BASE) {
  await scenario('COOP/COEP なし wasm/q8', {
    profile: freshProfile(), url: `${process.env.PLAIN_BASE}/?device=wasm&dtype=q8&probe=1`,
  });
}

fs.mkdirSync(path.join(ROOT, 'docs'), { recursive: true });
const out = path.join(ROOT, 'docs/browser-metrics.json');
// ONLY 指定のときは既存の結果に上書きマージする
const prev = fs.existsSync(out) && ONLY ? JSON.parse(fs.readFileSync(out, 'utf8')) : [];
const merged = [...prev.filter((r) => !report.some((n) => n.name === r.name)), ...report];
fs.writeFileSync(out, JSON.stringify(merged, null, 2));
console.log('\n-> docs/browser-metrics.json');
