#!/bin/bash
# Azure へデプロイする。
#
#   bash tools/deploy-azure.sh                 # 静的サイトだけ更新（数十秒）
#   bash tools/deploy-azure.sh --with-model    # 現行モデル318MBも上げ直す（初回・モデル変更時）
#   bash tools/deploy-azure.sh --with-students # 蒸留した生徒モデル（166MB×2）も上げる
#
# 構成:
#
#   ブラウザ ──HTTPS──> Azure Static Web Apps (Free, East Asia)
#      │                  *.html / js / css / data / audio  (約800KB)
#      │                  COOP: same-origin / COEP: credentialless
#      │
#      └──────────────> Azure Blob Storage (japaneast, 匿名読み取り+CORS)
#                         wav2vec2 24層 q8  318MB  ← 既定
#                         蒸留 12層 q8 ×2    166MB  ← ?model= で選んだときだけ
#
# なぜ Static Web Apps か:
#   COOP/COEP ヘッダが必須（無いと SharedArrayBuffer が使えず WASM が
#   1スレッドに落ちて2倍遅くなる）。SWA は staticwebapp.config.json で
#   ヘッダを指定できる。Blob の静的サイト機能では任意ヘッダを付けられず、
#   Front Door を挟むことになって構成も費用も増える。
#
# なぜモデルを Blob に置くか:
#   SWA は Free で 250MB 上限なので 318MB のモデルは載らない。
#   HuggingFace CDN のままでも動くが、初回訪問ごとに外部から 300MB 引くことになり、
#   速度も可用性も他社任せになる。

set -euo pipefail
cd "$(dirname "$0")/.."

RG=${RG:-eikaiwa-pron-rg}
LOC=${LOC:-japaneast}
SWA_NAME=${SWA_NAME:-eikaiwa-pron-demo}
SWA_LOC=${SWA_LOC:-eastasia}   # SWA の Free が使えるのは限られたリージョンだけ
CONTAINER=models
MODEL_DIR=wav2vec2-lv-60-espeak-cv-ft-ONNX
CACHE=.hfcache/onnx-community/$MODEL_DIR

WITH_MODEL=false
WITH_STUDENTS=false
for a in "$@"; do
  case "$a" in
    --with-model) WITH_MODEL=true ;;
    --with-students) WITH_STUDENTS=true ;;
    *) echo "不明な引数: $a" >&2; exit 1 ;;
  esac
done

# --- ストレージアカウント名を引き当てる（無ければ作る） ---
SA=$(az storage account list -g "$RG" --query "[?starts_with(name,'eikaiwapron')].name | [0]" -o tsv 2>/dev/null || true)
if [[ -z "$SA" || "$SA" == "null" ]]; then
  SA=eikaiwapron$(openssl rand -hex 3)
  echo "ストレージアカウントを作成: $SA"
  az group create -n "$RG" -l "$LOC" -o none
  az storage account create -n "$SA" -g "$RG" -l "$LOC" \
    --sku Standard_LRS --kind StorageV2 --access-tier Hot \
    --allow-blob-public-access true --min-tls-version TLS1_2 -o none
  export AZURE_STORAGE_ACCOUNT="$SA"
  export AZURE_STORAGE_KEY=$(az storage account keys list -g "$RG" -n "$SA" --query "[0].value" -o tsv)
  az storage container create -n "$CONTAINER" --public-access blob -o none
  # fetch で読むので CORS が要る
  az storage cors add --services b --methods GET HEAD OPTIONS \
    --origins '*' --allowed-headers '*' --exposed-headers '*' --max-age 3600
  WITH_MODEL=true
else
  export AZURE_STORAGE_ACCOUNT="$SA"
  export AZURE_STORAGE_KEY=$(az storage account keys list -g "$RG" -n "$SA" --query "[0].value" -o tsv)
fi
echo "ストレージ: $SA"

# --- モデル ---
if [[ "$WITH_MODEL" == true ]]; then
  [[ -f "$CACHE/onnx/model_quantized.onnx" ]] || {
    echo "モデルが手元にありません。一度 node bench/run.mjs q8 を回してキャッシュを作ってください。" >&2
    exit 1
  }
  echo "モデルをアップロード中（318MB）…"
  az storage blob upload -c "$CONTAINER" -f "$CACHE/config.json" \
    -n "$MODEL_DIR/config.json" --overwrite --content-type application/json -o none
  az storage blob upload -c "$CONTAINER" -f "$CACHE/preprocessor_config.json" \
    -n "$MODEL_DIR/preprocessor_config.json" --overwrite --content-type application/json -o none
  az storage blob upload -c "$CONTAINER" -f "$CACHE/onnx/model_quantized.onnx" \
    -n "$MODEL_DIR/onnx/model_quantized.onnx" --overwrite \
    --content-type application/octet-stream --max-connections 8 -o none
fi

# --- 蒸留した生徒モデル ---
#
# 現行モデルと同じ置き方（<dir>/config.json, preprocessor_config.json,
# onnx/model_quantized.onnx）にする。transformers.js から見れば区別はない。
# 特徴量抽出の設定は教師と同じものを使う（入力の作り方は変えていない）。
if [[ "$WITH_STUDENTS" == true ]]; then
  [[ -f "$CACHE/preprocessor_config.json" ]] || {
    echo "教師モデルのキャッシュ（$CACHE）がありません。生徒も同じ前処理設定を使います。" >&2
    exit 1
  }
  for dir in $(node -e "
    const m = require('./data/models.json').models;
    console.log(m.filter(x => x.dir !== '$MODEL_DIR').map(x => x.dir).join(' '));
  "); do
    src=work/$dir
    [[ -f "$src/model_q8.onnx" ]] || { echo "$src/model_q8.onnx がありません" >&2; exit 1; }
    echo "生徒モデルをアップロード中: $dir（$(du -h "$src/model_q8.onnx" | cut -f1)）…"
    az storage blob upload -c "$CONTAINER" -f "$src/config.json" \
      -n "$dir/config.json" --overwrite --content-type application/json -o none
    az storage blob upload -c "$CONTAINER" -f "$CACHE/preprocessor_config.json" \
      -n "$dir/preprocessor_config.json" --overwrite --content-type application/json -o none
    az storage blob upload -c "$CONTAINER" -f "$src/model_q8.onnx" \
      -n "$dir/onnx/model_quantized.onnx" --overwrite \
      --content-type application/octet-stream --max-connections 8 -o none
  done
fi

# --- 静的サイト ---
bash tools/build-dist.sh > /dev/null
cat > dist/data/model-source.json <<JSON
{
  "_comment": "自前配信（Azure Blob Storage）。tools/deploy-azure.sh が生成する。",
  "model": "$MODEL_DIR",
  "remoteHost": "https://$SA.blob.core.windows.net/$CONTAINER/",
  "remotePathTemplate": "{model}/"
}
JSON

if ! az staticwebapp show -n "$SWA_NAME" -g "$RG" -o none 2>/dev/null; then
  echo "Static Web App を作成: $SWA_NAME"
  az staticwebapp create -n "$SWA_NAME" -g "$RG" -l "$SWA_LOC" --sku Free -o none
fi

TOKEN=$(az staticwebapp secrets list -n "$SWA_NAME" -g "$RG" --query "properties.apiKey" -o tsv)
npx --yes @azure/static-web-apps-cli@latest deploy ./dist \
  --deployment-token "$TOKEN" --env production --no-use-keychain

HOST=$(az staticwebapp show -n "$SWA_NAME" -g "$RG" --query defaultHostname -o tsv)
echo
echo "https://$HOST"
