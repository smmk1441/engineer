// 検証用の静的サーバ。
//
//   node tools/serve.mjs            http://localhost:8080
//   node tools/serve.mjs --isolate  COOP/COEP を付けて起動
//
// file:// では ES モジュールもマイクも使えないので、ローカルでも
// サーバ経由で開く必要がある（localhost は secure context 扱い）。
//
// --isolate を付けると crossOriginIsolated になり、onnxruntime-web の
// WASM マルチスレッドが有効になる。学校端末の実効性能を見積もるとき、
// スレッド有無で倍以上変わるのでスイッチにしてある。
// COEP は credentialless。require-corp だと HuggingFace CDN からの
// モデル取得が CORP ヘッダ不足で落ちる。

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

// 既定はリポジトリ直下。ROOT=dist のように配信元を差し替えられる。
const ROOT = path.resolve(process.env.ROOT || path.join(import.meta.dirname, '..'));
const PORT = Number(process.env.PORT || 8080);
const isolate = process.argv.includes('--isolate');

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.wav': 'audio/wav',
  '.m4a': 'audio/mp4',
  '.svg': 'image/svg+xml',
};

http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  let file = path.join(ROOT, url === '/' ? 'index.html' : url);

  if (!file.startsWith(ROOT)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404, { 'content-type': 'text/plain' }).end('not found');
    return;
  }

  const headers = {
    'content-type': TYPES[path.extname(file)] || 'application/octet-stream',
    'cache-control': 'no-cache',
  };
  if (isolate) {
    headers['cross-origin-opener-policy'] = 'same-origin';
    headers['cross-origin-embedder-policy'] = 'credentialless';
  }
  res.writeHead(200, headers);
  fs.createReadStream(file).pipe(res);
}).listen(PORT, () => {
  console.log(`http://localhost:${PORT}  root=${ROOT}${isolate ? '  (cross-origin isolated)' : ''}`);
});
