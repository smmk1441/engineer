#!/usr/bin/env python3
"""層を削ったときに、話者ラダー（採点の目盛り）がどうなるかを測る。

    python3 tools/layer-ladder.py       # -> work/ladder-logp/*.bin
    node bench/layer-ladder.mjs         # 採点して表にする

tools/layer-probe.py はフレーム一致率までしか出さない。それは代理指標で、
実際に見たいのは「ネイティブが星3つ、日本語訛りが星2つ、順位が崩れない」かどうか。
ここでは層を削ったモデルの出力を実際に作り、既存の採点器へ渡せる形で書き出す。

前回の反省: 24層ぶんの中間出力をグラフに足すと ONNX Runtime のメモリ再利用が
効かなくなり、推論が数倍遅くなった（800ファイルで90分）。今回は見る層を絞る。
"""
import json
import os
import time

import numpy as np
import onnx
import onnxruntime as ort
from onnx import helper

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, '.hfcache/onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX/onnx/model.onnx')
WORK = os.path.join(ROOT, 'work')
OUT = os.path.join(WORK, 'ladder-logp')

# 見る層。全部出すと遅いので、傾向が分かる範囲に絞る。
LAYERS = [8, 12, 16, 20, 24]
# 出力層を当てはめるのに使う音声の数（多いほど当てはめが安定する）
N_TRAIN = 250


def probed_path():
    p = os.path.join(WORK, f'model-layers-{"-".join(map(str, LAYERS))}.onnx')
    if not os.path.exists(p):
        os.makedirs(WORK, exist_ok=True)
        print('中間出力つきモデルを作成中…', flush=True)
        m = onnx.load(SRC)
        for L in LAYERS:
            if L == 24:
                continue  # 24層は logits をそのまま使う
            m.graph.output.append(helper.make_tensor_value_info(
                f'/wav2vec2/encoder/layers.{L-1}/Add_1_output_0', onnx.TensorProto.FLOAT, None))
        onnx.save(m, p)
    return p


def read_wav(path):
    import wave
    with wave.open(path) as w:
        raw = w.readframes(w.getnframes())
    return np.frombuffer(raw, dtype='<i2').astype(np.float32) / 32768.0


def normalize(a):
    return (a - a.mean()) / np.sqrt(a.var() + 1e-7)


def log_softmax(x):
    x = x - x.max(-1, keepdims=True)
    return x - np.log(np.exp(x).sum(-1, keepdims=True))


def main():
    path = probed_path()
    en = json.load(open(os.path.join(ROOT, 'data/en-phones.json')))
    vocab = json.load(open(os.path.join(ROOT, 'data/vocab.json')))
    keep = np.array([vocab['<pad>']] + [i for i in en['ids'] if i != vocab['<pad>']])
    K = len(keep)

    corpus = os.path.join(WORK, 'corpus')
    train_files = sorted(f for f in os.listdir(corpus) if f.endswith('.wav'))[:N_TRAIN]
    bench = os.path.join(ROOT, 'bench/audio')
    eval_files = sorted(f for f in os.listdir(bench) if f.endswith('.wav'))

    print(f'出力層の当てはめ: {len(train_files)} ファイル / 評価: {len(eval_files)} ファイル', flush=True)
    sess = ort.InferenceSession(path, providers=['CPUExecutionProvider'])
    hidden_names = [f'/wav2vec2/encoder/layers.{L-1}/Add_1_output_0' for L in LAYERS if L != 24]
    names = ['logits'] + hidden_names

    D = 1024
    XtX = {L: np.zeros((D + 1, D + 1), np.float64) for L in LAYERS if L != 24}
    XtY = {L: np.zeros((D + 1, K), np.float64) for L in LAYERS if L != 24}

    t0 = time.time()
    for i, f in enumerate(train_files):
        a = normalize(read_wav(os.path.join(corpus, f)))[None, :]
        res = sess.run(names, {'input_values': a})
        tlp = log_softmax(res[0][0][:, keep]).astype(np.float32)
        for L, h in zip([x for x in LAYERS if x != 24], res[1:]):
            X1 = np.concatenate([h[0], np.ones((len(h[0]), 1), np.float32)], 1).astype(np.float64)
            XtX[L] += X1.T @ X1
            XtY[L] += X1.T @ tlp
        if (i + 1) % 25 == 0:
            el = time.time() - t0
            print(f'\r  当てはめ {i+1}/{len(train_files)}  {el:.0f}s '
                  f'(残り {el/(i+1)*(len(train_files)-i-1):.0f}s)', end='', flush=True)
    print()

    heads = {}
    for L in LAYERS:
        if L == 24:
            continue
        heads[L] = np.linalg.solve(XtX[L] + 1.0 * np.eye(D + 1), XtY[L]).astype(np.float32)

    # 評価用の音声について、層ごとの対数事後確率を書き出す
    os.makedirs(OUT, exist_ok=True)
    meta = []
    for f in eval_files:
        a = normalize(read_wav(os.path.join(bench, f)))[None, :]
        res = sess.run(names, {'input_values': a})
        per = {}
        per[24] = log_softmax(res[0][0][:, keep]).astype(np.float32)
        for L, h in zip([x for x in LAYERS if x != 24], res[1:]):
            h1 = np.concatenate([h[0], np.ones((len(h[0]), 1), np.float32)], 1)
            per[L] = log_softmax(h1 @ heads[L]).astype(np.float32)
        for L, lp in per.items():
            lp.tofile(os.path.join(OUT, f'{f[:-4]}__L{L}.bin'))
        meta.append({'file': f, 'T': int(per[24].shape[0])})
        print(f'\r  評価 {len(meta)}/{len(eval_files)}', end='', flush=True)
    print()

    json.dump({'layers': LAYERS, 'K': K, 'tokens': ['<pad>'] + [t for t in en['phones']],
               'files': meta},
              open(os.path.join(OUT, 'meta.json'), 'w'), indent=2)
    print(f'-> {OUT}')


if __name__ == '__main__':
    main()
