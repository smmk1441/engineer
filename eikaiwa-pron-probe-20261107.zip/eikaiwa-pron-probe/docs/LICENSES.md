# ライセンスと費用

商用利用に向けて、使っているものを洗い出した結果。
2026年9月時点の調査で、**法務の判断ではない**。判断が要る箇所は「要確認」と書いてある。

構成そのものは [ARCHITECTURE.md](ARCHITECTURE.md)、インフラ費用の詳細は
[MEASUREMENTS.md](MEASUREMENTS.md) の §2。

---

## まとめ

| | 対象 | 状態 |
|---|---|---|
| 🔴 | 同梱している「おてほん」音声 | **差し替えが必要** |
| 🟡 | espeak-ng (GPL-3.0-or-later) | ビルド時のみ。要確認 |
| 🟡 | 外部CDN依存（jsdelivr / Google Fonts） | 費用ではないが本番前に自前配信へ |
| 🟢 | モデル・ライブラリ・フォント | 無償で商用利用可 |
| 💰 | Azure | デモは実質¥0。本番規模では配信量が効く |

---

## 🔴 おてほん音声 — 差し替えが必要

`audio/model/*.m4a`（配信物に含まれる）は **macOS 内蔵の TTS（Samantha）** で生成している
（[../tools/gen-model-audio.sh](../tools/gen-model-audio.sh)）。

Apple のシステム音声は macOS の使用許諾の範囲で使うもので、
**生成した音声を商用製品に同梱して再配布することは明確には許諾されていない。**
検証用に手早く用意しただけで、そのまま商用に持っていくものではない。

### 差し替え先

課題文は固定なので、**一度生成すれば以降の費用はかからない。** 9文なら数十円の世界。

| 選択肢 | 備考 |
|---|---|
| **Azure AI Speech (Neural TTS)** | すでに Azure を使っているので構成が素直。商用利用可・従量課金 |
| Amazon Polly / Google Cloud TTS | 同上 |
| 人の録音 | 教材としては最良。小学生向けなら検討の価値がある |

### 作業

`tools/gen-model-audio.sh` を差し替え先のAPIで置き換えるだけ。
出力先（`audio/model/s*.m4a`）とファイル名の規則を守れば、アプリ側の変更は不要。

**差し替えたら「計測」→「お手本で自己診断」を必ず通すこと。** 声が変わると点も変わる。
実測では声によって同じ文の素点が 0.08〜0.98 まで振れた（[NOTES.md](NOTES.md) §0-6）。

### 検証用の音声について

`bench/audio/*.wav` も同じく macOS の `say` で作っているが、**配信物には含まれない**
（[../tools/build-dist.sh](../tools/build-dist.sh) が集めるのは `index.html` / `css` /
`js` / `data` / `audio` だけ）。リポジトリを社外に出す場合は別途整理が要る。

---

## 🟡 espeak-ng — ビルド時のみ。要確認

`espeak-ng 1.52.0` / **GPL-3.0-or-later**。

正解音素列の生成（[../tools/gen-reference.mjs](../tools/gen-reference.mjs)）と
英語音素の抽出（[../tools/gen-en-inventory.mjs](../tools/gen-en-inventory.mjs)）に使っている。

**アプリには一切同梱していない。** 開発機で CLI として叩き、出力された音素列を
`data/reference.json` / `data/en-phones.json` に保存しているだけ。
生成物はデータであってプログラムの派生物ではない、という整理が一般的だが、
GPL が絡むので一度見てもらう価値はある。

依存を切りたい場合は、生成済みの JSON を成果物として固定し、
以後 espeak-ng を使わない運用にできる（課題文を足すときだけ必要になる）。

---

## 🟢 無償で商用利用可

### モデル

| | ライセンス |
|---|---|
| `facebook/wav2vec2-large-lv60`（事前学習） | Apache-2.0 |
| `facebook/wav2vec2-lv-60-espeak-cv-ft`（音素認識） | Apache-2.0 |
| `onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX`（ONNX変換） | Apache-2.0 |

**Apache-2.0 なのは大きい。** 商用利用・改変・再配布が可能で、
将来の蒸留（引き継ぎメモでいう案2）にもそのまま使える。

学習データは CommonVoice と LibriSpeech。重みのライセンスは上記のとおり Apache-2.0。

### ライブラリ

| | ライセンス | 備考 |
|---|---|---|
| `@huggingface/transformers` 3.7.6 | Apache-2.0 | 実行時 |
| `onnxruntime-web` 1.22 | MIT | 実行時（transformers.js 経由） |
| `puppeteer-core` 23.11 | Apache-2.0 | 開発時のみ |

### フォント

| | ライセンス |
|---|---|
| M PLUS Rounded 1c | SIL OFL |
| Baloo 2 | SIL OFL |

**同梱・改変とも可。** 自前配信に切り替えても問題ない（むしろ推奨。下記）。

### 絵文字

`🎤 ⭐️ ☆ 🔊 ♪ ♬` を使っているが、**フォントを同梱していない**（端末のシステム
フォントで描画される）ので再配布の問題は無い。ただし端末によって見た目が変わる。
デザインを固定したいなら SVG に置き換える。

---

## 🟡 外部CDN依存 — 本番前に自前配信へ

実行時に外部から読んでいるもの:

| 参照先 | 中身 | 本番での扱い |
|---|---|---|
| `cdn.jsdelivr.net` | transformers.js | **自前配信にする。** 他社CDNの可用性に授業が依存する |
| `fonts.googleapis.com` / `fonts.gstatic.com` | フォント2種 | **自前配信にする。** 下記 |
| `huggingface.co` | モデル | デプロイ済み構成では Azure Blob に移してある |

**Google Fonts の外部読み込みは、小学生の利用端末からGoogleへIPアドレスが飛ぶ。**
学校で使うサービスとして説明が要る箇所なので、フォントは同梱したほうがいい
（OFL なので同梱に問題は無い）。

---

## 💰 Azure の費用

### 現在のデモ

| | |
|---|---|
| Static Web Apps (Free) | **¥0**（帯域100GB/月まで） |
| Blob ストレージ 318MB | 約 **¥1/月** |
| Blob 下り | 約 **¥5/初回訪問**（2回目以降はブラウザキャッシュから読むので¥0） |

URL が広く出回ると訪問数 × ¥5 で効く。

### 本番規模で効くもの

モデルの配信量。420万端末 × 318MB = **約1.34PB**（概算1〜1.5億円）。
一度きりだが、モデルを更新するたびに再発生する。

ただし比較対象は外部APIの従量課金で、そちらは **1回1円 × 1日2,000万回 = 年73億円**。
桁が違うので、[MEASUREMENTS.md](MEASUREMENTS.md) の結論は変わらない。

実際には CDN を挟む、キッティング時に同梱する、夜間に事前配信するなどで
さらに下げられる（MEASUREMENTS.md §2）。

---

## 本番前のチェックリスト

- [ ] **おてほん音声を商用利用可能な音源に差し替える**（🔴 必須）
- [ ] espeak-ng の GPL について法務確認、または生成物を固定して依存を切る
- [ ] transformers.js を自前配信にする
- [ ] フォントを同梱して外部読み込みをやめる
- [ ] `bench/audio/` の扱いを決める（リポジトリを社外に出す場合）
