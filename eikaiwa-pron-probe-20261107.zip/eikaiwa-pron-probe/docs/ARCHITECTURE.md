# 全体の作り

このリポジトリが何をどう組み立てているかの見取り図。
使い方は [../README.md](../README.md)、計測値は [MEASUREMENTS.md](MEASUREMENTS.md)、
実装中に踏んだ穴は [NOTES.md](NOTES.md)、商用化の前提は [LICENSES.md](LICENSES.md)。

**先に結論を書くと、配信しているモデルは学習していない。** 既存の学習済みモデルを借りて、
その出力をどう採点に変えるかだけを組んでいる。オリジナリティがあるのはそこと、
ブラウザで完結させるための周辺の作りのほう。
（小型化のために蒸留した生徒モデルは別途あり、切り替えて試せる。§5 と §7。）

---

## 1. モデルの来歴

使っているのは3段階を経たもので、①②は Meta AI、③はコミュニティによる変換。

| | 何か | 誰が |
|---|---|---|
| ① | `facebook/wav2vec2-large-lv60`<br>ラベル無し音声（LibriVox 6万時間）で自己教師あり事前学習。<br>「音声の構造を掴む」段階で、まだ何も書き起こせない | Meta AI<br>[arXiv:2006.11477](https://arxiv.org/abs/2006.11477) |
| ② | `facebook/wav2vec2-lv-60-espeak-cv-ft`<br>①を CommonVoice（多言語）で**音素認識**にファインチューニング。<br>約3.16億パラメータ / Apache-2.0 | Meta AI<br>[arXiv:2109.11680](https://arxiv.org/abs/2109.11680) |
| ③ | `onnx-community/wav2vec2-lv-60-espeak-cv-ft-ONNX`<br>②を ONNX へ変換し、量子化版（q8 / q4 / fp16 …）を用意したもの。<br>これを Transformers.js から読む | onnx-community |

**既定で動いているのは③そのもので、重みには一切手を入れていない**
（SHA-256 が配布物と一致することを確認済み）。こちらが足しているのは
推論時に候補を英語音素59個へ絞ることだけ。

### 名前の `espeak` が効いている

②の学習では、**音素ラベルを espeak で生成している**（`espeak-cv-ft` の espeak はそれ）。
そしてこちらも正解音素列を espeak-ng で作っている。つまり
**モデルが覚えた音素の体系と、こちらが用意する正解の体系が同じ**。

別々の発音辞書（CMUdict など）を使っていたら、ARPAbet と IPA の対応付け、
表記ゆれの吸収、音素の粒度合わせが延々と必要になっていた。
**モデルを選ぶときに、そのモデルがどの発音辞書で学習されたかを見るのは重要。**

---

## 2. 全体像

```
【ビルド時 — 開発機で1回だけ】

  課題文          ──espeak-ng──>  正解音素列 + 許容する異形   data/reference.json
                                                            data/listening.json
                                                            data/speaking.json
  英語辞書21万語   ──espeak-ng──>  英語音素 59個              data/en-phones.json
  課題文          ──macOS say──>  おてほん音声               audio/*/*.m4a


【実行時 — ブラウザ】

  マイク
    │  getUserMedia（音声処理はすべてオフ）
    │  16kHz モノラル Float32 / 適応的な無音トリム
    ↓
  [ Web Worker ]
    │  wav2vec2 (ONNX q8, WASM 4スレッド)
    ↓
  20ms ごと × (英語59音素 + blank) の対数事後確率
    │
    ├──> CTC 強制アライメント (Viterbi)  ──> 音素ごとのフレーム区間
    │         ↓
    │      GOP = その音が、その区間で、どれだけそれらしかったか
    │         ↓
    │      星 0〜3 + 単語/音素の色分け
    │
    └──> 自由デコード（貪欲）  ──> 「こう聞こえたよ」の表示と、
                                   「声が無い」の判定に使う
```

### 画面は3つ、エンジンは1つ

| 画面 | 何をするか | 正解文 |
|---|---|---|
| `index.html` 発音チャレンジ | 決まった文を読んで発音を採点 | 既知 |
| `speaking.html` はなして つたえよう | 教材形式（音読 / 対話 / 発表） | **選んだ時点で**既知 |
| `listen.html` きいて こたえよう | 設問を聞いて選択肢を声で答える | 未知（候補から選ぶ） |

**`listen.html` だけが「何と言ったか」を当てている。** 残り2つは正解文が既知で、
同じ採点経路（強制アライメント → GOP → 星）を通る。

`speaking.html` の対話・発表は、答えを**先にタップさせる**ことで未知を既知に変えている。
機械に当てさせる手もあるが、枠が同じで1語しか違わない候補（`I like ___.`）だと
日本語訛り＋雑音で正答率が 40〜60% まで落ちた（MEASUREMENTS §7-9）。
先に選ばせればその不確かさが消え、「何を答えるか考える」段階は画面の側に残る。

---

## 3. ビルド時に作るもの

すべて `npm run data` と `bash tools/gen-*-audio.sh` で再生成できる。
本番なら、課題文を登録した時点でサーバ側で一度回せばよい類の処理。

### 正解音素列 — [tools/gen-reference.mjs](../tools/gen-reference.mjs)

課題文を espeak-ng (`--ipa=3`) に通し、モデルの語彙に合わせたトークン列へ切る。

切り方は [tools/ipa.mjs](../tools/ipa.mjs)。`--ipa=3` は二重母音の内側を
ZWJ (U+200D) で綴じてくれるので、そこを見て割る。最長一致で切ると
`Let's` が破擦音 `ts` になって壊れる（NOTES §3）。

同じ処理を [tools/gen-listening.mjs](../tools/gen-listening.mjs) と
[tools/gen-speaking.mjs](../tools/gen-speaking.mjs) も使う。問題を足すのは
それぞれの `QUESTIONS` 配列への追記。

### 許容する発音の異形 — [tools/variants.mjs](../tools/variants.mjs)

espeak が出すのは辞書形で、自然な発話とはずれる。`to school` は `t uː` ではなく `t ə`、
`get up` は `ɡ ɛ t` ではなく `ɡ ɛ ɾ`。**正しく読んでいるのに減点されるので、
位置ごとに「正解とみなす別の音素」を持たせている。**

対象は英語として確立した現象だけに絞る:

- 機能語（to / of / the …）の母音は曖昧母音でもよい
- 母音に挟まれた t / d のフラップ化
- 音節主音的な l / n
- `i`（happy母音）と `ɔ`（短いほう）のゆれ。**espeak がこの2つを弱い位置にしか
  使わない**ので、意味の対立を壊さずに緩められる。`see` / `sheep` は `iː`、
  `caught` / `call` は `ɔː` で別記号なので、`ship(ɪ)` と `sheep(iː)` の対立には触らない

経緯は NOTES §0-7。

**ここは全データの土台なので、触ったら話者ラダーの回帰を必ず見る**（§7）。

### 英語音素の在庫 — [tools/gen-en-inventory.mjs](../tools/gen-en-inventory.mjs)

モデルの語彙は **392 トークンの多言語 IPA** で、中国語の声調付き母音まで入っている。
英語音声でもそちらへ落ちる事故が実際に出た。

英語辞書21万語を espeak-ng に通して**英語で実際に出てくる音素 59 個**を抽出し、
推論時に候補をその範囲へ絞っている。

### おてほん音声 — [tools/gen-model-audio.sh](../tools/gen-model-audio.sh) 他

**端末の TTS に任せてはいけない。** ブラウザが選ぶ既定の声しだいで、
同じ文の素点が 0.08〜0.98 まで振れる（NOTES §6）。音声ファイルとして同梱する。

`audio/model/` が発音チャレンジ、`audio/listen/` が設問、`audio/speaking/` が
お手本と先生のしつ問。

**ただし現状の音声は macOS 内蔵 TTS で作っており、商用では差し替えが要る**
（[LICENSES.md](LICENSES.md)）。

---

## 4. 実行時の流れ

### 録音 — [js/audio.js](../js/audio.js)

- `getUserMedia` の音声処理（エコー除去・ノイズ抑制・自動ゲイン）は**すべてオフ**。
  通話向けの既定は発音評価に合わない。とくにエコー除去は、おてほんをスピーカーで
  鳴らしてマイクに聞かせる使い方を殺す
- **マイクは開いたまま保持する。** 開き直すと毎回 800ms 前後かかる
- 無音トリムのしきい値は暗騒音から決める。固定値だと、うるさい部屋で1フレームも削れない。
  ただし**声のレベルを超えさせない**（超えると全部消えて「何も起きない」ようになる）
- 録音の品質（S/N・レベル・クリップ・途中切れ）を一緒に返す。
  点が出ない原因が発音なのか録音環境なのかは、これが無いと切り分けられない

### 起動とモデルの選択 — [js/boot.js](../js/boot.js)

3画面が共有する。ここを分けると、下の自己検証が片方だけ抜ける。

**起動時に既知の音声で1回推論して出力が壊れていないか確かめる。**
WebGPU バックエンドはこのモデルで壊れた事後確率を返すため（NOTES §0-2）、
検証に落ちたら WASM へ退避する。既定は最初から WASM。

[data/models.json](../data/models.json) に並べたモデルを `?model=<id>` で切り替えられる
（計測パネルのプルダウンからも）。**既定は現行の24層から動かさない。**

**取得元によって ID の形が違う。** 自前配信（Blob）では置き場所がそのままパスになるが、
HuggingFace では組織名が要る。`dir` と `hf` を分けてあるのはそのため。
蒸留した生徒は HuggingFace に上げていないので、自前配信のときだけ選べる
（取得元に無いものは選択肢にも出さない）。

### 推論 — [js/engine.js](../js/engine.js) / [js/worker.js](../js/worker.js)

**Transformers.js の ASR パイプラインは使わない。** 理由は2つ:

1. このリポジトリには `tokenizer.json` が無く、パイプラインはロードに失敗する
2. パイプラインは文字列しか返さない。要るのは**フレームごとの対数事後確率そのもの**

モデルと特徴量抽出器を直接叩き、圧縮語彙（blank + 英語音素59）の上で
対数ソフトマックスを取る。以降の処理はすべてこの `T × 60` の行列だけを見る。

**推論は必ず Worker で走らせる。** WASM の推論はメインスレッドを完全に塞ぐ。
実測で推論中の `requestAnimationFrame` は 0fps、CSS アニメーションも止まる。
「かんがえ中」の表示を足しても、出た瞬間に固まる（NOTES §0-4）。

### 採点 — [js/gop.js](../js/gop.js) / [js/score.js](../js/score.js)

**正解音素列は既知なのだから、自由に読み取る必要がない。**
これが設計の中心。「何と言ったか」ではなく「その音がどれだけそれらしく出ていたか」を測る。

1. 正解音素列を CTC で**強制アライメント**（Viterbi）し、各音素のフレーム区間を得る
2. その区間で、正解音素（とその異形）のうち最良の対数事後確率を取り、
   同区間の最尤音素との差を取る → **音素ごとの GOP**
3. 強制パスと自由パスの尤度差 → **発話全体の GOP**。余分な音を挟むほど開く

GOP は 0 に近いほど「その音がいちばんそれらしく出ていた」。
音素ごとに連続値が出るので、色分けも星も、甘さ調整もここから素直に作れる。

最初は「自由デコード + Needleman-Wunsch で文字列比較」で作ったが、
argmax で1本に潰した時点で情報を捨てすぎていて、
**ちゃんと読めている発話まで減点していた**ので作り直した（MEASUREMENTS §5-2）。
旧実装は [../bench/legacy/](../bench/legacy/) に残してあり、
`node bench/compare-scoring.mjs` で新旧を並べられる。

### 貼り付ける区間と、採点する区間は別

`gopScore(out, phones, alts, { from })` の `from` より手前の音素は、
**貼り付けには使うが採点には入れない。**

2文で答える問題（`That is Elly. She is kind.` のうち `She is kind.` だけを見る）のため。
前置きまで採点区間に含めると、前置きを blank に押し込む無理が発話GOP に乗り、
**音素ごとの GOP が全部 0.0（発音は満点）なのに ★3 → ★2 に落ちた**。
しかも前置きをはっきり言うほどコストが上がるので、上手い子ほど損をしていた
（MEASUREMENTS §7-11）。

副産物として**固有名詞が解けた**。名前は採点区間の外にあるので、
`Elly` でも `Mary` でも `Takeshi` でも TGT の点は変わらない。

前置きは言っても言わなくてよいので、[js/speaking.js](../js/speaking.js) の `judge` が
**2通りの貼り付け方をためして良いほうを採る**（強制アライメントは1回 0.4ms）。
間違いは救済されない — 言い間違えは両方とも ★2、言わなければ両方とも ★1。

### 星への変換

測るところは素直に測り、**甘さは最後の変換だけで作る**。
係数は [../bench/calibrate.mjs](../bench/calibrate.mjs) で話者ラダーを見ながら決めた。

| | 値 | 意味 |
|---|---|---|
| `GOP_DEAD` | 0.25 | これ以内のズレは満点 |
| `GOP_TAU` | 2.6 | 減り方のなだらかさ |
| `UTT_WEIGHT` | 1.1 | 発話全体の無理をどれだけ効かせるか |
| `STAR_CUTS` | [0.75, 0.42] | 星3つ / 2つ の境目（`accuracy^0.8` に対する線） |
| `STAR_ZERO` | 0.30 | **星なしの境目。素点そのものに対する線** |

**根拠のある値ではない。** ネイティブが星3つに張り付き、日本語訛りが星2つに落ち、
順位が崩れない位置に手で置いただけ。実際の小学生の音声が取れたら全部引き直す前提。

`STAR_ZERO` だけは劣化条件込みで振って決めた（MEASUREMENTS §7-12）。
0.30 で、劣化込み100件の正解を1件も弾かずに、別の英文の97%・無音の100%を捕まえる。
**余裕は薄い** — 正解の最低は 0.313 で線のすぐ上にいる。

星なしの理由は2つに分ける。**自由デコードの音素数がこれを完全に分離する**
（無音は 0個、それ以外は最小6個）。

- 音素ゼロ → 「マイクに ちかづいて、もういちど いってみよう」
- それ以外 → 「もんだいの えいぶんを よんでみよう」

### 選択肢から選ぶ — [js/listen.js](../js/listen.js)

リスニング問題だけは正解文が未知。候補それぞれについて
「この音声をこの文として読ませるのにどれだけ無理があるか」（発話GOP）を測り、
いちばん無理の無いものを「言った文」とみなす。
重いのは推論1回だけで、候補1つの照合は 0.5ms 程度。

**必ず最良を選ぶ作りなので、でたらめでもどれかが選ばれる。**
弾く基準には **1位と2位の差**（`REJECT_MARGIN = 0.080`）を使う。
発話GOP の絶対値は使えない — 雑音が乗ると正しい発話のほうが低くなり、
順序が逆転する（MEASUREMENTS §7-7）。

---

## 5. 配信

```
ブラウザ ──HTTPS──> Azure Static Web Apps (Free, East Asia)
   │                  *.html / js / css / data / audio  約800KB
   │                  COOP: same-origin / COEP: credentialless
   │
   └──────────────> Azure Blob Storage (japaneast, 匿名読み取り + CORS)
                      wav2vec2 24層 q8        318MB  ← 既定
                      蒸留 12層 q8 ×2          166MB  ← ?model= で選んだときだけ
```

**COOP/COEP ヘッダが必須。** 無いと `SharedArrayBuffer` が使えず、
WASM が黙ってシングルスレッドに落ちて2倍遅くなる。エラーは何も出ない。
Static Web Apps を選んだのは、このヘッダを設定ファイルで指定できるから。

モデルを Blob に置くのは、SWA の Free が 250MB 上限で載らないのと、
初回訪問ごとに外部から 300MB 引くのを避けるため。

配信するのは [../tools/build-dist.sh](../tools/build-dist.sh) が集めたものだけ。
**`docs/` は含めない** — 規模や費用の見積もりが入っていて、公開URLに置くものではない。

```bash
bash tools/deploy-azure.sh                  # 静的サイトだけ（数十秒）
bash tools/deploy-azure.sh --with-model     # 現行モデルも上げ直す
bash tools/deploy-azure.sh --with-students  # 蒸留した生徒モデルも上げる
```

---

## 6. ファイルの地図

| | |
|---|---|
| **画面** | |
| `index.html` / `js/app.js` | 発音チャレンジ。数値は出さず星と色だけ |
| `speaking.html` / `js/speaking.js` | 教材形式（音読 / 対話 / 発表 / 2文で答える） |
| `listen.html` / `js/listen.js` | リスニング問題。選択肢から「どれを言ったか」を選ぶ |
| `js/boot.js` | エンジンの起動。3画面で共有。**自己検証とモデル選択もここ** |
| `css/app.css` / `listen.css` / `speaking.css` | 小学生向けの見た目 |
| **音声** | |
| `js/audio.js` | 録音、16kHz へのリサンプル、無音トリム、品質の計測 |
| **推論** | |
| `js/engine.js` | モデルのロードと、フレームごとの対数事後確率の算出 |
| `js/worker.js` | 推論を走らせる Worker |
| `js/engine-client.js` | Worker 側のエンジンを engine.js と同じ形で使う層 |
| **採点** | |
| `js/gop.js` | CTC 強制アライメントと GOP。**採点の中身はここ** |
| `js/score.js` | GOP → 星と色。甘め補正と星なしの判定はここだけ |
| **データ** | |
| `data/reference.json` / `listening.json` / `speaking.json` | 問題と正解音素列 |
| `data/en-phones.json` / `vocab.json` | 音素の在庫とモデルの語彙 |
| `data/models.json` | 選べるモデル（`?model=`） |
| `data/model-source.json` | 取得元。デプロイ時に書き換わる |
| **ビルド時** | |
| `tools/gen-reference.mjs` / `gen-listening.mjs` / `gen-speaking.mjs` | 問題 → 正解音素列 |
| `tools/variants.mjs` | 許容する発音の異形 |
| `tools/ipa.mjs` | espeak の IPA をモデルの音素トークンへ切る |
| `tools/gen-en-inventory.mjs` | 多言語語彙から英語音素だけ抜く |
| `tools/gen-*-audio.sh` | おてほん・設問の音声 |
| **配信・開発** | |
| `tools/build-dist.sh` / `deploy-azure.sh` / `staticwebapp.config.json` | |
| `tools/serve.mjs` | ローカルの静的サーバ。`--isolate` で COOP/COEP を付ける |
| **小型化（本番には入らない）** | |
| `tools/layer-probe.py` / `layer-ladder.py` | 層を削る実験 |
| `tools/distill-targets.py` / `distill-train.py` / `distill-export.py` | 蒸留 |
| `tools/fetch-librispeech.sh` | 学習データ |
| **検証** | |
| `js/*.test.mjs` | アライメント・採点・録音の単体テスト（`npm test`） |
| `bench/run.mjs` / `calibrate.mjs` / `compare-scoring.mjs` | 精度、係数の校正、新旧比較 |
| `bench/exp-degrade.mjs` | 録音の劣化に対する耐性 |
| `bench/exp-choice.mjs` / `exp-frame.mjs` | 候補から選ぶ方式の限界 |
| `bench/exp-two-sentence.mjs` | 2文で答える問題 |
| `bench/exp-zero-star.mjs` | 星なしのしきい値 |
| `bench/exp-child.mjs` / `distill-ladder.mjs` / `layer-ladder.mjs` | 子どもの声、小型化 |
| `bench/wav.mjs` | wav の読み書き（bench 共通） |
| `tools/measure-browser.mjs` / `compare-models.mjs` / `shots.mjs` | 実 Chrome を puppeteer で回す |
| `tools/test-mic.mjs` / `exp-mic-path.mjs` / `exp-noise-constraints.mjs` | マイク経路の検証 |

---

## 7. 触るときの勘所

**採点の係数を動かす前に** `node bench/calibrate.mjs` を回す。
話者ラダーの順位が崩れないことが最低条件。

**`tools/variants.mjs` を触ったら、全データを作り直してラダーを見る。**
ここは `reference.json` / `listening.json` / `speaking.json` すべての土台。
`npm run data` が3つとも作り直す。

**課題文を足したら**「計測」→「お手本で自己診断」を必ず通す。
お手本音声をマイクを通さず直接採点するので、**ここで星3つが出ない文は、
子どもが正しく読んでも点が出ない文**ということになる。0.85 未満なら出題しない。

**しきい値を決めるときは、最初から劣化条件を混ぜる。**
これは2回踏んでいる。クリーンな音声だけで決めた境目は、雑音が乗ると
正しい発話とでたらめの**順序が逆転**して役に立たなくなる（§7-7 / §7-12）。
`bench/exp-zero-star.mjs` が、正解 / 別の英文 / でたらめ / 無音 を
4つの劣化条件で振る型になっている。

**「点が出ない」と言われたら**、まず自己診断でエンジンとマイク経路を切り分ける。
過去に原因になったのは、順に:

1. WebGPU バックエンドが壊れた出力を返していた
2. おてほんの音声が端末まかせの声だった
3. マイクの音声処理が音を壊していた
4. 無音トリムが録音を全部消していた
5. espeak の辞書形が実際の発音とずれていた

**どれも採点ロジックではなかった。** 計測パネルの数字を先に見ること。

**本番だけ見て確認しない。** モデルの取得元が本番（Blob）とローカル（HuggingFace）で
違うため、片方だけ壊れる変更があり得る。実際に一度やった（§7-9 のコミット）。

**速度を上げたくなったら**、WASM の 861〜1,507ms が現状の実力。WebGPU は使えない。
モデルのパラメータ数を減らす以外に手は無い（MEASUREMENTS §7）。

**モデルを小さくしたくなったら**、語彙の絞り込みは効かない（サイズの 0.13% しかない）。
層を20まで削るのは実用可（257MB）。それ以上は蒸留が要る。
蒸留した12層（166MB）は Blob に置いてあり `?model=s12` で試せるが、
**サイズ半分と引き換えにネイティブと訛りを見分ける幅が4割縮む**（§7-8）。
既定を差し替えていないのはそのため。

**小学生の声は未検証のまま。** 代用（フォルマントを20%上げた成人音声）では
判別力がほぼ消える。データ量でも水増しでも越えられなかった。
**実データの収集が、小型化より先に来る課題。**
`STAR_ZERO` の余裕の薄さも、採点係数も、実データが取れたら最初に引き直す。
